from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd

from config import DEFAULT_RECENT_PERIODS
from .generic_schema import (
    AnalysisConfig,
    BusinessValueConfig,
    ContextColumnConfig,
    MetricConfig,
    business_value_output_column,
    context_output_column,
    metric_output_column,
)


def normalize_entity_id(series: pd.Series) -> pd.Series:
    normalized = series.where(series.notna(), "")
    normalized = normalized.astype(str).str.strip()
    normalized = normalized.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA})
    return normalized


def _to_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series.replace("", pd.NA), errors="coerce")


def _time_sort_values(df: pd.DataFrame, time_column: Optional[str]) -> pd.DataFrame:
    if time_column and time_column in df.columns:
        parsed = pd.to_datetime(df[time_column], errors="coerce")
        if parsed.notna().any():
            return df.assign(__time_sort=parsed).sort_values(["canonical_entity_id", "__time_sort"])
        return df.sort_values(["canonical_entity_id", time_column])
    return df.assign(__physical_order=range(len(df))).sort_values(["canonical_entity_id", "__physical_order"])


def _aggregate_series(
    df: pd.DataFrame,
    value_column: str,
    aggregation: str,
    time_column: Optional[str] = None,
    recent_periods: int = DEFAULT_RECENT_PERIODS,
):
    if aggregation == "FIRST":
        return df.groupby("canonical_entity_id", dropna=True)[value_column].first()
    if aggregation == "LATEST":
        ordered = _time_sort_values(df, time_column)
        return ordered.groupby("canonical_entity_id", dropna=True)[value_column].last()

    numeric = df.copy()
    numeric[value_column] = _to_numeric(numeric[value_column])
    if aggregation == "MEAN":
        return numeric.groupby("canonical_entity_id", dropna=True)[value_column].mean()
    if aggregation == "SUM":
        return numeric.groupby("canonical_entity_id", dropna=True)[value_column].sum(min_count=1)
    if aggregation == "MIN":
        return numeric.groupby("canonical_entity_id", dropna=True)[value_column].min()
    if aggregation == "MAX":
        return numeric.groupby("canonical_entity_id", dropna=True)[value_column].max()
    if aggregation == "RECENT_MEAN":
        ordered = _time_sort_values(numeric, time_column)
        return (
            ordered.groupby("canonical_entity_id", dropna=True)
            .tail(recent_periods)
            .groupby("canonical_entity_id", dropna=True)[value_column]
            .mean()
        )
    raise ValueError(f"Agregacao nao suportada: {aggregation}")


def _aggregate_trend(
    df: pd.DataFrame,
    metric: MetricConfig,
    recent_periods: int = DEFAULT_RECENT_PERIODS,
) -> Tuple[pd.Series, pd.Series, pd.Series]:
    time_column = metric.time_column
    if not time_column or time_column not in df.columns:
        raise ValueError(f"Metrica de tendencia precisa de tempo: {metric.label}")

    working = df[["canonical_entity_id", time_column, metric.source_column]].copy()
    working[metric.source_column] = _to_numeric(working[metric.source_column])
    working = _time_sort_values(working, time_column)
    previous_values = {}
    recent_values = {}
    deltas = {}
    for entity_id, group in working.groupby("canonical_entity_id", dropna=True):
        values = group[metric.source_column].dropna()
        if len(values) == 0:
            previous_values[entity_id] = pd.NA
            recent_values[entity_id] = pd.NA
            deltas[entity_id] = pd.NA
            continue
        recent = values.tail(recent_periods)
        previous = values.iloc[: max(0, len(values) - len(recent))]
        recent_mean = float(recent.mean()) if len(recent) else pd.NA
        previous_mean = float(previous.mean()) if len(previous) else float(values.head(1).mean())
        delta = recent_mean - previous_mean if pd.notna(recent_mean) and pd.notna(previous_mean) else pd.NA
        previous_values[entity_id] = previous_mean
        recent_values[entity_id] = recent_mean
        deltas[entity_id] = delta
    return pd.Series(deltas), pd.Series(previous_values), pd.Series(recent_values)


def _apply_status_filters(df: pd.DataFrame, sheet: str, config: AnalysisConfig) -> pd.DataFrame:
    filtered = df.copy()
    for status_filter in config.status_filters:
        if status_filter.source_sheet != sheet:
            continue
        if status_filter.source_column not in filtered.columns:
            continue
        allowed = {str(value) for value in status_filter.allowed_values}
        if allowed:
            filtered = filtered[filtered[status_filter.source_column].astype(str).isin(allowed)]
    return filtered


def _merge_one_per_entity(frames: Iterable[pd.DataFrame]) -> pd.DataFrame:
    frames = [frame for frame in frames if frame is not None and not frame.empty]
    if not frames:
        return pd.DataFrame(columns=["canonical_entity_id"])
    merged = frames[0]
    for frame in frames[1:]:
        merged = merged.merge(frame, on="canonical_entity_id", how="outer", validate="one_to_one")
    return merged


def build_entity_metrics(
    sheets: Dict[str, pd.DataFrame],
    config: AnalysisConfig,
) -> Tuple[pd.DataFrame, dict]:
    frames: List[pd.DataFrame] = []
    metadata = {
        "ignored_sheets": [],
        "metric_columns": {},
        "context_columns": {},
        "business_value_columns": {},
        "trend_columns": {},
        "sheet_rows_after_aggregation": {},
    }

    metrics_by_sheet: Dict[str, List[MetricConfig]] = {}
    for metric in config.metrics:
        metrics_by_sheet.setdefault(metric.source_sheet, []).append(metric)

    contexts_by_sheet: Dict[str, List[ContextColumnConfig]] = {}
    for context in config.context_columns:
        contexts_by_sheet.setdefault(context.source_sheet, []).append(context)

    business_by_sheet: Dict[str, List[BusinessValueConfig]] = {}
    for item in config.business_values:
        business_by_sheet.setdefault(item.source_sheet, []).append(item)

    for sheet_name, df in sheets.items():
        entity_column = config.entity_keys.get(sheet_name)
        if not entity_column or entity_column not in df.columns:
            metadata["ignored_sheets"].append(
                {"sheet": sheet_name, "reason": "Nao foi possivel relacionar esta aba aos clientes."}
            )
            continue

        working = _apply_status_filters(df, sheet_name, config).copy()
        working["canonical_entity_id"] = normalize_entity_id(working[entity_column])
        working = working.dropna(subset=["canonical_entity_id"])

        sheet_parts: List[pd.DataFrame] = [
            pd.DataFrame({"canonical_entity_id": working["canonical_entity_id"].drop_duplicates()})
        ]

        for metric in metrics_by_sheet.get(sheet_name, []):
            if metric.source_column not in working.columns:
                continue
            output_col = metric_output_column(metric)
            time_col = metric.time_column or config.time_columns.get(sheet_name)
            recent_periods = metric.recent_periods or DEFAULT_RECENT_PERIODS
            if metric.generic_type == "TREND_RISK":
                delta, previous, recent = _aggregate_trend(working, metric, recent_periods)
                part = delta.rename(output_col).reset_index().rename(columns={"index": "canonical_entity_id"})
                sheet_parts.append(part)
                metadata["trend_columns"][output_col] = {
                    "previous_mean": previous.to_dict(),
                    "recent_mean": recent.to_dict(),
                }
            else:
                aggregated = _aggregate_series(
                    working,
                    metric.source_column,
                    metric.aggregation,
                    time_col,
                    recent_periods,
                )
                part = aggregated.rename(output_col).reset_index()
                sheet_parts.append(part)
            metadata["metric_columns"][metric.label] = output_col

        for context in contexts_by_sheet.get(sheet_name, []):
            if context.source_column not in working.columns:
                continue
            output_col = context_output_column(context)
            aggregated = _aggregate_series(
                working,
                context.source_column,
                context.aggregation,
                config.time_columns.get(sheet_name),
            )
            sheet_parts.append(aggregated.rename(output_col).reset_index())
            metadata["context_columns"][context.label] = output_col

        for business in business_by_sheet.get(sheet_name, []):
            if business.source_column not in working.columns:
                continue
            output_col = business_value_output_column(business)
            aggregated = _aggregate_series(
                working,
                business.source_column,
                business.aggregation,
                config.time_columns.get(sheet_name),
            )
            sheet_parts.append(aggregated.rename(output_col).reset_index())
            metadata["business_value_columns"][business.label] = output_col

        sheet_frame = _merge_one_per_entity(sheet_parts)
        metadata["sheet_rows_after_aggregation"][sheet_name] = int(len(sheet_frame))
        frames.append(sheet_frame)

    consolidated = _merge_one_per_entity(frames)
    return consolidated, metadata
