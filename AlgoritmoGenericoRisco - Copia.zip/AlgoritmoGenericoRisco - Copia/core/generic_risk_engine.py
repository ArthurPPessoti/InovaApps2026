from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from config import AUTO_SCALE_SMALL_SAMPLE, RISK_BANDS
from .generic_schema import (
    AnalysisConfig,
    MetricConfig,
    analysis_config_to_dict,
    business_value_output_column,
    context_output_column,
    metric_output_column,
)


def clamp(value, minimum: float = 0.0, maximum: float = 1.0):
    if pd.isna(value):
        return np.nan
    return float(max(minimum, min(maximum, value)))


def normalize_high_is_risk(x, scale_min: float, scale_max: float):
    if pd.isna(x) or scale_max == scale_min:
        return np.nan
    return clamp((float(x) - scale_min) / (scale_max - scale_min))


def normalize_low_is_risk(x, scale_min: float, scale_max: float):
    value = normalize_high_is_risk(x, scale_min, scale_max)
    if pd.isna(value):
        return np.nan
    return 1 - value


def normalize_binary_risk(x, value_risk_map: Dict[str, float]):
    if pd.isna(x):
        return np.nan
    key = str(x)
    if key not in value_risk_map:
        return np.nan
    return clamp(float(value_risk_map[key]))


def normalize_categorical_risk(x, category_risk_map: Dict[str, float]):
    return normalize_binary_risk(x, category_risk_map)


def normalize_target_range(
    x,
    healthy_min: float,
    healthy_max: float,
    scale_min: float,
    scale_max: float,
):
    if pd.isna(x):
        return np.nan
    x = float(x)
    if healthy_min <= x <= healthy_max:
        return 0.0
    if x < healthy_min:
        denominator = healthy_min - scale_min
        if denominator <= 0:
            return 1.0
        return clamp((healthy_min - x) / denominator)
    denominator = scale_max - healthy_max
    if denominator <= 0:
        return 1.0
    return clamp((x - healthy_max) / denominator)


def _robust_scale(values: pd.Series) -> Tuple[float, float, str]:
    clean = pd.to_numeric(values, errors="coerce").dropna()
    if len(clean) == 0:
        return 0.0, 1.0, "automatic"
    if len(clean) < AUTO_SCALE_SMALL_SAMPLE:
        scale_min = float(clean.min())
        scale_max = float(clean.max())
    else:
        scale_min = float(clean.quantile(0.05))
        scale_max = float(clean.quantile(0.95))
    if scale_min == scale_max:
        scale_max = scale_min + 1.0
    return scale_min, scale_max, "automatic"


def calculate_trend_risk(deltas: Iterable, trend_direction: str) -> pd.Series:
    series = pd.to_numeric(pd.Series(deltas), errors="coerce")
    signal = series if trend_direction == "UP_IS_RISK" else -series
    signal = signal.clip(lower=0)
    non_missing = signal.dropna()
    if len(non_missing) == 0:
        return pd.Series([np.nan] * len(series), index=series.index)
    if len(non_missing) < AUTO_SCALE_SMALL_SAMPLE:
        scale_min = float(non_missing.min())
        scale_max = float(non_missing.max())
    else:
        scale_min = float(non_missing.quantile(0.05))
        scale_max = float(non_missing.quantile(0.95))
    if scale_max == scale_min:
        risk = signal.apply(lambda value: np.nan if pd.isna(value) else (1.0 if value > 0 else 0.0))
    else:
        risk = signal.apply(lambda value: normalize_high_is_risk(value, scale_min, scale_max))
    return risk


def normalize_weights(metrics: List[MetricConfig]) -> Dict[str, float]:
    scoring_metrics = [m for m in metrics if m.generic_type != "INFORMATIONAL"]
    total = sum(float(metric.weight or 1) for metric in scoring_metrics)
    if total <= 0:
        return {}
    return {metric.label: float(metric.weight or 1) / total for metric in scoring_metrics}


def calculate_coverage(available_weight_sum: float, configured_weight_sum: float) -> float:
    if configured_weight_sum <= 0:
        return 0.0
    return 100 * available_weight_sum / configured_weight_sum


def calculate_score(weighted_sum: float, available_weight_sum: float) -> float:
    if available_weight_sum <= 0:
        return np.nan
    return 100 * weighted_sum / available_weight_sum


def calculate_contributions(risks: Dict[str, float], weights: Dict[str, float]) -> Dict[str, dict]:
    available = {
        label: risk
        for label, risk in risks.items()
        if label in weights and pd.notna(risk)
    }
    available_weight_sum = sum(weights[label] for label in available)
    contributions = {}
    for label, risk in available.items():
        normalized_weight = weights[label] / available_weight_sum if available_weight_sum else 0
        contributions[label] = {
            "metric_risk": float(risk),
            "normalized_weight": float(normalized_weight),
            "contribution_points": float(risk * normalized_weight * 100),
        }
    return contributions


def _band(score: Optional[float]) -> str:
    if pd.isna(score):
        return "Sem score"
    rounded = round(float(score))
    for band in RISK_BANDS:
        if band["min"] <= rounded <= band["max"]:
            return band["label"]
    return RISK_BANDS[-1]["label"]


def _missing_value_for_strategy(metric: MetricConfig):
    if metric.missing_strategy == "NEUTRAL":
        return 0.5
    if metric.missing_strategy == "RISK":
        return 1.0
    if metric.missing_strategy == "HEALTHY":
        return 0.0
    if metric.missing_strategy == "CUSTOM":
        return clamp(metric.missing_custom_value if metric.missing_custom_value is not None else 0.5)
    return np.nan


def _numeric_scale(consolidated: pd.DataFrame, column: str, metric: MetricConfig) -> Tuple[float, float, str]:
    if metric.scale_mode == "MANUAL":
        if metric.scale_min is None or metric.scale_max is None:
            raise ValueError(f"Escala manual incompleta para {metric.label}.")
        if metric.scale_min == metric.scale_max:
            raise ValueError(f"Escala manual invalida para {metric.label}.")
        return float(metric.scale_min), float(metric.scale_max), "manual"
    return _robust_scale(consolidated[column])


def _risk_series_for_metric(consolidated: pd.DataFrame, metric: MetricConfig) -> Tuple[pd.Series, dict]:
    column = metric_output_column(metric)
    if column not in consolidated.columns:
        return pd.Series([np.nan] * len(consolidated), index=consolidated.index), {}

    values = consolidated[column]
    meta = {}
    if metric.generic_type == "HIGH_IS_RISK":
        scale_min, scale_max, source = _numeric_scale(consolidated, column, metric)
        meta = {"scale_min": scale_min, "scale_max": scale_max, "scale_source": source}
        return pd.to_numeric(values, errors="coerce").apply(
            lambda value: normalize_high_is_risk(value, scale_min, scale_max)
        ), meta
    if metric.generic_type == "LOW_IS_RISK":
        scale_min, scale_max, source = _numeric_scale(consolidated, column, metric)
        meta = {"scale_min": scale_min, "scale_max": scale_max, "scale_source": source}
        return pd.to_numeric(values, errors="coerce").apply(
            lambda value: normalize_low_is_risk(value, scale_min, scale_max)
        ), meta
    if metric.generic_type == "BINARY_RISK":
        return values.apply(lambda value: normalize_binary_risk(value, metric.binary_mapping)), {
            "mapping": metric.binary_mapping
        }
    if metric.generic_type == "CATEGORICAL_RISK":
        return values.apply(lambda value: normalize_categorical_risk(value, metric.category_mapping)), {
            "mapping": metric.category_mapping
        }
    if metric.generic_type == "TARGET_RANGE":
        scale_min, scale_max, source = _numeric_scale(consolidated, column, metric)
        meta = {
            "scale_min": scale_min,
            "scale_max": scale_max,
            "scale_source": source,
            "healthy_min": metric.healthy_min,
            "healthy_max": metric.healthy_max,
        }
        return pd.to_numeric(values, errors="coerce").apply(
            lambda value: normalize_target_range(
                value,
                float(metric.healthy_min),
                float(metric.healthy_max),
                scale_min,
                scale_max,
            )
        ), meta
    if metric.generic_type == "TREND_RISK":
        risk = calculate_trend_risk(values, metric.trend_direction or "UP_IS_RISK")
        return risk, {"trend_direction": metric.trend_direction or "UP_IS_RISK", "scale_source": "automatic"}
    return pd.Series([np.nan] * len(consolidated), index=consolidated.index), {}


def run_generic_analysis(consolidated: pd.DataFrame, config: AnalysisConfig) -> dict:
    scoring_metrics = [metric for metric in config.metrics if metric.generic_type != "INFORMATIONAL"]
    weights = normalize_weights(scoring_metrics)
    configured_weight_sum = sum(float(metric.weight or 1) for metric in scoring_metrics)

    metric_risks: Dict[str, pd.Series] = {}
    metric_meta: Dict[str, dict] = {}
    for metric in scoring_metrics:
        risk_series, meta = _risk_series_for_metric(consolidated, metric)
        metric_risks[metric.label] = risk_series
        metric_meta[metric.label] = meta

    ranking: List[dict] = []
    details: List[dict] = []

    for idx, row in consolidated.iterrows():
        entity_id = row.get("canonical_entity_id")
        risks_for_entity = {}
        available_raw_weight_sum = 0.0
        weighted_sum = 0.0

        for metric in scoring_metrics:
            risk = metric_risks[metric.label].loc[idx]
            value_column = metric_output_column(metric)
            raw_value = row.get(value_column, np.nan)
            missing_applied = False
            if pd.isna(risk):
                replacement = _missing_value_for_strategy(metric)
                if pd.notna(replacement):
                    risk = replacement
                    missing_applied = True
            if pd.notna(risk):
                risks_for_entity[metric.label] = float(risk)
                available_raw_weight_sum += float(metric.weight or 1)
                weighted_sum += float(risk) * float(metric.weight or 1)

            details.append(
                {
                    "Entidade": entity_id,
                    "Metrica": metric.label,
                    "Aba origem": metric.source_sheet,
                    "Coluna origem": metric.source_column,
                    "Valor original": None if pd.isna(raw_value) else raw_value,
                    "Valor agregado": None if pd.isna(raw_value) else raw_value,
                    "Regra": metric.generic_type,
                    "Risco 0-1": None if pd.isna(risk) else round(float(risk), 6),
                    "Peso": float(metric.weight or 1),
                    "Peso normalizado": None,
                    "Contribuicao": 0.0,
                    "Tratamento vazio aplicado": missing_applied,
                    **metric_meta.get(metric.label, {}),
                }
            )

        score = calculate_score(weighted_sum, available_raw_weight_sum)
        coverage = calculate_coverage(available_raw_weight_sum, configured_weight_sum)
        contributions = calculate_contributions(risks_for_entity, weights)

        for detail in details:
            if detail["Entidade"] == entity_id and detail["Metrica"] in contributions:
                contribution = contributions[detail["Metrica"]]
                detail["Peso normalizado"] = round(contribution["normalized_weight"], 6)
                detail["Contribuicao"] = round(contribution["contribution_points"], 6)

        ordered_factors = sorted(
            contributions.items(),
            key=lambda item: item[1]["contribution_points"],
            reverse=True,
        )
        factors = [name for name, _ in ordered_factors[:3]]
        ranking_row = {
            "Entidade": entity_id,
            "Score": None if pd.isna(score) else round(float(score), 2),
            "Faixa": _band(score),
            "Cobertura": round(float(coverage), 2),
            "Fator 1": factors[0] if len(factors) > 0 else "",
            "Fator 2": factors[1] if len(factors) > 1 else "",
            "Fator 3": factors[2] if len(factors) > 2 else "",
            "Contribuicoes": contributions,
        }
        for context in config.context_columns:
            column = context_output_column(context)
            if column in consolidated.columns:
                value = row.get(column)
                ranking_row[context.label] = None if pd.isna(value) else value
        for business in config.business_values:
            column = business_value_output_column(business)
            if column in consolidated.columns:
                value = row.get(column)
                ranking_row[business.label] = None if pd.isna(value) else value
        ranking.append(ranking_row)

    ranking = sorted(
        ranking,
        key=lambda item: (-1 if item["Score"] is None else item["Score"]),
        reverse=True,
    )
    for position, row in enumerate(ranking, start=1):
        row["Posicao"] = position

    return {
        "ranking": ranking,
        "details": details,
        "methodology": methodology_text(),
        "config": analysis_config_to_dict(config),
        "metric_metadata": metric_meta,
    }


def methodology_text() -> str:
    return (
        "O sistema transforma metricas especificas da empresa em metricas genericas de risco. "
        "Cada metrica gera um risco normalizado entre 0 e 1. Os pesos configurados sao "
        "normalizados apenas entre metricas disponiveis para a entidade. O Score de Risco "
        "e 100 * soma(risco da metrica * peso disponivel) / soma(pesos disponiveis). "
        "A cobertura mostra quanto do peso total configurado possuia dados para aquela entidade. "
        "Escalas automaticas usam percentis 5 e 95 quando ha dados suficientes, reduzindo impacto "
        "de outliers. O score e um indice ponderado, nao uma probabilidade."
    )


def analysis_to_frames(result: dict, consolidated: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    ranking_rows = []
    for item in result["ranking"]:
        row = dict(item)
        row.pop("Contribuicoes", None)
        ranking_rows.append(row)
    return {
        "Ranking": pd.DataFrame(ranking_rows),
        "Detalhes": pd.DataFrame(result["details"]),
        "Configuracao": pd.json_normalize(result["config"], sep="."),
        "Metodologia": pd.DataFrame({"Texto": [result["methodology"]]}),
        "Dados Consolidados": consolidated.copy(),
    }
