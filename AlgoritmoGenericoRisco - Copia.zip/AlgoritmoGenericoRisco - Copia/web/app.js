const STORAGE_KEY = "risk-analysis-config-draft";

const stepInfo = [
  { id: 1, short: "Arquivo", help: "Envie seus dados para comecar." },
  { id: 2, short: "Clientes", help: "Confirme quem sao os clientes acompanhados." },
  { id: 3, short: "Abas", help: "Mostre como as abas pertencem ao mesmo cliente." },
  { id: 4, short: "Indicadores", help: "Escolha o que entra no Score de Risco." },
  { id: 5, short: "Revisao", help: "Confira as regras antes de executar." },
  { id: 6, short: "Resultado", help: "Veja o ranking e os detalhes." }
];

const state = {
  currentStep: 1,
  maxStep: 1,
  mode: "simple",
  uploadId: null,
  fileName: "",
  selectedFileMeta: null,
  uploading: false,
  uploadError: "",
  profile: null,
  ignoredSheets: new Set(),
  mainSheet: "",
  mainKey: "",
  entityKeys: {},
  suggestions: {},
  template: null,
  columnSettings: {},
  analysisId: null,
  ranking: [],
  details: []
};

const roleLabels = {
  IGNORE: "Ignorar",
  METRIC: "Indicador de risco",
  CONTEXT: "Informacao",
  BUSINESS_VALUE: "Valor de negocio",
  TIME: "Data/periodo",
  STATUS_FILTER: "Status/filtro"
};

const typeLabels = {
  HIGH_IS_RISK: "Quanto maior, maior o risco",
  LOW_IS_RISK: "Quanto menor, maior o risco",
  BINARY_RISK: "Sim / Nao",
  CATEGORICAL_RISK: "Categorias com niveis de risco",
  TARGET_RANGE: "Existe uma faixa saudavel",
  TREND_RISK: "Mudanca ao longo do tempo"
};

const typeDescriptions = {
  HIGH_IS_RISK: "Use quando valores altos representam uma situacao pior.",
  LOW_IS_RISK: "Use quando valores baixos representam uma situacao pior.",
  BINARY_RISK: "Use quando existem apenas dois estados.",
  CATEGORICAL_RISK: "Use quando categorias diferentes representam niveis diferentes.",
  TARGET_RANGE: "Valores dentro de uma faixa sao considerados saudaveis.",
  TREND_RISK: "Use quando aumento ou queda recente e mais importante que o valor isolado."
};

const aggregationLabels = {
  LATEST: "Ultimo valor",
  MEAN: "Media",
  RECENT_MEAN: "Media recente",
  SUM: "Soma",
  MIN: "Menor valor",
  MAX: "Maior valor"
};

const aggregationDescriptions = {
  LATEST: "Utiliza a informacao mais recente do cliente.",
  MEAN: "Utiliza a media de todo o historico disponivel.",
  RECENT_MEAN: "Utiliza a media dos ultimos 3 periodos.",
  SUM: "Soma todos os registros.",
  MIN: "Utiliza o menor valor encontrado.",
  MAX: "Utiliza o maior valor encontrado."
};

document.addEventListener("DOMContentLoaded", () => {
  bindNavigation();
  bindActions();
  health();
  loadTemplates();
  restoreDraft();
  renderSteps();
  renderAll();
});

function bindNavigation() {
  document.getElementById("steps").addEventListener("click", event => {
    const button = event.target.closest(".step");
    if (!button || button.disabled) return;
    showStep(Number(button.dataset.step));
  });
}

function bindActions() {
  byId("upload-button").addEventListener("click", uploadFile);
  byId("file-input").addEventListener("change", onFileSelected);
  byId("continue-file").addEventListener("click", () => {
    if (!state.uploadId || !state.profile) return toast("Envie um arquivo CSV ou Excel antes de continuar.", "error");
    unlock(2);
    showStep(2);
  });
  byId("confirm-clients").addEventListener("click", confirmClients);
  byId("suggest-button").addEventListener("click", suggestRelationships);
  byId("confirm-relationships").addEventListener("click", confirmRelationships);
  byId("review-button").addEventListener("click", openReview);
  byId("run-button").addEventListener("click", runAnalysis);
  byId("load-template-button").addEventListener("click", loadSelectedTemplate);
  byId("ignore-all-button").addEventListener("click", ignoreAllColumns);
  byId("equal-weights-button").addEventListener("click", equalWeights);
  byId("main-sheet").addEventListener("change", event => {
    state.mainSheet = event.target.value;
    state.mainKey = suggestKeyForSheet(state.mainSheet) || firstColumn(state.mainSheet);
    state.entityKeys[state.mainSheet] = state.mainKey;
    renderMainKey();
    renderClientSuggestions();
    renderRelationships();
    persistDraft();
  });
  byId("main-key").addEventListener("change", event => {
    state.mainKey = event.target.value;
    state.entityKeys[state.mainSheet] = state.mainKey;
    renderClientSuggestions();
    renderRelationships();
    persistDraft();
  });
  document.querySelectorAll(".back-button").forEach(button => {
    button.addEventListener("click", () => showStep(Number(button.dataset.back)));
  });
  document.querySelectorAll(".segmented button").forEach(button => {
    button.addEventListener("click", () => {
      state.mode = button.dataset.mode;
      renderMode();
      renderMetricCards();
      persistDraft();
    });
  });
}

async function health() {
  try {
    const data = await api("/api/health");
    byId("health").textContent = data.ok ? "Servidor ativo" : "Servidor indisponivel";
  } catch {
    byId("health").textContent = "Servidor indisponivel";
  }
}

async function uploadFile() {
  const input = byId("file-input");
  if (!input.files.length) {
    state.uploadError = "Escolha um arquivo CSV ou XLSX antes de enviar.";
    renderUploadState();
    return toast(state.uploadError, "error");
  }
  const file = input.files[0];
  if (!/\.(csv|xlsx)$/i.test(file.name)) {
    state.uploadError = "Formato nao suportado. Escolha um arquivo CSV ou XLSX.";
    renderUploadState();
    return toast(state.uploadError, "error");
  }

  console.log("arquivo selecionado", { name: file.name, size: file.size, type: file.type || "desconhecido" });
  console.log("iniciando upload");

  state.uploading = true;
  state.uploadError = "";
  state.uploadId = null;
  state.profile = null;
  renderUploadState();

  const form = new FormData();
  form.append("file", file);
  try {
    const response = await fetch("/api/files/upload", { method: "POST", body: form });
    const payload = await safeJson(response);
    console.log("upload response", { status: response.status, ok: response.ok, payload });
    if (!response.ok) {
      throw new Error(errorMessage(payload, "Nao foi possivel enviar o arquivo."));
    }
    if (!payload.upload_id) {
      throw new Error("O servidor nao retornou upload_id.");
    }

    state.uploadId = payload.upload_id;
    state.fileName = payload.filename || file.name;

    const profileResponse = await fetch(`/api/files/${encodeURIComponent(state.uploadId)}/profile`);
    const profilePayload = await safeJson(profileResponse);
    console.log("profile response", { status: profileResponse.status, ok: profileResponse.ok, payload: profilePayload });
    if (!profileResponse.ok) {
      throw new Error(errorMessage(profilePayload, "Nao foi possivel ler o perfil do arquivo."));
    }

    state.profile = profilePayload.profile || payload.profile;
    if (!state.profile) {
      throw new Error("O servidor nao retornou o perfil do arquivo.");
    }

    state.ignoredSheets = new Set(documentationSheets());
    state.mainSheet = state.template?.main_sheet || suggestMainSheet() || firstSheet();
    state.mainKey = state.template?.entity_keys?.[state.mainSheet] || suggestKeyForSheet(state.mainSheet) || firstColumn(state.mainSheet);
    state.entityKeys = { [state.mainSheet]: state.mainKey };
    state.suggestions = {};
    initColumnSettings();
    if (state.template) applyTemplate(state.template);

    unlock(1);
    renderAll();
    persistDraft();
    toast("Arquivo enviado com sucesso.");
  } catch (error) {
    state.uploadError = error.message || "Nao foi possivel enviar o arquivo.";
    state.uploadId = null;
    state.profile = null;
    renderUploadState();
    toast("Nao foi possivel enviar o arquivo.", "error");
  } finally {
    state.uploading = false;
    renderUploadState();
  }
}

function onFileSelected() {
  const file = byId("file-input").files[0];
  state.uploadId = null;
  state.profile = null;
  state.fileName = "";
  state.uploadError = "";
  if (!file) {
    state.selectedFileMeta = null;
  } else {
    state.selectedFileMeta = {
      name: file.name,
      size: file.size,
      type: fileTypeLabel(file.name)
    };
    console.log("arquivo selecionado", state.selectedFileMeta);
  }
  renderUploadState();
}

function renderUploadState() {
  const selected = byId("selected-file");
  const status = byId("upload-status");
  const uploadButton = byId("upload-button");
  const continueButton = byId("continue-file");
  if (state.selectedFileMeta) {
    selected.innerHTML = `
      <strong>Arquivo selecionado:</strong> ${escapeHtml(state.selectedFileMeta.name)}<br>
      <strong>Tamanho:</strong> ${formatBytes(state.selectedFileMeta.size)}<br>
      <strong>Tipo:</strong> ${escapeHtml(state.selectedFileMeta.type)}
    `;
  } else {
    selected.textContent = "Nenhum arquivo selecionado.";
  }
  uploadButton.disabled = state.uploading;
  uploadButton.textContent = state.uploading ? "Enviando arquivo..." : "Enviar arquivo";
  continueButton.disabled = !state.uploadId || !state.profile;
  if (state.uploading) {
    status.className = "upload-status";
    status.textContent = "Enviando arquivo...";
  } else if (state.uploadId && state.profile) {
    status.className = "upload-status success";
    status.textContent = "Arquivo enviado com sucesso.";
  } else if (state.uploadError) {
    status.className = "upload-status error";
    status.innerHTML = `Nao foi possivel enviar o arquivo.<br><small>${escapeHtml(state.uploadError)}</small>`;
  } else {
    status.className = "upload-status";
    status.textContent = "";
  }
}

function renderAll() {
  renderSteps();
  renderUploadState();
  renderProfile();
  renderRelationsShell();
  renderRelationships();
  renderMetricEditor();
  renderMetricCards();
  renderMode();
}

function renderSteps() {
  byId("step-counter").textContent = `Passo ${state.currentStep} de 6`;
  byId("step-help").textContent = stepInfo[state.currentStep - 1].help;
  byId("progress-bar").style.width = `${(state.currentStep / 6) * 100}%`;
  byId("steps").innerHTML = stepInfo.map(step => {
    const complete = state.maxStep > step.id;
    const active = state.currentStep === step.id;
    const disabled = state.maxStep < step.id;
    const prefix = complete ? "OK" : active ? "Agora" : "";
    return `<button class="step ${active ? "active" : ""} ${complete ? "complete" : ""}" data-step="${step.id}" ${disabled ? "disabled" : ""}>${prefix ? `<span>${prefix}</span>` : ""}${step.short}</button>`;
  }).join("");
}

function renderProfile() {
  const el = byId("file-profile");
  if (!state.profile) {
    el.innerHTML = "";
    return;
  }
  const sheets = Object.entries(state.profile);
  const docs = documentationSheets();
  const columnsCount = sheets.reduce((total, [, profile]) => total + profile.columns_count, 0);
  const possibleClients = estimatePossibleClients();
  const sheetList = sheets.map(([sheet, profile]) => {
    const doc = profile.is_documentation;
    return `<li>${doc ? "Documento" : "OK"} ${escapeHtml(sheet)} - ${profile.rows} registros${doc ? " (documentacao)" : ""}</li>`;
  }).join("");

  el.innerHTML = `
    <div class="box">
      <h3>Arquivo: ${escapeHtml(state.fileName)}</h3>
      <div class="found-grid">
        <div><strong>${sheets.length}</strong><span>abas encontradas</span></div>
        <div><strong>${possibleClients}</strong><span>possiveis clientes</span></div>
        <div><strong>${columnsCount}</strong><span>colunas disponiveis</span></div>
      </div>
      ${docs.length ? `<p class="notice">Encontramos uma aba que parece conter documentacao dos dados. Ela nao sera usada diretamente no Score de Risco.</p>` : ""}
      <ul class="sheet-summary">${sheetList}</ul>
    </div>
  `;
}

function renderRelationsShell() {
  const mainSheet = byId("main-sheet");
  if (!state.profile) {
    mainSheet.innerHTML = "";
    byId("main-key").innerHTML = "";
    return;
  }
  mainSheet.innerHTML = analyticSheetNames().map(sheet => option(sheet, sheet, state.mainSheet)).join("");
  if (state.mainSheet) mainSheet.value = state.mainSheet;
  renderMainKey();
  renderClientSuggestions();
}

function renderMainKey() {
  const keySelect = byId("main-key");
  const columns = columnsFor(state.mainSheet);
  keySelect.innerHTML = columns.map(col => option(col, col, state.mainKey)).join("");
  if (state.mainKey) keySelect.value = state.mainKey;
}

function renderClientSuggestions() {
  if (!state.profile) return;
  const sheet = suggestMainSheet();
  const key = suggestKeyForSheet(state.mainSheet);
  const sheetProfile = state.profile[state.mainSheet];
  byId("main-sheet-suggestion").innerHTML = sheet
    ? `Sugestao: <strong>${escapeHtml(sheet)}</strong><br><span>Por que sugerimos? Possui ${state.profile[sheet].rows} registros e uma possivel coluna identificadora.</span>`
    : "";
  byId("main-key-suggestion").innerHTML = key && sheetProfile
    ? `Sugestao: <strong>${escapeHtml(key)}</strong><br><span>Por que sugerimos? Esta coluna tem ${columnInfo(state.mainSheet, key)?.unique_count || 0} valores unicos.</span>`
    : "";
}

async function suggestRelationships() {
  if (!state.uploadId) return toast("Envie um arquivo primeiro.", "error");
  const data = await api("/api/relationships/suggest", {
    method: "POST",
    body: { upload_id: state.uploadId, main_sheet: state.mainSheet, main_key: state.mainKey }
  });
  state.suggestions = data.suggestions || {};
  renderRelationships();
  persistDraft();
  toast("Sugestoes calculadas. Revise antes de confirmar.");
}

function renderRelationships() {
  const editor = byId("relationship-editor");
  const note = byId("documentation-note");
  if (!state.profile) {
    editor.innerHTML = "<p>Envie um arquivo primeiro.</p>";
    note.innerHTML = "";
    return;
  }
  const docs = documentationSheets();
  note.innerHTML = docs.length ? `<div class="notice">Encontramos abas de documentacao: ${docs.map(escapeHtml).join(", ")}. Elas comecam ignoradas.</div>` : "";
  const rows = Object.entries(state.profile).map(([sheet, profile]) => relationshipRow(sheet, profile)).join("");
  editor.innerHTML = `
    <table>
      <thead><tr><th>Aba</th><th>Coluna que identifica o cliente</th><th>Ajuda</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  `;
  editor.querySelectorAll(".entity-key").forEach(select => {
    select.addEventListener("change", event => {
      const sheet = event.target.dataset.sheet;
      if (event.target.value === "__IGNORE__") {
        state.ignoredSheets.add(sheet);
        delete state.entityKeys[sheet];
      } else {
        state.ignoredSheets.delete(sheet);
        state.entityKeys[sheet] = event.target.value;
      }
      renderMetricEditor();
      renderMetricCards();
      persistDraft();
    });
  });
  editor.querySelectorAll(".use-suggestion").forEach(button => {
    button.addEventListener("click", () => {
      state.ignoredSheets.delete(button.dataset.sheet);
      state.entityKeys[button.dataset.sheet] = button.dataset.column;
      renderRelationships();
      renderMetricEditor();
      renderMetricCards();
      persistDraft();
    });
  });
}

function relationshipRow(sheet, profile) {
  if (sheet === state.mainSheet) {
    state.entityKeys[sheet] = state.mainKey;
    return `<tr><td>${escapeHtml(sheet)}</td><td>${escapeHtml(state.mainKey)} <span class="pill">principal</span></td><td>Esta e a lista principal.</td></tr>`;
  }
  const ignored = state.ignoredSheets.has(sheet);
  const selected = ignored ? "__IGNORE__" : state.entityKeys[sheet];
  const best = bestSuggestion(sheet);
  const options = [`<option value="__IGNORE__" ${ignored ? "selected" : ""}>Ignorar esta aba</option>`]
    .concat(columnsFor(sheet).map(col => option(col, col, selected)))
    .join("");
  const suggestionText = best
    ? `Sugestao ${best.relation_score}%: ${escapeHtml(best.column)}. Encontramos os mesmos codigos de clientes nesta coluna. <button class="inline use-suggestion" data-sheet="${escapeAttr(sheet)}" data-column="${escapeAttr(best.column)}">Usar sugestao</button>`
    : "Nao conseguimos identificar automaticamente. Selecione uma coluna ou ignore a aba.";
  const docText = profile.is_documentation ? "Esta aba parece documentacao e comeca ignorada." : suggestionText;
  return `<tr><td>${escapeHtml(sheet)}</td><td><select class="entity-key" data-sheet="${escapeAttr(sheet)}">${options}</select></td><td>${docText}</td></tr>`;
}

function renderMetricEditor() {
  const editor = byId("metric-editor");
  if (!state.profile) {
    editor.innerHTML = "<p>Envie um arquivo para configurar indicadores.</p>";
    return;
  }
  const rows = analyticSheetNames()
    .filter(sheet => !state.ignoredSheets.has(sheet))
    .flatMap(sheet => columnsFor(sheet).map(column => columnRoleRow(sheet, column)))
    .join("");
  editor.innerHTML = `
    <div class="box">
      <table class="metric-table">
        <thead><tr><th>Coluna</th><th>Aba</th><th>Usar como</th><th>Sugestao local</th></tr></thead>
        <tbody>${rows || `<tr><td colspan="4">Nenhuma aba relacionada para configurar.</td></tr>`}</tbody>
      </table>
    </div>
  `;
  editor.querySelectorAll(".role").forEach(select => {
    select.addEventListener("change", event => {
      const setting = settingFor(event.target.dataset.sheet, event.target.dataset.column);
      setting.role = event.target.value;
      renderMetricCards();
      persistDraft();
    });
  });
}

function columnRoleRow(sheet, column) {
  const info = columnInfo(sheet, column);
  const setting = settingFor(sheet, column);
  const suggestion = suggestionForColumn(info);
  return `
    <tr>
      <td><code>${escapeHtml(column)}</code></td>
      <td>${escapeHtml(sheet)}</td>
      <td>
        <select class="role" data-sheet="${escapeAttr(sheet)}" data-column="${escapeAttr(column)}">
          ${Object.entries(roleLabels).map(([value, label]) => option(value, label, setting.role)).join("")}
        </select>
      </td>
      <td class="muted">${suggestion}</td>
    </tr>
  `;
}

function renderMetricCards() {
  const container = byId("metric-cards");
  if (!state.profile) {
    container.innerHTML = "";
    return;
  }
  const metricSettings = selectedMetricSettings();
  const weights = normalizedWeights(metricSettings);
  container.innerHTML = metricSettings.length
    ? metricSettings.map(item => metricCard(item, weights[item.key] || 0)).join("")
    : `<div class="box"><h3>Nenhum indicador escolhido ainda</h3><p>Marque "Indicador de risco" nas colunas que devem influenciar o Score de Risco.</p></div>`;
  bindMetricCardEvents();
}

function metricCard(item, normalizedWeight) {
  const setting = item.setting;
  const info = columnInfo(item.sheet, item.column);
  const showManualScale = state.mode === "advanced" && setting.scale_mode === "MANUAL";
  const showMapping = ["BINARY_RISK", "CATEGORICAL_RISK"].includes(setting.generic_type);
  const showHealthy = setting.generic_type === "TARGET_RANGE";
  const showTrend = setting.generic_type === "TREND_RISK";
  const showTime = needsTime(setting) && sheetHasManyRows(item.sheet);
  const showAdvancedMissing = state.mode === "advanced";
  const typeOptions = Object.entries(typeLabels).map(([value, label]) => option(value, label, setting.generic_type)).join("");
  const aggregationOptions = Object.entries(aggregationLabels).map(([value, label]) => option(value, label, setting.aggregation)).join("");
  const timeOptions = columnsFor(item.sheet).map(column => option(column, column, setting.time_column || suggestTimeColumn(item.sheet))).join("");

  return `
    <article class="metric-card" data-key="${escapeAttr(item.key)}">
      <header>
        <div>
          <h3>${escapeHtml(prettyName(item.column))}</h3>
          <p><code>${escapeHtml(item.column)}</code> em ${escapeHtml(item.sheet)} ${hintIcon(typeDescriptions[setting.generic_type])}</p>
        </div>
        <span class="weight-preview">${Math.round(normalizedWeight)}%</span>
      </header>

      <div class="card-grid">
        <label>Como este indicador se comporta?
          <select class="generic-type">${typeOptions}</select>
          <small>${escapeHtml(typeDescriptions[setting.generic_type])}</small>
        </label>
        <label>Importancia no Score
          <input class="weight" type="number" min="0.01" step="0.1" value="${escapeAttr(setting.weight)}">
          <small>Voce pode usar qualquer numero positivo.</small>
        </label>
        <label>Como obter um valor quando ha varios registros?
          <select class="aggregation">${aggregationOptions}</select>
          <small>${escapeHtml(aggregationDescriptions[setting.aggregation])}</small>
        </label>
      </div>

      ${showTime ? `
        <div class="field-row">
          <label>Qual coluna informa quando cada registro aconteceu?
            <select class="time-column">${timeOptions}</select>
          </label>
        </div>
      ` : ""}

      <div class="scale-row ${state.mode === "advanced" ? "" : "hidden"}">
        <span>Escala ${hintIcon("Na escala automatica o sistema usa a distribuicao dos proprios clientes para transformar valores em risco entre 0 e 1.")}</span>
        <label><input type="radio" class="scale-mode" name="scale-${escapeAttr(item.key)}" value="AUTO" ${setting.scale_mode === "AUTO" ? "checked" : ""}> Automatica</label>
        <label><input type="radio" class="scale-mode" name="scale-${escapeAttr(item.key)}" value="MANUAL" ${setting.scale_mode === "MANUAL" ? "checked" : ""}> Informar limites</label>
      </div>

      <div class="card-grid ${showManualScale ? "" : "hidden"}">
        <label>Limite minimo <input class="scale-min" type="number" step="any" value="${escapeAttr(setting.scale_min ?? "")}"></label>
        <label>Limite maximo <input class="scale-max" type="number" step="any" value="${escapeAttr(setting.scale_max ?? "")}"></label>
      </div>

      <div class="${showMapping ? "" : "hidden"}">
        <label>${setting.generic_type === "BINARY_RISK" ? "Mapa dos dois estados" : "Mapa das categorias"}
          <textarea class="mapping" placeholder='{"Sim":1,"Nao":0}'>${escapeHtml(setting.mapping || "")}</textarea>
        </label>
      </div>

      <div class="card-grid ${showHealthy ? "" : "hidden"}">
        <label>Faixa saudavel minima <input class="healthy-min" type="number" step="any" value="${escapeAttr(setting.healthy_min ?? "")}"></label>
        <label>Faixa saudavel maxima <input class="healthy-max" type="number" step="any" value="${escapeAttr(setting.healthy_max ?? "")}"></label>
      </div>

      <div class="${showTrend ? "" : "hidden"}">
        <label>A mudanca que gera risco
          <select class="trend-direction">
            ${option("UP_IS_RISK", "Aumento recente gera risco", setting.trend_direction)}
            ${option("DOWN_IS_RISK", "Queda recente gera risco", setting.trend_direction)}
          </select>
        </label>
      </div>

      <div class="missing-row">
        <p>Quando nao houver valor para este cliente: <strong>${missingLabel(setting.missing_strategy)}</strong></p>
        <small>Padrao: usar apenas os outros indicadores, redistribuindo os pesos disponiveis.</small>
        <details class="${showAdvancedMissing ? "" : "hidden"}">
          <summary>Opcoes avancadas</summary>
          <select class="missing">
            ${["IGNORE_AND_REWEIGHT", "NEUTRAL", "RISK", "HEALTHY", "CUSTOM"].map(value => option(value, missingLabel(value), setting.missing_strategy)).join("")}
          </select>
        </details>
      </div>

      <footer><button class="done-indicator">Concluir indicador</button><span class="muted">${escapeHtml(info.kind)}${info.hints?.length ? ` - ${info.hints.join(", ")}` : ""}</span></footer>
    </article>
  `;
}

function bindMetricCardEvents() {
  byId("metric-cards").querySelectorAll(".metric-card").forEach(card => {
    const setting = state.columnSettings[card.dataset.key];
    card.querySelectorAll("select, input, textarea").forEach(input => {
      input.addEventListener("change", () => updateSettingFromCard(card, setting));
      input.addEventListener("input", () => updateSettingFromCard(card, setting, true));
    });
    card.querySelector(".done-indicator").addEventListener("click", () => toast("Indicador configurado."));
  });
}

function updateSettingFromCard(card, setting, partial = false) {
  setting.generic_type = valueOf(card, ".generic-type", setting.generic_type);
  setting.weight = Math.max(0.01, Number(valueOf(card, ".weight", setting.weight)) || 1);
  setting.aggregation = valueOf(card, ".aggregation", setting.aggregation);
  setting.scale_mode = checkedValue(card, ".scale-mode", setting.scale_mode);
  setting.scale_min = numberOrNull(valueOf(card, ".scale-min", setting.scale_min));
  setting.scale_max = numberOrNull(valueOf(card, ".scale-max", setting.scale_max));
  setting.mapping = valueOf(card, ".mapping", setting.mapping);
  setting.healthy_min = numberOrNull(valueOf(card, ".healthy-min", setting.healthy_min));
  setting.healthy_max = numberOrNull(valueOf(card, ".healthy-max", setting.healthy_max));
  setting.trend_direction = valueOf(card, ".trend-direction", setting.trend_direction);
  setting.time_column = valueOf(card, ".time-column", setting.time_column);
  setting.missing_strategy = valueOf(card, ".missing", setting.missing_strategy);
  persistDraft();
  if (!partial) renderMetricCards();
}

async function openReview() {
  const validation = validateBeforeRun();
  if (validation.length) return showValidation(validation);
  renderReview({ loading: true });
  unlock(5);
  showStep(5);
  try {
    const data = await api("/api/analysis/preview", {
      method: "POST",
      body: { upload_id: state.uploadId, config: buildConfig() }
    });
    renderReview({ preview: data });
  } catch (error) {
    renderReview({ errors: [error.message] });
  }
}

function renderReview({ loading = false, preview = null, errors = [] } = {}) {
  const config = buildConfig();
  const metrics = config.metrics;
  const totalWeight = metrics.reduce((sum, metric) => sum + Number(metric.weight || 1), 0);
  const metricRows = metrics.map(metric => `
    <tr>
      <td>${escapeHtml(metric.label)}</td>
      <td>${escapeHtml(typeLabels[metric.generic_type] || metric.generic_type)}</td>
      <td>${totalWeight ? Math.round((metric.weight / totalWeight) * 100) : 0}%</td>
    </tr>
  `).join("");
  const context = config.context_columns.map(item => item.label).join(", ") || "Nenhuma";
  const business = config.business_values.map(item => item.label).join(", ") || "Nenhum";
  byId("review").innerHTML = `
    <div class="cards">
      <div class="card"><strong>Clientes</strong><span>${preview?.entities_detected ?? "-"}</span></div>
      <div class="card"><strong>Abas utilizadas</strong><span>${preview?.sheets_used ?? Object.keys(config.entity_keys).length}</span></div>
      <div class="card"><strong>Indicadores</strong><span>${metrics.length}</span></div>
    </div>
    ${loading ? `<div class="box">Calculando resumo...</div>` : ""}
    ${errors.length ? `<div class="notice error">${errors.map(escapeHtml).join("<br>")}</div>` : ""}
    <div class="box">
      <h3>Resumo dos indicadores</h3>
      <table><thead><tr><th>Indicador</th><th>Regra</th><th>Peso</th></tr></thead><tbody>${metricRows}</tbody></table>
    </div>
    <div class="box">
      <p><strong>Informacoes exibidas:</strong> ${escapeHtml(context)}</p>
      <p><strong>Valor de negocio:</strong> ${escapeHtml(business)}</p>
    </div>
  `;
}

async function runAnalysis() {
  const validation = validateBeforeRun();
  if (validation.length) return showValidation(validation);
  try {
    const config = buildConfig();
    if (byId("save-template-checkbox").checked) {
      const templateName = byId("template-name").value.trim();
      if (!templateName) return toast("Informe um nome para salvar a configuracao.", "error");
      await api("/api/templates", { method: "POST", body: { id: templateName, config } });
      await loadTemplates();
    }
    const data = await api("/api/analysis/run", { method: "POST", body: { upload_id: state.uploadId, config } });
    state.analysisId = data.analysis_id;
    state.ranking = data.ranking || [];
    state.details = data.details || [];
    renderResults(data.summary);
    unlock(6);
    showStep(6);
    toast("Analise gerada.");
  } catch (error) {
    toast(error.message, "error");
  }
}

function renderResults(summary) {
  byId("xlsx-link").href = `/api/analysis/${state.analysisId}/export/xlsx`;
  byId("csv-link").href = `/api/analysis/${state.analysisId}/export/csv`;
  byId("report-link").href = `/api/analysis/${state.analysisId}/report`;
  const cards = [
    ["Clientes analisados", summary.clientes_analisados],
    ["Risco medio", summary.risco_medio],
    ["Clientes em atencao", summary.clientes_em_atencao],
    ["Alto risco", summary.clientes_em_alto_risco],
    ["Criticos", summary.clientes_criticos],
    ["Cobertura media", `${summary.cobertura_media}%`]
  ];
  byId("summary-cards").innerHTML = cards.map(([label, value]) => `<div class="card"><strong>${label}</strong><span>${value}</span></div>`).join("");
  const businessLabels = buildConfig().business_values.map(item => item.label);
  const columns = ["Posicao", "Entidade", "Score", "Faixa", "Cobertura", "Fatores", ...businessLabels];
  byId("ranking").innerHTML = `
    <table>
      <thead><tr>${columns.map(column => `<th>${columnLabel(column)}</th>`).join("")}</tr></thead>
      <tbody>
        ${state.ranking.map(row => `<tr data-entity="${escapeAttr(row.Entidade)}">${columns.map(column => rankingCell(row, column)).join("")}</tr>`).join("")}
      </tbody>
    </table>
  `;
  byId("ranking").querySelectorAll("tbody tr").forEach(row => {
    row.addEventListener("click", () => renderDetail(row.dataset.entity));
  });
}

function rankingCell(row, column) {
  const value = column === "Fatores"
    ? [row["Fator 1"], row["Fator 2"], row["Fator 3"]].filter(Boolean).join(", ")
    : column === "Cobertura" && row[column] !== null && row[column] !== undefined
      ? `${row[column]}%`
      : row[column];
  const klass = column === "Faixa" ? ` class="risk-${escapeAttr(row.Faixa)}"` : "";
  return `<td${klass}>${escapeHtml(value ?? "")}</td>`;
}

function renderDetail(entity) {
  const rows = state.details.filter(row => String(row.Entidade) === String(entity));
  const ranking = state.ranking.find(row => String(row.Entidade) === String(entity));
  const el = byId("detail");
  el.classList.remove("hidden");
  el.innerHTML = `
    <h3>Cliente ${escapeHtml(entity)}</h3>
    <div class="detail-grid">
      <div><strong>Score de Risco</strong><span>${ranking?.Score ?? ""} / 100</span></div>
      <div><strong>Faixa</strong><span>${escapeHtml(ranking?.Faixa ?? "")}</span></div>
      <div><strong>Cobertura</strong><span>${ranking?.Cobertura ?? ""}%</span></div>
    </div>
    <h4>Por que este cliente esta nesta posicao?</h4>
    <table>
      <thead><tr><th>Indicador</th><th>Valor</th><th>Interpretacao</th><th>Peso</th><th>Risco gerado</th><th>Contribuicao</th></tr></thead>
      <tbody>
        ${rows.map(row => `<tr><td>${escapeHtml(row.Metrica)}</td><td>${escapeHtml(row["Valor agregado"] ?? "")}</td><td>${escapeHtml(typeLabels[row.Regra] || row.Regra)}</td><td>${row["Peso normalizado"] !== null ? Math.round(row["Peso normalizado"] * 100) + "%" : row.Peso}</td><td>${row["Risco 0-1"] ?? ""}</td><td>${row.Contribuicao} pontos</td></tr>`).join("")}
      </tbody>
    </table>
  `;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
}

function confirmClients() {
  if (!state.mainSheet || !state.mainKey) return toast("Informe qual coluna identifica os clientes.", "error");
  state.entityKeys[state.mainSheet] = state.mainKey;
  unlock(3);
  showStep(3);
  if (!Object.keys(state.suggestions).length) suggestRelationships();
}

function confirmRelationships() {
  if (!state.entityKeys[state.mainSheet]) return toast("Informe qual coluna identifica os clientes.", "error");
  renderMetricEditor();
  renderMetricCards();
  unlock(4);
  showStep(4);
}

function buildConfig() {
  const config = {
    entity_label: "Cliente",
    main_sheet: state.mainSheet,
    entity_keys: { ...state.entityKeys },
    time_columns: {},
    context_columns: [],
    business_values: [],
    status_filters: [],
    metrics: []
  };
  Object.entries(state.columnSettings).forEach(([key, setting]) => {
    if (state.ignoredSheets.has(setting.sheet)) return;
    if (!config.entity_keys[setting.sheet]) return;
    if (setting.role === "TIME") config.time_columns[setting.sheet] = setting.column;
    if (setting.role === "CONTEXT") config.context_columns.push({ source_sheet: setting.sheet, source_column: setting.column, label: prettyName(setting.column), aggregation: "LATEST" });
    if (setting.role === "BUSINESS_VALUE") config.business_values.push({ source_sheet: setting.sheet, source_column: setting.column, label: prettyName(setting.column), aggregation: "LATEST" });
    if (setting.role === "STATUS_FILTER") {
      const allowed = (setting.allowed_values || "").split(",").map(value => value.trim()).filter(Boolean);
      config.status_filters.push({ source_sheet: setting.sheet, source_column: setting.column, allowed_values: allowed });
    }
    if (setting.role === "METRIC") {
      const metric = {
        source_sheet: setting.sheet,
        source_column: setting.column,
        label: prettyName(setting.column),
        generic_type: setting.generic_type,
        aggregation: setting.aggregation,
        weight: Number(setting.weight || 1),
        scale_mode: setting.scale_mode,
        scale_min: setting.scale_min,
        scale_max: setting.scale_max,
        missing_strategy: setting.missing_strategy,
        binary_mapping: {},
        category_mapping: {},
        healthy_min: setting.healthy_min,
        healthy_max: setting.healthy_max,
        trend_direction: setting.trend_direction,
        time_column: setting.time_column || config.time_columns[setting.sheet] || null
      };
      if (setting.mapping?.trim()) {
        const parsed = JSON.parse(setting.mapping);
        if (setting.generic_type === "BINARY_RISK") metric.binary_mapping = parsed;
        if (setting.generic_type === "CATEGORICAL_RISK") metric.category_mapping = parsed;
      }
      config.metrics.push(metric);
    }
  });
  return config;
}

function validateBeforeRun() {
  const errors = [];
  if (!state.uploadId) errors.push("Envie um arquivo CSV ou Excel.");
  if (!state.mainSheet || !state.mainKey) errors.push("Informe qual coluna identifica os clientes.");
  const metrics = selectedMetricSettings();
  if (!metrics.length) errors.push("Defina pelo menos um indicador de risco.");
  metrics.forEach(({ setting }) => {
    const name = prettyName(setting.column);
    if (setting.weight <= 0) errors.push(`${name}: informe uma importancia maior que zero.`);
    if (["BINARY_RISK", "CATEGORICAL_RISK"].includes(setting.generic_type) && !setting.mapping?.trim()) {
      errors.push(`${name}: informe o mapa de valores para esta regra.`);
    }
    if (setting.mapping?.trim()) {
      try {
        JSON.parse(setting.mapping);
      } catch {
        errors.push(`${name}: o mapa precisa ser um JSON valido, como {"Sim":1,"Nao":0}.`);
      }
    }
    if (setting.generic_type === "TARGET_RANGE" && (setting.healthy_min === null || setting.healthy_max === null)) {
      errors.push(`${name}: informe a faixa saudavel.`);
    }
    if (setting.generic_type === "TREND_RISK" && !setting.time_column && !timeRoleForSheet(setting.sheet)) {
      errors.push(`${name} foi configurado como mudanca ao longo do tempo, mas ainda nao sabemos qual coluna representa o periodo.`);
    }
    if (setting.scale_mode === "MANUAL" && (setting.scale_min === null || setting.scale_max === null)) {
      errors.push(`${name}: informe os limites da escala manual.`);
    }
  });
  return errors;
}

function showValidation(errors) {
  toast(errors[0], "error");
  if (state.currentStep === 5) {
    renderReview({ errors });
  }
}

function initColumnSettings() {
  state.columnSettings = {};
  Object.entries(state.profile || {}).forEach(([sheet, profile]) => {
    profile.columns.forEach(column => {
      const key = settingKey(sheet, column.name);
      state.columnSettings[key] = defaultSetting(sheet, column.name, column);
    });
  });
}

function defaultSetting(sheet, column, info = {}) {
  let role = "IGNORE";
  if (info.hints?.includes("possivel_periodo")) role = "TIME";
  return {
    sheet,
    column,
    role,
    generic_type: info.kind === "number" ? "HIGH_IS_RISK" : info.hints?.includes("binaria") ? "BINARY_RISK" : "CATEGORICAL_RISK",
    weight: 1,
    aggregation: sheetHasManyRows(sheet) ? "RECENT_MEAN" : "MEAN",
    scale_mode: "AUTO",
    scale_min: null,
    scale_max: null,
    missing_strategy: "IGNORE_AND_REWEIGHT",
    mapping: "",
    healthy_min: null,
    healthy_max: null,
    trend_direction: "UP_IS_RISK",
    time_column: suggestTimeColumn(sheet),
    allowed_values: ""
  };
}

function applyTemplate(template) {
  if (!state.profile) return;
  state.mainSheet = template.main_sheet || state.mainSheet;
  state.mainKey = template.entity_keys?.[state.mainSheet] || state.mainKey;
  state.entityKeys = { ...(template.entity_keys || state.entityKeys) };
  Object.entries(state.profile).forEach(([sheet, profile]) => {
    if (!state.entityKeys[sheet] && !profile.is_documentation) state.ignoredSheets.add(sheet);
  });
  Object.entries(template.time_columns || {}).forEach(([sheet, column]) => {
    if (state.columnSettings[settingKey(sheet, column)]) state.columnSettings[settingKey(sheet, column)].role = "TIME";
  });
  (template.context_columns || []).forEach(item => setRoleFromTemplate(item, "CONTEXT"));
  (template.business_values || []).forEach(item => setRoleFromTemplate(item, "BUSINESS_VALUE"));
  (template.status_filters || []).forEach(item => {
    const setting = setRoleFromTemplate(item, "STATUS_FILTER");
    if (setting) setting.allowed_values = (item.allowed_values || []).join(", ");
  });
  (template.metrics || []).forEach(metric => {
    const setting = setRoleFromTemplate(metric, "METRIC");
    if (!setting) return;
    Object.assign(setting, {
      generic_type: metric.generic_type || setting.generic_type,
      weight: metric.weight || 1,
      aggregation: metric.aggregation || setting.aggregation,
      scale_mode: metric.scale_mode || "AUTO",
      scale_min: metric.scale_min ?? null,
      scale_max: metric.scale_max ?? null,
      missing_strategy: metric.missing_strategy || "IGNORE_AND_REWEIGHT",
      mapping: JSON.stringify(metric.binary_mapping && Object.keys(metric.binary_mapping).length ? metric.binary_mapping : metric.category_mapping || {}),
      healthy_min: metric.healthy_min ?? null,
      healthy_max: metric.healthy_max ?? null,
      trend_direction: metric.trend_direction || "UP_IS_RISK",
      time_column: metric.time_column || suggestTimeColumn(metric.source_sheet)
    });
  });
  renderAll();
  persistDraft();
  toast("Configuracao aplicada. Revise apenas as diferencas.");
}

function setRoleFromTemplate(item, role) {
  const key = settingKey(item.source_sheet, item.source_column);
  const setting = state.columnSettings[key];
  if (setting) setting.role = role;
  return setting;
}

async function loadTemplates() {
  const select = byId("template-select");
  const data = await api("/api/templates");
  select.innerHTML = `<option value="">Nova analise</option>${(data.templates || []).map(t => option(t.id, t.filename, "")).join("")}`;
}

async function loadSelectedTemplate() {
  const id = byId("template-select").value;
  if (!id) return toast("Selecione uma configuracao salva.", "error");
  const data = await api(`/api/templates/${encodeURIComponent(id)}`);
  state.template = data.template;
  byId("template-status").textContent = "Configuracao carregada. Envie um arquivo ou confira a compatibilidade.";
  if (state.uploadId) {
    applyTemplate(state.template);
    const validation = await api(`/api/templates/${encodeURIComponent(id)}/validate`, { method: "POST", body: { upload_id: state.uploadId } });
    const expected = expectedColumns(state.template);
    const found = Math.max(0, expected - (validation.missing_columns?.length || 0));
    const percent = expected ? Math.round((found / expected) * 100) : 100;
    byId("template-status").textContent = `Encontramos ${percent}% das colunas esperadas. ${validation.status}.`;
  }
}

function ignoreAllColumns() {
  Object.values(state.columnSettings).forEach(setting => {
    if (!isEntityColumn(setting.sheet, setting.column)) setting.role = "IGNORE";
  });
  renderMetricEditor();
  renderMetricCards();
  persistDraft();
}

function equalWeights() {
  selectedMetricSettings().forEach(({ setting }) => {
    setting.weight = 1;
  });
  renderMetricCards();
  persistDraft();
}

function renderMode() {
  document.body.dataset.mode = state.mode;
  byId("simple-mode").classList.toggle("active", state.mode === "simple");
  byId("advanced-mode").classList.toggle("active", state.mode === "advanced");
}

function showStep(step) {
  state.currentStep = step;
  document.querySelectorAll(".panel").forEach(panel => panel.classList.remove("active"));
  byId(`step-${step}`).classList.add("active");
  renderSteps();
  persistDraft();
}

function unlock(step) {
  state.maxStep = Math.max(state.maxStep, step);
}

function persistDraft() {
  const saved = {
    currentStep: state.currentStep,
    maxStep: state.maxStep,
    mode: state.mode,
    selectedFileMeta: state.selectedFileMeta,
    ignoredSheets: Array.from(state.ignoredSheets),
    mainSheet: state.mainSheet,
    mainKey: state.mainKey,
    entityKeys: state.entityKeys,
    suggestions: state.suggestions,
    template: state.template,
    columnSettings: state.columnSettings,
    analysisId: state.analysisId
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
}

function restoreDraft() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const saved = JSON.parse(raw);
    Object.assign(state, saved);
    state.uploadId = null;
    state.fileName = "";
    state.profile = null;
    state.uploading = false;
    state.uploadError = "";
    state.currentStep = 1;
    state.maxStep = 1;
    state.ignoredSheets = new Set(saved.ignoredSheets || []);
  } catch {
    localStorage.removeItem(STORAGE_KEY);
  }
}

function selectedMetricSettings() {
  return Object.entries(state.columnSettings)
    .filter(([, setting]) => setting.role === "METRIC" && !state.ignoredSheets.has(setting.sheet))
    .map(([key, setting]) => ({ key, setting, sheet: setting.sheet, column: setting.column }));
}

function normalizedWeights(items) {
  const total = items.reduce((sum, item) => sum + Number(item.setting.weight || 1), 0);
  const result = {};
  items.forEach(item => {
    result[item.key] = total ? (Number(item.setting.weight || 1) / total) * 100 : 0;
  });
  return result;
}

function analyticSheetNames() {
  return Object.entries(state.profile || {}).filter(([, profile]) => !profile.is_documentation).map(([sheet]) => sheet);
}

function documentationSheets() {
  return Object.entries(state.profile || {}).filter(([, profile]) => profile.is_documentation).map(([sheet]) => sheet);
}

function estimatePossibleClients() {
  const candidates = analyticSheetNames().flatMap(sheet => columnsFor(sheet).map(column => columnInfo(sheet, column)));
  const ids = candidates.filter(info => info?.hints?.includes("possivel_identificador"));
  const source = ids.length ? ids : candidates;
  return source.reduce((max, info) => Math.max(max, info?.unique_count || 0), 0);
}

function suggestMainSheet() {
  return analyticSheetNames()
    .map(sheet => ({ sheet, profile: state.profile[sheet], key: suggestKeyForSheet(sheet) }))
    .filter(item => item.key)
    .sort((a, b) => {
      const au = columnInfo(a.sheet, a.key)?.unique_count || 0;
      const bu = columnInfo(b.sheet, b.key)?.unique_count || 0;
      const ar = a.profile.rows || 1;
      const br = b.profile.rows || 1;
      return Math.abs(1 - bu / br) - Math.abs(1 - au / ar);
    })[0]?.sheet || "";
}

function suggestKeyForSheet(sheet) {
  const columns = (state.profile?.[sheet]?.columns || []);
  const idLike = columns.filter(column => column.hints?.includes("possivel_identificador"));
  const sorted = (idLike.length ? idLike : columns).slice().sort((a, b) => {
    const ar = state.profile[sheet]?.rows || 1;
    const br = state.profile[sheet]?.rows || 1;
    return Math.abs(1 - b.unique_count / br) - Math.abs(1 - a.unique_count / ar);
  });
  return sorted[0]?.name || "";
}

function suggestTimeColumn(sheet) {
  return (state.profile?.[sheet]?.columns || []).find(column => column.hints?.includes("possivel_periodo") || column.kind === "date")?.name || "";
}

function bestSuggestion(sheet) {
  const items = state.suggestions[sheet] || [];
  return items[0] || null;
}

function suggestionForColumn(info) {
  if (!info) return "";
  if (info.hints?.includes("possivel_periodo")) return "Parece ser data ou periodo.";
  if (info.hints?.includes("possivel_identificador")) return "Parece identificar clientes.";
  if (info.hints?.includes("binaria")) return "Parece ter dois estados.";
  if (info.hints?.includes("categorica")) return "Parece categorica.";
  if (info.hints?.includes("numerica")) return "Parece numerica.";
  return "";
}

function needsTime(setting) {
  return ["LATEST", "RECENT_MEAN"].includes(setting.aggregation) || setting.generic_type === "TREND_RISK";
}

function sheetHasManyRows(sheet) {
  const key = state.entityKeys[sheet] || suggestKeyForSheet(sheet);
  const info = columnInfo(sheet, key);
  const rows = state.profile?.[sheet]?.rows || 0;
  return info ? rows > info.unique_count : false;
}

function timeRoleForSheet(sheet) {
  return Object.values(state.columnSettings).find(setting => setting.sheet === sheet && setting.role === "TIME")?.column || "";
}

function isEntityColumn(sheet, column) {
  return state.entityKeys[sheet] === column || (sheet === state.mainSheet && state.mainKey === column);
}

function settingFor(sheet, column) {
  const key = settingKey(sheet, column);
  if (!state.columnSettings[key]) state.columnSettings[key] = defaultSetting(sheet, column, columnInfo(sheet, column));
  return state.columnSettings[key];
}

function settingKey(sheet, column) {
  return `${sheet}|||${column}`;
}

function columnInfo(sheet, column) {
  return state.profile?.[sheet]?.columns?.find(item => item.name === column);
}

function columnsFor(sheet) {
  return state.profile?.[sheet]?.columns?.map(column => column.name) || [];
}

function firstSheet() {
  return analyticSheetNames()[0] || Object.keys(state.profile || {})[0] || "";
}

function firstColumn(sheet) {
  return columnsFor(sheet)[0] || "";
}

function prettyName(value) {
  return String(value || "")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, char => char.toUpperCase());
}

function expectedColumns(template) {
  const set = new Set();
  Object.entries(template.entity_keys || {}).forEach(([sheet, column]) => set.add(`${sheet}.${column}`));
  (template.metrics || []).forEach(item => set.add(`${item.source_sheet}.${item.source_column}`));
  (template.context_columns || []).forEach(item => set.add(`${item.source_sheet}.${item.source_column}`));
  (template.business_values || []).forEach(item => set.add(`${item.source_sheet}.${item.source_column}`));
  return set.size;
}

async function api(path, options = {}) {
  const init = { method: options.method || "GET", headers: {} };
  if (options.body) {
    init.headers["Content-Type"] = "application/json";
    init.body = JSON.stringify(options.body);
  }
  const response = await fetch(path, init);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || (data.errors || []).join("\n") || "Erro na requisicao.");
  return data;
}

async function safeJson(response) {
  const text = await response.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    return { error: text };
  }
}

function errorMessage(payload, fallback) {
  if (payload?.error?.message) return payload.error.message;
  if (payload?.error) return String(payload.error);
  if (payload?.errors?.length) return payload.errors.join("\n");
  return fallback;
}

function valueOf(root, selector, fallback = "") {
  const el = root.querySelector(selector);
  return el ? el.value : fallback;
}

function checkedValue(root, selector, fallback = "") {
  const el = root.querySelector(`${selector}:checked`);
  return el ? el.value : fallback;
}

function numberOrNull(value) {
  return value === "" || value === null || value === undefined ? null : Number(value);
}

function fileTypeLabel(filename) {
  return /\.xlsx$/i.test(filename) ? "Excel" : /\.csv$/i.test(filename) ? "CSV" : "Desconhecido";
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return "-";
  const mb = bytes / (1024 * 1024);
  if (mb >= 0.1) return `${mb.toFixed(2)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function byId(id) {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Elemento ausente: ${id}`);
  return element;
}

function option(value, label, selected) {
  return `<option value="${escapeAttr(value)}" ${value === selected ? "selected" : ""}>${escapeHtml(label)}</option>`;
}

function missingLabel(value) {
  return {
    IGNORE_AND_REWEIGHT: "Usar apenas os outros indicadores",
    NEUTRAL: "Neutro",
    RISK: "Considerar risco",
    HEALTHY: "Considerar saudavel",
    CUSTOM: "Valor personalizado"
  }[value] || value;
}

function columnLabel(column) {
  return {
    Posicao: "Posicao",
    Entidade: "Cliente",
    Score: "Score",
    Faixa: "Faixa",
    Cobertura: "Cobertura",
    Fatores: "Principais fatores"
  }[column] || column;
}

function hintIcon(text) {
  return `<span class="help-icon" title="${escapeAttr(text)}">?</span>`;
}

function toast(message, type = "ok") {
  const el = byId("toast");
  el.textContent = message;
  el.className = `show ${type}`;
  setTimeout(() => { el.className = ""; }, 3600);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[ch]));
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}
