import pandas as pd

from core.entity_metric_builder import build_entity_metrics
from core.generic_risk_engine import run_generic_analysis
from core.generic_schema import AnalysisConfig, MetricConfig
from core.relationship_detector import suggest_relationships


def test_one_sheet_pipeline():
    sheets = {"base": pd.DataFrame({"id": ["A", "B"], "risco": [1, 9]})}
    config = AnalysisConfig(
        entity_keys={"base": "id"},
        metrics=[MetricConfig("base", "risco", "risco", "HIGH_IS_RISK", scale_mode="MANUAL", scale_min=0, scale_max=10)],
    )
    consolidated, _ = build_entity_metrics(sheets, config)
    assert len(consolidated) == 2
    result = run_generic_analysis(consolidated, config)
    assert result["ranking"][0]["Entidade"] == "B"


def test_different_key_names_and_no_raw_multiplication():
    sheets = {
        "A": pd.DataFrame({"cliente_id": ["C1", "C1", "C1", "C2", "C2", "C2"], "x": [1, 2, 3, 4, 5, 6]}),
        "B": pd.DataFrame({"codigo_cliente": ["C1", "C1", "C1", "C1", "C2", "C2", "C2", "C2"], "y": [10, 20, 30, 40, 1, 2, 3, 4]}),
    }
    config = AnalysisConfig(
        entity_keys={"A": "cliente_id", "B": "codigo_cliente"},
        metrics=[
            MetricConfig("A", "x", "x", "HIGH_IS_RISK", aggregation="MEAN"),
            MetricConfig("B", "y", "y", "HIGH_IS_RISK", aggregation="SUM"),
        ],
    )
    consolidated, metadata = build_entity_metrics(sheets, config)
    assert len(consolidated) == 2
    assert metadata["sheet_rows_after_aggregation"] == {"A": 2, "B": 2}
    assert set(consolidated["canonical_entity_id"]) == {"C1", "C2"}


def test_five_sheets_and_unrelated_sheet_is_ignored():
    sheets = {
        "s1": pd.DataFrame({"id": ["A", "B"], "m1": [1, 2]}),
        "s2": pd.DataFrame({"account": ["A", "B"], "m2": [3, 4]}),
        "s3": pd.DataFrame({"code": ["A", "B"], "m3": [5, 6]}),
        "s4": pd.DataFrame({"ref": ["A", "B"], "m4": [7, 8]}),
        "s5": pd.DataFrame({"client": ["A", "B"], "m5": [9, 10]}),
        "nao_relacionada": pd.DataFrame({"outro": ["X", "Y"], "m": [1, 2]}),
    }
    config = AnalysisConfig(
        entity_keys={"s1": "id", "s2": "account", "s3": "code", "s4": "ref", "s5": "client"},
        metrics=[
            MetricConfig("s1", "m1", "m1", "HIGH_IS_RISK"),
            MetricConfig("s2", "m2", "m2", "HIGH_IS_RISK"),
            MetricConfig("s3", "m3", "m3", "HIGH_IS_RISK"),
            MetricConfig("s4", "m4", "m4", "HIGH_IS_RISK"),
            MetricConfig("s5", "m5", "m5", "HIGH_IS_RISK"),
        ],
    )
    consolidated, metadata = build_entity_metrics(sheets, config)
    assert len(consolidated) == 2
    assert metadata["ignored_sheets"][0]["sheet"] == "nao_relacionada"


def test_relationship_detector_suggests_high_overlap_but_does_not_apply():
    sheets = {
        "clientes": pd.DataFrame({"cliente_id": ["C001", "C002", "C003"]}),
        "financeiro": pd.DataFrame({"codigo_cliente": ["C001", "C002", "C003"]}),
    }
    suggestions = suggest_relationships(sheets, "clientes", "cliente_id")
    best = suggestions["financeiro"][0]
    assert best["column"] == "codigo_cliente"
    assert best["relation_score"] >= 80


def test_same_engine_processes_different_domains():
    config_a = AnalysisConfig(
        entity_keys={"clientes": "cliente_id"},
        metrics=[MetricConfig("clientes", "nps", "nps", "LOW_IS_RISK", scale_mode="MANUAL", scale_min=0, scale_max=10)],
    )
    config_b = AnalysisConfig(
        entity_keys={"membros": "matricula"},
        metrics=[MetricConfig("membros", "visitas", "visitas", "LOW_IS_RISK", scale_mode="MANUAL", scale_min=0, scale_max=20)],
    )
    consolidated_a, _ = build_entity_metrics({"clientes": pd.DataFrame({"cliente_id": ["C1"], "nps": [3]})}, config_a)
    consolidated_b, _ = build_entity_metrics({"membros": pd.DataFrame({"matricula": ["A1"], "visitas": [3]})}, config_b)
    assert run_generic_analysis(consolidated_a, config_a)["ranking"][0]["Score"] == 70
    assert run_generic_analysis(consolidated_b, config_b)["ranking"][0]["Score"] == 85
