import math

import pandas as pd

from core.generic_risk_engine import (
    calculate_contributions,
    calculate_coverage,
    calculate_score,
    calculate_trend_risk,
    normalize_binary_risk,
    normalize_categorical_risk,
    normalize_high_is_risk,
    normalize_low_is_risk,
    normalize_target_range,
    normalize_weights,
    run_generic_analysis,
)
from core.generic_schema import AnalysisConfig, MetricConfig


def test_numeric_normalizers():
    assert normalize_high_is_risk(75, 0, 100) == 0.75
    assert normalize_high_is_risk(150, 0, 100) == 1
    assert normalize_low_is_risk(25, 0, 100) == 0.75


def test_binary_and_categorical_normalizers():
    assert normalize_binary_risk("Sim", {"Sim": 1, "Nao": 0}) == 1
    assert normalize_categorical_risk("B", {"A": 0, "B": 0.5, "C": 1}) == 0.5


def test_target_range_normalizer():
    assert normalize_target_range(50, 40, 60, 0, 100) == 0
    assert normalize_target_range(20, 40, 60, 0, 100) == 0.5
    assert normalize_target_range(80, 40, 60, 0, 100) == 0.5


def test_trend_risk_up_and_down():
    up = calculate_trend_risk(pd.Series([-5, 0, 10]), "UP_IS_RISK")
    down = calculate_trend_risk(pd.Series([-5, 0, 10]), "DOWN_IS_RISK")
    assert list(up.round(2)) == [0, 0, 1]
    assert list(down.round(2)) == [1, 0, 0]


def test_weights_coverage_score_and_contributions():
    metrics = [
        MetricConfig("s", "a", "A", "HIGH_IS_RISK", weight=3),
        MetricConfig("s", "b", "B", "LOW_IS_RISK", weight=1),
    ]
    weights = normalize_weights(metrics)
    assert weights == {"A": 0.75, "B": 0.25}
    assert calculate_coverage(3, 4) == 75
    assert calculate_score(2, 4) == 50
    contributions = calculate_contributions({"A": 0.8, "B": 0.4}, weights)
    assert math.isclose(contributions["A"]["contribution_points"], 60)
    assert math.isclose(contributions["B"]["contribution_points"], 10)


def test_missing_ignore_and_reweight_reconstructs_score():
    df = pd.DataFrame(
        {
            "canonical_entity_id": ["C1", "C2"],
            "metric__s_a": [100, 50],
            "metric__s_b": [pd.NA, 0],
        }
    )
    config = AnalysisConfig(
        entity_keys={"s": "id"},
        metrics=[
            MetricConfig("s", "a", "A", "HIGH_IS_RISK", weight=1, scale_mode="MANUAL", scale_min=0, scale_max=100),
            MetricConfig("s", "b", "B", "HIGH_IS_RISK", weight=1, scale_mode="MANUAL", scale_min=0, scale_max=100),
        ],
    )
    result = run_generic_analysis(df, config)
    c1 = next(row for row in result["ranking"] if row["Entidade"] == "C1")
    assert c1["Score"] == 100
    assert c1["Cobertura"] == 50
    for row in result["ranking"]:
        total = sum(item["contribution_points"] for item in row["Contribuicoes"].values())
        assert math.isclose(total, row["Score"], abs_tol=0.01)
