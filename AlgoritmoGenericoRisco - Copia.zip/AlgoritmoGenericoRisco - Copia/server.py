from __future__ import annotations

import json
import logging
import mimetypes
import re
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from config import EXPORT_DIR, MAX_UPLOAD_SIZE, TEMPLATE_DIR, UPLOAD_DIR, WEB_DIR
from core.data_loader import ALLOWED_EXTENSIONS, load_workbook, sanitize_filename
from core.data_profiler import profile_sheets
from core.entity_metric_builder import build_entity_metrics
from core.export_engine import export_csv, export_xlsx
from core.generic_risk_engine import normalize_weights, run_generic_analysis
from core.generic_schema import analysis_config_from_dict, validate_analysis_config
from core.relationship_detector import suggest_relationships
from core.report_engine import build_printable_report
from core.template_engine import list_templates, load_template, save_template, validate_template


UPLOADS = {}
ANALYSES = {}


class RiskAnalysisHandler(BaseHTTPRequestHandler):
    server_version = "RiskAnalysis/0.1"

    def do_GET(self):
        try:
            parsed = urlparse(self.path)
            path = unquote(parsed.path)
            if path == "/api/health":
                return self._json({"ok": True, "service": "Risk Analysis"})
            if path.startswith("/api/files/") and path.endswith("/profile"):
                upload_id = path.split("/")[3]
                return self._profile(upload_id)
            if path == "/api/templates":
                return self._json({"templates": list_templates(TEMPLATE_DIR)})
            if path.startswith("/api/templates/"):
                template_id = path.split("/")[3]
                return self._json({"template": load_template(TEMPLATE_DIR, template_id)})
            if path.startswith("/api/analysis/"):
                parts = path.strip("/").split("/")
                if len(parts) == 3:
                    return self._analysis(parts[2])
                if len(parts) == 5 and parts[3] == "export":
                    return self._download_export(parts[2], parts[4])
                if len(parts) == 4 and parts[3] == "report":
                    return self._report(parts[2])
            return self._static(path)
        except Exception as exc:
            return self._error(exc)

    def do_POST(self):
        try:
            parsed = urlparse(self.path)
            path = unquote(parsed.path)
            if path == "/api/files/upload":
                return self._upload()
            if path == "/api/relationships/suggest":
                payload = self._read_json()
                return self._relationship_suggest(payload)
            if path == "/api/analysis/preview":
                payload = self._read_json()
                return self._analysis_preview(payload)
            if path == "/api/analysis/run":
                payload = self._read_json()
                return self._analysis_run(payload)
            if path == "/api/templates":
                payload = self._read_json()
                template_id = payload.get("id") or payload.get("name") or "template"
                return self._json({"template": save_template(TEMPLATE_DIR, template_id, payload.get("config", {}))})
            if path.startswith("/api/templates/") and path.endswith("/validate"):
                payload = self._read_json()
                template_id = path.split("/")[3]
                template = load_template(TEMPLATE_DIR, template_id)
                profile = payload.get("profile") or self._profile_data(payload.get("upload_id"))
                return self._json(validate_template(template, profile))
            return self._json({"error": "Endpoint nao encontrado."}, HTTPStatus.NOT_FOUND)
        except Exception as exc:
            return self._error(exc)

    def _upload(self):
        raw_length = self.headers.get("Content-Length")
        if raw_length is None:
            return self._json({"error": "Content-Length ausente."}, HTTPStatus.LENGTH_REQUIRED)
        try:
            length = int(raw_length)
        except ValueError:
            return self._json({"error": "Content-Length invalido."}, HTTPStatus.BAD_REQUEST)
        if length <= 0:
            return self._json({"error": "Arquivo vazio ou requisicao sem conteudo."}, HTTPStatus.BAD_REQUEST)
        if length > MAX_UPLOAD_SIZE:
            return self._json({"error": "Arquivo maior que 50 MB."}, HTTPStatus.REQUEST_ENTITY_TOO_LARGE)

        logging.info("upload recebido: content_length=%s", length)
        content_type = self.headers.get("Content-Type", "")
        upload = _parse_multipart_file(self.rfile.read(length), content_type)
        if upload is None:
            return self._json({"error": "Envie o campo file."}, HTTPStatus.BAD_REQUEST)

        filename = sanitize_filename(Path(upload["filename"] or "arquivo").name)
        suffix = Path(filename).suffix.lower()
        if suffix not in ALLOWED_EXTENSIONS:
            return self._json({"error": "Formato nao suportado. Envie CSV ou XLSX."}, HTTPStatus.BAD_REQUEST)

        upload_id = uuid.uuid4().hex
        path = UPLOAD_DIR / f"{upload_id}{suffix}"
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        with path.open("wb") as destination:
            destination.write(upload["content"])
        logging.info("arquivo salvo: filename=%s upload_id=%s bytes=%s", filename, upload_id, len(upload["content"]))

        sheets = load_workbook(path)
        UPLOADS[upload_id] = {"path": path, "filename": filename}
        logging.info("upload_id gerado: %s", upload_id)
        return self._json(
            {
                "success": True,
                "upload_id": upload_id,
                "filename": filename,
                "profile": profile_sheets(sheets),
            }
        )

    def _profile(self, upload_id: str):
        return self._json({"profile": self._profile_data(upload_id)})

    def _profile_data(self, upload_id: str):
        upload = self._require_upload(upload_id)
        return profile_sheets(load_workbook(upload["path"]))

    def _relationship_suggest(self, payload: dict):
        upload = self._require_upload(payload.get("upload_id"))
        sheets = load_workbook(upload["path"])
        suggestions = suggest_relationships(
            sheets,
            payload.get("main_sheet"),
            payload.get("main_key"),
        )
        return self._json({"suggestions": suggestions})

    def _analysis_preview(self, payload: dict):
        upload = self._require_upload(payload.get("upload_id"))
        config = analysis_config_from_dict(payload.get("config", {}))
        errors = validate_analysis_config(config)
        sheets = load_workbook(upload["path"])
        consolidated, metadata = build_entity_metrics(sheets, config) if not errors else (None, {})
        weights = normalize_weights(config.metrics)
        return self._json(
            {
                "errors": errors,
                "entities_detected": 0 if consolidated is None else int(len(consolidated)),
                "sheets_used": len(config.entity_keys),
                "risk_metrics": len([m for m in config.metrics if m.generic_type != "INFORMATIONAL"]),
                "normalized_weights": {key: round(value * 100, 2) for key, value in weights.items()},
                "metadata": metadata,
            }
        )

    def _analysis_run(self, payload: dict):
        upload = self._require_upload(payload.get("upload_id"))
        config = analysis_config_from_dict(payload.get("config", {}))
        errors = validate_analysis_config(config)
        if errors:
            return self._json({"errors": errors}, HTTPStatus.BAD_REQUEST)

        sheets = load_workbook(upload["path"])
        consolidated, metadata = build_entity_metrics(sheets, config)
        result = run_generic_analysis(consolidated, config)
        analysis_id = uuid.uuid4().hex
        summary = _summary(result)

        xlsx_path = EXPORT_DIR / f"{analysis_id}_analise_risco.xlsx"
        csv_path = EXPORT_DIR / f"{analysis_id}_ranking.csv"
        report_path = EXPORT_DIR / f"{analysis_id}_relatorio.html"
        export_xlsx(result, consolidated, xlsx_path)
        export_csv(result, csv_path)
        report_path.write_text(build_printable_report(result, summary), encoding="utf-8")

        ANALYSES[analysis_id] = {
            "result": result,
            "summary": summary,
            "metadata": metadata,
            "xlsx": xlsx_path,
            "csv": csv_path,
            "report": report_path,
        }
        return self._json(
            {
                "analysis_id": analysis_id,
                "summary": summary,
                "ranking": result["ranking"],
                "details": result["details"],
                "metadata": metadata,
                "methodology": result["methodology"],
            }
        )

    def _analysis(self, analysis_id: str):
        analysis = self._require_analysis(analysis_id)
        return self._json(
            {
                "analysis_id": analysis_id,
                "summary": analysis["summary"],
                "ranking": analysis["result"]["ranking"],
                "details": analysis["result"]["details"],
                "metadata": analysis["metadata"],
                "methodology": analysis["result"]["methodology"],
            }
        )

    def _download_export(self, analysis_id: str, kind: str):
        analysis = self._require_analysis(analysis_id)
        if kind == "xlsx":
            return self._send_file(analysis["xlsx"], "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        if kind == "csv":
            return self._send_file(analysis["csv"], "text/csv; charset=utf-8")
        return self._json({"error": "Exportacao nao encontrada."}, HTTPStatus.NOT_FOUND)

    def _report(self, analysis_id: str):
        analysis = self._require_analysis(analysis_id)
        return self._send_file(analysis["report"], "text/html; charset=utf-8", inline=True)

    def _static(self, path: str):
        if path in ("", "/"):
            path = "/index.html"
        candidate = (WEB_DIR / path.lstrip("/")).resolve()
        web_root = WEB_DIR.resolve()
        if not str(candidate).startswith(str(web_root)) or not candidate.exists() or not candidate.is_file():
            return self._json({"error": "Arquivo nao encontrado."}, HTTPStatus.NOT_FOUND)
        content_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
        return self._send_file(candidate, content_type, inline=True)

    def _require_upload(self, upload_id: str):
        if not upload_id or upload_id not in UPLOADS:
            raise ValueError("Upload nao encontrado.")
        return UPLOADS[upload_id]

    def _require_analysis(self, analysis_id: str):
        if not analysis_id or analysis_id not in ANALYSES:
            raise ValueError("Analise nao encontrada nesta sessao.")
        return ANALYSES[analysis_id]

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8") or "{}")

    def _json(self, payload: dict, status: HTTPStatus = HTTPStatus.OK):
        body = json.dumps(_json_safe(payload), ensure_ascii=False).encode("utf-8")
        self.send_response(status.value)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path, content_type: str, inline: bool = False):
        body = path.read_bytes()
        self.send_response(HTTPStatus.OK.value)
        self.send_header("Content-Type", content_type)
        disposition = "inline" if inline else "attachment"
        self.send_header("Content-Disposition", f'{disposition}; filename="{path.name}"')
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _error(self, exc: Exception):
        status = HTTPStatus.BAD_REQUEST if isinstance(exc, ValueError) else HTTPStatus.INTERNAL_SERVER_ERROR
        return self._json({"error": str(exc)}, status)

    def log_message(self, format, *args):
        print("%s - - %s" % (self.address_string(), format % args))


def _summary(result: dict) -> dict:
    ranking = result.get("ranking", [])
    scores = [row["Score"] for row in ranking if row.get("Score") is not None]
    coverages = [row["Cobertura"] for row in ranking if row.get("Cobertura") is not None]
    return {
        "clientes_analisados": len(ranking),
        "risco_medio": round(sum(scores) / len(scores), 2) if scores else 0,
        "clientes_em_atencao": len([row for row in ranking if row.get("Faixa") == "Atencao"]),
        "clientes_em_alto_risco": len([row for row in ranking if row.get("Faixa") == "Alto"]),
        "clientes_criticos": len([row for row in ranking if row.get("Faixa") == "Critico"]),
        "cobertura_media": round(sum(coverages) / len(coverages), 2) if coverages else 0,
    }


def _json_safe(value):
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_safe(item) for item in value]
    if hasattr(value, "item"):
        return _json_safe(value.item())
    if str(value) == "nan":
        return None
    return value


def _parse_multipart_file(body: bytes, content_type: str):
    match = re.search(r'boundary="?([^";]+)"?', content_type)
    if not match:
        return None
    boundary = ("--" + match.group(1)).encode("utf-8")
    for part in body.split(boundary):
        if b'name="file"' not in part:
            continue
        if b"\r\n\r\n" not in part:
            continue
        raw_headers, content = part.split(b"\r\n\r\n", 1)
        header_text = raw_headers.decode("utf-8", errors="replace")
        filename_match = re.search(r'filename="([^"]*)"', header_text)
        filename = filename_match.group(1) if filename_match else "arquivo"
        content = content.rstrip(b"\r\n")
        if content.endswith(b"--"):
            content = content[:-2].rstrip(b"\r\n")
        return {"filename": filename, "content": content}
    return None


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    for directory in [UPLOAD_DIR, EXPORT_DIR, TEMPLATE_DIR]:
        directory.mkdir(parents=True, exist_ok=True)
    address = ("127.0.0.1", 8000)
    server = ThreadingHTTPServer(address, RiskAnalysisHandler)
    print("Risk Analysis rodando em http://127.0.0.1:8000")
    server.serve_forever()


if __name__ == "__main__":
    main()
