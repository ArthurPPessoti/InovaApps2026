from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from config import AUTO_SCALE_SMALL_SAMPLE, MIN_COVERAGE_FOR_RANKING, RISK_BANDS
from .generic_schema import (
    AnalysisConfig,
    MetricConfig,
    analysis_config_to_dict,
    business_value_output_column,
    context_output_column,
    metric_output_column,
)


def clamp(value, minimum: float = 0.0, maximum: float = 1.0):
    if pd.isna(value):
        return np.nan
    return float(max(minimum, min(maximum, value)))


def normalize_high_is_risk(x, scale_min: float, scale_max: float):
    if pd.isna(x) or scale_max == scale_min:
        return np.nan
    return clamp((float(x) - scale_min) / (scale_max - scale_min))


def normalize_low_is_risk(x, scale_min: float, scale_max: float):
    value = normalize_high_is_risk(x, scale_min, scale_max)
    if pd.isna(value):
        return np.nan
    return clamp(1 - value)


def normalize_binary_risk(x, value_risk_map: Dict[str, float]):
    if pd.isna(x):
        return np.nan
    key = str(x)
    if key not in value_risk_map:
        return np.nan
    return clamp(float(value_risk_map[key]))


def normalize_categorical_risk(x, category_risk_map: Dict[str, float]):
    return normalize_binary_risk(x, category_risk_map)


def normalize_target_range(
    x,
    healthy_min: float,
    healthy_max: float,
    scale_min: float,
    scale_max: float,
):
    if pd.isna(x):
        return np.nan
    x = float(x)
    if healthy_min <= x <= healthy_max:
        return 0.0
    if x < healthy_min:
        denominator = healthy_min - scale_min
        if denominator <= 0:
            return 1.0
        return clamp((healthy_min - x) / denominator)
    denominator = scale_max - healthy_max
    if denominator <= 0:
        return 1.0
    return clamp((x - healthy_max) / denominator)


def _robust_scale(values: pd.Series) -> Tuple[Optional[float], Optional[float], str, bool]:
    clean = pd.to_numeric(values, errors="coerce").dropna()
    if len(clean) == 0:
        return None, None, "AUTO_DYNAMIC:sem_dados", False
    if len(clean) < AUTO_SCALE_SMALL_SAMPLE:
        scale_min = float(clean.min())
        scale_max = float(clean.max())
        source = "AUTO_DYNAMIC:min_max"
    else:
        scale_min = float(clean.quantile(0.05))
        scale_max = float(clean.quantile(0.95))
        source = "AUTO_DYNAMIC:p5_p95"
    return scale_min, scale_max, source, scale_min == scale_max


def _resolve_scale(values: pd.Series, metric: MetricConfig) -> Tuple[Optional[float], Optional[float], str, bool]:
    if metric.scale_mode == "MANUAL":
        scale_min = float(metric.scale_min)
        scale_max = float(metric.scale_max)
        return scale_min, scale_max, "MANUAL", scale_min == scale_max
    if metric.scale_mode == "FIXED":
        fixed_min = metric.resolved_scale_min if metric.resolved_scale_min is not None else metric.scale_min
        fixed_max = metric.resolved_scale_max if metric.resolved_scale_max is not None else metric.scale_max
        scale_min = float(fixed_min)
        scale_max = float(fixed_max)
        return scale_min, scale_max, "FIXED", scale_min == scale_max
    return _robust_scale(values)


def calculate_trend_risk(deltas: Iterable, trend_direction: str) -> pd.Series:
    risk, _meta = _trend_risk_with_meta(pd.Series(deltas), trend_direction)
    return risk


def _trend_risk_with_meta(deltas: Iterable, trend_direction: str) -> Tuple[pd.Series, dict]:
    series = pd.to_numeric(pd.Series(deltas), errors="coerce")
    signal = series if trend_direction == "UP_IS_RISK" else -series
    signal = signal.clip(lower=0)
    scale_min, scale_max, source, non_discriminant = _robust_scale(signal)
    meta = {
        "trend_direction": trend_direction,
        "scale_min": scale_min,
        "scale_max": scale_max,
        "scale_source": source,
        "non_discriminant": non_discriminant,
    }
    if scale_min is None or scale_max is None or non_discriminant:
        return pd.Series([np.nan] * len(series), index=series.index), meta
    return signal.apply(lambda value: normalize_high_is_risk(value, scale_min, scale_max)), meta


def normalize_weights(metrics: List[MetricConfig]) -> Dict[str, float]:
    scoring_metrics = [m for m in metrics if m.generic_type != "INFORMATIONAL"]
    total = sum(float(metric.weight or 1) for metric in scoring_metrics)
    if total <= 0:
        return {}
    return {metric.label: float(metric.weight or 1) / total for metric in scoring_metrics}


def calculate_coverage(observed_weight_sum: float, configured_weight_sum: float) -> float:
    if configured_weight_sum <= 0:
        return 0.0
    return 100 * observed_weight_sum / configured_weight_sum


def calculate_score(weighted_sum: float, available_weight_sum: float) -> float:
    if available_weight_sum <= 0:
        return np.nan
    return 100 * weighted_sum / available_weight_sum


def calculate_contributions(risks: Dict[str, float], weights: Dict[str, float]) -> Dict[str, dict]:
    available = {
        label: risk
        for label, risk in risks.items()
        if label in weights and pd.notna(risk)
    }
    available_weight_sum = sum(weights[label] for label in available)
    contributions = {}
    for label, risk in available.items():
        normalized_weight = weights[label] / available_weight_sum if available_weight_sum else 0
        contributions[label] = {
            "metric_risk": float(risk),
            "normalized_weight": float(normalized_weight),
            "contribution_points": float(risk * normalized_weight * 100),
        }
    return contributions


def _band(score: Optional[float]) -> str:
    if pd.isna(score):
        return "Sem score"
    rounded = round(float(score))
    for band in RISK_BANDS:
        if band["min"] <= rounded <= band["max"]:
            return band["label"]
    return RISK_BANDS[-1]["label"]


def _missing_value_for_strategy(metric: MetricConfig):
    if metric.missing_strategy == "NEUTRAL":
        return 0.5
    if metric.missing_strategy == "RISK":
        return 1.0
    if metric.missing_strategy == "HEALTHY":
        return 0.0
    if metric.missing_strategy == "CUSTOM":
        return clamp(metric.missing_custom_value if metric.missing_custom_value is not None else 0.5)
    return np.nan


def _scale_label(meta: dict) -> str:
    scale_min = meta.get("scale_min")
    scale_max = meta.get("scale_max")
    source = meta.get("scale_source")
    if scale_min is None or scale_max is None:
        return str(source or "")
    return f"{source}: {scale_min} a {scale_max}"


def _already_mapped_risk(values: pd.Series) -> bool:
    numeric = pd.to_numeric(values, errors="coerce").dropna()
    return len(numeric) > 0 and ((numeric >= 0) & (numeric <= 1)).all()


def _risk_series_for_metric(consolidated: pd.DataFrame, metric: MetricConfig) -> Tuple[pd.Series, dict]:
    column = metric_output_column(metric)
    if column not in consolidated.columns:
        return pd.Series([np.nan] * len(consolidated), index=consolidated.index), {}

    values = consolidated[column]
    numeric_values = pd.to_numeric(values, errors="coerce")
    if metric.generic_type in {"HIGH_IS_RISK", "LOW_IS_RISK", "TARGET_RANGE"}:
        scale_min, scale_max, source, non_discriminant = _resolve_scale(numeric_values, metric)
        meta = {
            "scale_min": scale_min,
            "scale_max": scale_max,
            "scale_source": source,
            "resolved_scale_min": scale_min,
            "resolved_scale_max": scale_max,
            "non_discriminant": non_discriminant,
        }
        if non_discriminant or scale_min is None or scale_max is None:
            return pd.Series([np.nan] * len(consolidated), index=consolidated.index), meta
        if metric.generic_type == "HIGH_IS_RISK":
            return numeric_values.apply(lambda value: normalize_high_is_risk(value, scale_min, scale_max)), meta
        if metric.generic_type == "LOW_IS_RISK":
            return numeric_values.apply(lambda value: normalize_low_is_risk(value, scale_min, scale_max)), meta
        meta.update({"healthy_min": metric.healthy_min, "healthy_max": metric.healthy_max})
        return numeric_values.apply(
            lambda value: normalize_target_range(
                value,
                float(metric.healthy_min),
                float(metric.healthy_max),
                scale_min,
                scale_max,
            )
        ), meta
    if metric.generic_type == "BINARY_RISK":
        if _already_mapped_risk(values):
            return numeric_values.apply(clamp), {"mapping": metric.binary_mapping, "mapped_before_aggregate": True}
        return values.apply(lambda value: normalize_binary_risk(value, metric.binary_mapping)), {"mapping": metric.binary_mapping}
    if metric.generic_type == "CATEGORICAL_RISK":
        if _already_mapped_risk(values):
            return numeric_values.apply(clamp), {"mapping": metric.category_mapping, "mapped_before_aggregate": True}
        return values.apply(lambda value: normalize_categorical_risk(value, metric.category_mapping)), {"mapping": metric.category_mapping}
    if metric.generic_type == "TREND_RISK":
        return _trend_risk_with_meta(values, metric.trend_direction or "UP_IS_RISK")
    return pd.Series([np.nan] * len(consolidated), index=consolidated.index), {}


def run_generic_analysis(consolidated: pd.DataFrame, config: AnalysisConfig) -> dict:
    scoring_metrics = [metric for metric in config.metrics if metric.generic_type != "INFORMATIONAL"]

    metric_risks: Dict[str, pd.Series] = {}
    metric_meta: Dict[str, dict] = {}
    warnings: List[str] = []
    for metric in scoring_metrics:
        risk_series, meta = _risk_series_for_metric(consolidated, metric)
        metric_risks[metric.label] = risk_series
        metric_meta[metric.label] = meta
        if meta.get("non_discriminant"):
            warnings.append(
                f"A metrica {metric.label} nao apresentou variabilidade suficiente e foi desconsiderada nesta analise."
            )

    discriminant_metrics = [metric for metric in scoring_metrics if not metric_meta.get(metric.label, {}).get("non_discriminant")]
    configured_weight_sum = sum(float(metric.weight or 1) for metric in discriminant_metrics)
    weights = normalize_weights(discriminant_metrics)

    ranking: List[dict] = []
    insufficient_data: List[dict] = []
    details: List[dict] = []

    for idx, row in consolidated.iterrows():
        entity_id = row.get("canonical_entity_id")
        risks_for_entity = {}
        observed_weight_sum = 0.0
        available_weight_sum = 0.0
        weighted_sum = 0.0
        entity_detail_indexes = []

        for metric in scoring_metrics:
            meta = metric_meta.get(metric.label, {})
            value_column = metric_output_column(metric)
            raw_value = row.get(value_column, np.nan)
            initial_risk = metric_risks[metric.label].loc[idx]
            non_discriminant = bool(meta.get("non_discriminant"))
            observed = pd.notna(initial_risk) and not non_discriminant
            risk = initial_risk
            missing_applied = False

            if not observed and not non_discriminant:
                replacement = _missing_value_for_strategy(metric)
                if pd.notna(replacement):
                    risk = replacement
                    missing_applied = True

            risk_available = pd.notna(risk) and not non_discriminant
            if observed:
                observed_weight_sum += float(metric.weight or 1)
            if risk_available:
                risks_for_entity[metric.label] = float(risk)
                available_weight_sum += float(metric.weight or 1)
                weighted_sum += float(risk) * float(metric.weight or 1)

            detail = {
                "Entidade": entity_id,
                "Metrica": metric.label,
                "Aba origem": metric.source_sheet,
                "Coluna origem": metric.source_column,
                "Valor original": None if pd.isna(raw_value) else raw_value,
                "Valor agregado": None if pd.isna(raw_value) else raw_value,
                "generic_type": metric.generic_type,
                "Regra": metric.generic_type,
                "aggregation": metric.aggregation,
                "observed": bool(observed),
                "risk_available": bool(risk_available),
                "Risco 0-1": None if pd.isna(risk) else round(float(risk), 6),
                "risk": None if pd.isna(risk) else round(float(risk), 6),
                "Peso": float(metric.weight or 1),
                "original_weight": float(metric.weight or 1),
                "Peso normalizado": None,
                "normalized_available_weight": None,
                "Contribuicao": 0.0,
                "contribution_points": 0.0,
                "non_discriminant": non_discriminant,
                "missing_strategy": metric.missing_strategy,
                "Tratamento vazio aplicado": missing_applied,
                "missing_applied": missing_applied,
                "scale": _scale_label(meta),
                **meta,
            }
            entity_detail_indexes.append(len(details))
            details.append(detail)

        score = calculate_score(weighted_sum, available_weight_sum)
        coverage = calculate_coverage(observed_weight_sum, configured_weight_sum)
        contributions = calculate_contributions(risks_for_entity, weights)

        for detail_index in entity_detail_indexes:
            detail = details[detail_index]
            contribution = contributions.get(detail["Metrica"])
            if contribution:
                detail["Peso normalizado"] = round(contribution["normalized_weight"], 6)
                detail["normalized_available_weight"] = round(contribution["normalized_weight"], 6)
                detail["Contribuicao"] = round(contribution["contribution_points"], 6)
                detail["contribution_points"] = round(contribution["contribution_points"], 6)

        ordered_factors = sorted(
            contributions.items(),
            key=lambda item: item[1]["contribution_points"],
            reverse=True,
        )
        factors = [name for name, _ in ordered_factors[:3]]
        low_coverage = pd.isna(score) or coverage < MIN_COVERAGE_FOR_RANKING
        ranking_row = {
            "Entidade": entity_id,
            "Score": None if pd.isna(score) else round(float(score), 2),
            "Faixa": "Dados insuficientes" if low_coverage else _band(score),
            "Cobertura": round(float(coverage), 2),
            "operational_status": "Dados insuficientes" if low_coverage else "Classificado",
            "Fator 1": factors[0] if len(factors) > 0 else "",
            "Fator 2": factors[1] if len(factors) > 1 else "",
            "Fator 3": factors[2] if len(factors) > 2 else "",
            "Contribuicoes": contributions,
        }
        for context in config.context_columns:
            column = context_output_column(context)
            if column in consolidated.columns:
                value = row.get(column)
                ranking_row[context.label] = None if pd.isna(value) else value
        for business in config.business_values:
            column = business_value_output_column(business)
            if column in consolidated.columns:
                value = row.get(column)
                ranking_row[business.label] = None if pd.isna(value) else value
        if low_coverage:
            insufficient_data.append(ranking_row)
        else:
            ranking.append(ranking_row)

    ranking = sorted(
        ranking,
        key=lambda item: (-1 if item["Score"] is None else item["Score"]),
        reverse=True,
    )
    insufficient_data = sorted(
        insufficient_data,
        key=lambda item: (-1 if item["Score"] is None else item["Score"]),
        reverse=True,
    )
    for position, row in enumerate(ranking, start=1):
        row["Posicao"] = position
    for row in insufficient_data:
        row["Posicao"] = ""

    snapshot = analysis_config_to_dict(config)
    return {
        "ranking": ranking,
        "insufficient_data": insufficient_data,
        "details": details,
        "methodology": methodology_text(),
        "config": snapshot,
        "analysis_config_snapshot": snapshot,
        "warnings": warnings,
        "metric_metadata": metric_meta,
    }


def methodology_text() -> str:
    return (
        "O sistema transforma metricas especificas da empresa em metricas genericas de risco. "
        "Cada metrica gera um risco normalizado entre 0 e 1, sempre limitado a essa faixa. "
        "O Score de Risco e 100 * soma(risco da metrica * peso disponivel) / soma(pesos disponiveis). "
        "Risco disponivel significa que a metrica foi observada ou recebeu uma estrategia explicita de ausente; "
        "ja a cobertura considera apenas metricas realmente observadas, portanto imputacao nao aumenta cobertura. "
        "Metricas sem variabilidade suficiente sao marcadas como nao discriminantes e saem do score e do denominador "
        "de cobertura. Escalas AUTO_DYNAMIC usam P5/P95 quando ha dados suficientes e minimo/maximo em amostras pequenas; "
        "FIXED reutiliza limites resolvidos e MANUAL usa limites informados. Binarios e categorias sao mapeados para "
        "risco antes da agregacao historica. RECENT_MEAN usa os ultimos periodos distintos, nao as ultimas linhas. "
        "TREND_RISK compara a media recente com a media anterior de mesmo tamanho e exige historico suficiente. "
        "Entidades com cobertura abaixo do minimo operacional aparecem como Dados insuficientes. O score e um indice "
        "ponderado, nao uma probabilidade."
    )


def _ranking_rows(result: dict, include_insufficient: bool = False) -> List[dict]:
    rows = list(result.get("ranking", []))
    if include_insufficient:
        rows.extend(result.get("insufficient_data", []))
    clean_rows = []
    for item in rows:
        row = dict(item)
        row.pop("Contribuicoes", None)
        clean_rows.append(row)
    return clean_rows


def _config_frame(result: dict) -> pd.DataFrame:
    snapshot = result.get("analysis_config_snapshot") or result.get("config") or {}
    return pd.json_normalize(snapshot, sep=".")


def analysis_to_frames(result: dict, consolidated: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    frames = {
        "Ranking": pd.DataFrame(_ranking_rows(result)),
        "Detalhes": pd.DataFrame(result.get("details", [])),
        "Configuracao": _config_frame(result),
        "Metodologia": pd.DataFrame({"Texto": [result.get("methodology", "")]}),
        "Dados Consolidados": consolidated.copy(),
    }
    if result.get("insufficient_data"):
        frames["Dados Insuficientes"] = pd.DataFrame(_ranking_rows({"ranking": result.get("insufficient_data", [])}))
    return frames
