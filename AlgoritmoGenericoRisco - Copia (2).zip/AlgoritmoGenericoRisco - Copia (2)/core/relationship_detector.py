from __future__ import annotations

from difflib import SequenceMatcher
from itertools import product
from typing import Dict, List, Optional

import pandas as pd

from .data_profiler import infer_kind


def _clean_values(series: pd.Series) -> pd.Series:
    return series.dropna().astype(str).str.strip().replace("", pd.NA).dropna()


def _name_similarity(left: str, right: str) -> float:
    return SequenceMatcher(None, left.lower(), right.lower()).ratio()


def _value_overlap(left: pd.Series, right: pd.Series) -> float:
    left_values = set(_clean_values(left))
    right_values = set(_clean_values(right))
    if not left_values or not right_values:
        return 0.0
    intersection = len(left_values & right_values)
    return intersection / min(len(left_values), len(right_values))


def _uniqueness(series: pd.Series) -> float:
    clean = _clean_values(series)
    if len(clean) == 0:
        return 0.0
    return min(1.0, clean.nunique() / len(clean))


def score_column_pair(
    left_name: str,
    left: pd.Series,
    right_name: str,
    right: pd.Series,
) -> dict:
    name_score = _name_similarity(left_name, right_name)
    type_score = 1.0 if infer_kind(left) == infer_kind(right) else 0.35
    overlap = _value_overlap(left, right)
    uniqueness = (_uniqueness(left) + _uniqueness(right)) / 2
    relation_score = 100 * (
        (0.25 * name_score)
        + (0.15 * type_score)
        + (0.45 * overlap)
        + (0.15 * uniqueness)
    )
    return {
        "left_column": left_name,
        "right_column": right_name,
        "name_similarity": round(name_score, 3),
        "type_compatibility": round(type_score, 3),
        "value_overlap": round(overlap, 3),
        "uniqueness": round(uniqueness, 3),
        "relation_score": round(float(relation_score), 1),
    }


def suggest_relationships(
    sheets: Dict[str, pd.DataFrame],
    main_sheet: Optional[str] = None,
    main_key: Optional[str] = None,
    max_suggestions_per_sheet: int = 5,
) -> Dict[str, List[dict]]:
    if not sheets:
        return {}
    if main_sheet is None:
        main_sheet = next(iter(sheets.keys()))
    if main_sheet not in sheets:
        raise ValueError("Aba principal nao encontrada.")

    suggestions: Dict[str, List[dict]] = {}
    main_df = sheets[main_sheet]
    main_columns = [main_key] if main_key else list(main_df.columns)
    main_columns = [col for col in main_columns if col in main_df.columns]

    for sheet_name, df in sheets.items():
        if sheet_name == main_sheet:
            continue
        scored: List[dict] = []
        for left_col, right_col in product(main_columns, df.columns):
            pair = score_column_pair(str(left_col), main_df[left_col], str(right_col), df[right_col])
            pair.update(
                {
                    "main_sheet": main_sheet,
                    "main_column": str(left_col),
                    "sheet": sheet_name,
                    "column": str(right_col),
                    "message": (
                        f"{right_col} parece representar a mesma entidade que {left_col}."
                    ),
                }
            )
            scored.append(pair)
        suggestions[sheet_name] = sorted(
            scored, key=lambda item: item["relation_score"], reverse=True
        )[:max_suggestions_per_sheet]
    return suggestions
