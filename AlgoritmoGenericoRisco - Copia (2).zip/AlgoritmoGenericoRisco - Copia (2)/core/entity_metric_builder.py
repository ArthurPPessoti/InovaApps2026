from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd

from config import DEFAULT_RECENT_PERIODS
from .generic_schema import (
    AnalysisConfig,
    BusinessValueConfig,
    ContextColumnConfig,
    MetricConfig,
    business_value_output_column,
    context_output_column,
    metric_output_column,
)


def normalize_entity_id(series: pd.Series) -> pd.Series:
    normalized = series.where(series.notna(), "")
    normalized = normalized.astype(str).str.strip()
    normalized = normalized.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA})
    return normalized


def _to_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series.replace("", pd.NA), errors="coerce")


def _time_sort_values(df: pd.DataFrame, time_column: Optional[str]) -> pd.DataFrame:
    if time_column and time_column in df.columns:
        parsed = pd.to_datetime(df[time_column], errors="coerce")
        if parsed.notna().any():
            return df.assign(__time_sort=parsed).sort_values(["canonical_entity_id", "__time_sort"])
        return df.sort_values(["canonical_entity_id", time_column])
    return df.assign(__physical_order=range(len(df))).sort_values(["canonical_entity_id", "__physical_order"])


def _periodized(df: pd.DataFrame, time_column: Optional[str]) -> pd.DataFrame:
    working = df.copy()
    if time_column and time_column in working.columns:
        parsed = pd.to_datetime(working[time_column], errors="coerce")
        if parsed.notna().any():
            working["__period_key"] = parsed
            working["__period_sort"] = parsed
        else:
            working["__period_key"] = working[time_column].astype(str)
            working["__period_sort"] = working[time_column].astype(str)
    else:
        working["__period_key"] = range(len(working))
        working["__period_sort"] = range(len(working))
    return working


def _aggregate_by_latest_period(df: pd.DataFrame, value_column: str, time_column: Optional[str]) -> pd.Series:
    working = _periodized(df, time_column)
    numeric = _to_numeric(working[value_column])
    use_numeric = numeric.notna().any()
    working["__value"] = numeric if use_numeric else working[value_column]
    if use_numeric:
        by_period = (
            working.groupby(["canonical_entity_id", "__period_key"], dropna=True)
            .agg(__value=("__value", "mean"), __period_sort=("__period_sort", "max"))
            .reset_index()
        )
    else:
        by_period = (
            working.sort_values(["canonical_entity_id", "__period_sort"])
            .groupby(["canonical_entity_id", "__period_key"], dropna=True)
            .agg(__value=("__value", "last"), __period_sort=("__period_sort", "max"))
            .reset_index()
        )
    latest = by_period.sort_values(["canonical_entity_id", "__period_sort"]).groupby("canonical_entity_id", dropna=True)
    return latest["__value"].last()


def _aggregate_recent_period_mean(
    df: pd.DataFrame,
    value_column: str,
    time_column: Optional[str],
    recent_periods: int,
) -> pd.Series:
    working = _periodized(df, time_column)
    working["__value"] = _to_numeric(working[value_column])
    by_period = (
        working.groupby(["canonical_entity_id", "__period_key"], dropna=True)
        .agg(__value=("__value", "mean"), __period_sort=("__period_sort", "max"))
        .reset_index()
        .sort_values(["canonical_entity_id", "__period_sort"])
    )
    return (
        by_period.groupby("canonical_entity_id", dropna=True)
        .tail(recent_periods)
        .groupby("canonical_entity_id", dropna=True)["__value"]
        .mean()
    )


def _aggregate_series(
    df: pd.DataFrame,
    value_column: str,
    aggregation: str,
    time_column: Optional[str] = None,
    recent_periods: int = DEFAULT_RECENT_PERIODS,
):
    if aggregation == "FIRST":
        return df.groupby("canonical_entity_id", dropna=True)[value_column].first()
    if aggregation == "LATEST":
        return _aggregate_by_latest_period(df, value_column, time_column)

    numeric = df.copy()
    numeric[value_column] = _to_numeric(numeric[value_column])
    if aggregation == "MEAN":
        return numeric.groupby("canonical_entity_id", dropna=True)[value_column].mean()
    if aggregation == "SUM":
        return numeric.groupby("canonical_entity_id", dropna=True)[value_column].sum(min_count=1)
    if aggregation == "MIN":
        return numeric.groupby("canonical_entity_id", dropna=True)[value_column].min()
    if aggregation == "MAX":
        return numeric.groupby("canonical_entity_id", dropna=True)[value_column].max()
    if aggregation == "RECENT_MEAN":
        return _aggregate_recent_period_mean(numeric, value_column, time_column, recent_periods)
    raise ValueError(f"Agregacao nao suportada: {aggregation}")


def _aggregate_trend(
    df: pd.DataFrame,
    metric: MetricConfig,
    recent_periods: int = DEFAULT_RECENT_PERIODS,
) -> Tuple[pd.Series, pd.Series, pd.Series]:
    time_column = metric.time_column
    if not time_column or time_column not in df.columns:
        raise ValueError(f"Metrica de tendencia precisa de tempo: {metric.label}")

    working = df[["canonical_entity_id", time_column, metric.source_column]].copy()
    working[metric.source_column] = _to_numeric(working[metric.source_column])
    working = _periodized(working, time_column)
    by_period = (
        working.groupby(["canonical_entity_id", "__period_key"], dropna=True)
        .agg(__value=(metric.source_column, "mean"), __period_sort=("__period_sort", "max"))
        .reset_index()
        .sort_values(["canonical_entity_id", "__period_sort"])
    )
    previous_values = {}
    recent_values = {}
    deltas = {}
    for entity_id, group in by_period.groupby("canonical_entity_id", dropna=True):
        values = group["__value"].dropna()
        if len(values) < recent_periods * 2:
            previous_values[entity_id] = pd.NA
            recent_values[entity_id] = pd.NA
            deltas[entity_id] = pd.NA
            continue
        recent = values.tail(recent_periods)
        previous = values.iloc[-(recent_periods * 2) : -recent_periods]
        recent_mean = float(recent.mean()) if len(recent) else pd.NA
        previous_mean = float(previous.mean()) if len(previous) else pd.NA
        delta = recent_mean - previous_mean if pd.notna(recent_mean) and pd.notna(previous_mean) else pd.NA
        previous_values[entity_id] = previous_mean
        recent_values[entity_id] = recent_mean
        deltas[entity_id] = delta
    return pd.Series(deltas), pd.Series(previous_values), pd.Series(recent_values)


def _map_raw_values_to_risk(series: pd.Series, mapping: Dict[str, float]) -> pd.Series:
    risks = series.where(series.notna(), pd.NA).astype("object").map(lambda value: str(value) if pd.notna(value) else pd.NA)
    return risks.map({str(key): value for key, value in (mapping or {}).items()})


def _apply_status_filters(df: pd.DataFrame, sheet: str, config: AnalysisConfig) -> pd.DataFrame:
    filtered = df.copy()
    for status_filter in config.status_filters:
        if status_filter.source_sheet != sheet:
            continue
        if status_filter.source_column not in filtered.columns:
            continue
        allowed = {str(value) for value in status_filter.allowed_values}
        if allowed:
            filtered = filtered[filtered[status_filter.source_column].astype(str).isin(allowed)]
    return filtered


def _allowed_entities_for_status_filters(
    sheets: Dict[str, pd.DataFrame],
    config: AnalysisConfig,
) -> Optional[set]:
    allowed_entities: Optional[set] = None
    for status_filter in config.status_filters:
        entity_column = config.entity_keys.get(status_filter.source_sheet)
        if not entity_column:
            continue
        df = sheets.get(status_filter.source_sheet)
        if df is None or entity_column not in df.columns or status_filter.source_column not in df.columns:
            continue
        allowed_values = {str(value) for value in status_filter.allowed_values}
        if not allowed_values:
            continue
        matching = df[df[status_filter.source_column].astype(str).isin(allowed_values)]
        entity_ids = set(normalize_entity_id(matching[entity_column]).dropna().tolist())
        allowed_entities = entity_ids if allowed_entities is None else allowed_entities & entity_ids
    return allowed_entities


def _merge_one_per_entity(frames: Iterable[pd.DataFrame]) -> pd.DataFrame:
    frames = [frame for frame in frames if frame is not None and not frame.empty]
    if not frames:
        return pd.DataFrame(columns=["canonical_entity_id"])
    merged = frames[0]
    for frame in frames[1:]:
        merged = merged.merge(frame, on="canonical_entity_id", how="outer", validate="one_to_one")
    return merged


def build_entity_metrics(
    sheets: Dict[str, pd.DataFrame],
    config: AnalysisConfig,
) -> Tuple[pd.DataFrame, dict]:
    frames: List[pd.DataFrame] = []
    metadata = {
        "ignored_sheets": [],
        "metric_columns": {},
        "context_columns": {},
        "business_value_columns": {},
        "trend_columns": {},
        "sheet_rows_after_aggregation": {},
    }

    metrics_by_sheet: Dict[str, List[MetricConfig]] = {}
    for metric in config.metrics:
        metrics_by_sheet.setdefault(metric.source_sheet, []).append(metric)

    contexts_by_sheet: Dict[str, List[ContextColumnConfig]] = {}
    for context in config.context_columns:
        contexts_by_sheet.setdefault(context.source_sheet, []).append(context)

    business_by_sheet: Dict[str, List[BusinessValueConfig]] = {}
    for item in config.business_values:
        business_by_sheet.setdefault(item.source_sheet, []).append(item)

    for sheet_name, df in sheets.items():
        entity_column = config.entity_keys.get(sheet_name)
        if not entity_column or entity_column not in df.columns:
            metadata["ignored_sheets"].append(
                {"sheet": sheet_name, "reason": "Nao foi possivel relacionar esta aba aos clientes."}
            )
            continue

        working = _apply_status_filters(df, sheet_name, config).copy()
        working["canonical_entity_id"] = normalize_entity_id(working[entity_column])
        working = working.dropna(subset=["canonical_entity_id"])

        sheet_parts: List[pd.DataFrame] = [
            pd.DataFrame({"canonical_entity_id": working["canonical_entity_id"].drop_duplicates()})
        ]

        for metric in metrics_by_sheet.get(sheet_name, []):
            if metric.source_column not in working.columns:
                continue
            output_col = metric_output_column(metric)
            time_col = metric.time_column or config.time_columns.get(sheet_name)
            recent_periods = metric.recent_periods or DEFAULT_RECENT_PERIODS
            if metric.generic_type == "TREND_RISK":
                delta, previous, recent = _aggregate_trend(working, metric, recent_periods)
                part = delta.rename(output_col).reset_index().rename(columns={"index": "canonical_entity_id"})
                sheet_parts.append(part)
                metadata["trend_columns"][output_col] = {
                    "previous_mean": previous.to_dict(),
                    "recent_mean": recent.to_dict(),
                }
            else:
                value_column = metric.source_column
                source_for_aggregation = working
                if metric.generic_type in {"BINARY_RISK", "CATEGORICAL_RISK"}:
                    mapping = metric.binary_mapping if metric.generic_type == "BINARY_RISK" else metric.category_mapping
                    value_column = f"__mapped_risk_{output_col}"
                    source_for_aggregation = working.copy()
                    source_for_aggregation[value_column] = _map_raw_values_to_risk(working[metric.source_column], mapping)
                    metadata["metric_columns"][f"{metric.label}__mapped_before_aggregate"] = True
                aggregated = _aggregate_series(
                    source_for_aggregation,
                    value_column,
                    metric.aggregation,
                    time_col,
                    recent_periods,
                )
                part = aggregated.rename(output_col).reset_index()
                sheet_parts.append(part)
            metadata["metric_columns"][metric.label] = output_col

        for context in contexts_by_sheet.get(sheet_name, []):
            if context.source_column not in working.columns:
                continue
            output_col = context_output_column(context)
            aggregated = _aggregate_series(
                working,
                context.source_column,
                context.aggregation,
                config.time_columns.get(sheet_name),
            )
            sheet_parts.append(aggregated.rename(output_col).reset_index())
            metadata["context_columns"][context.label] = output_col

        for business in business_by_sheet.get(sheet_name, []):
            if business.source_column not in working.columns:
                continue
            output_col = business_value_output_column(business)
            aggregated = _aggregate_series(
                working,
                business.source_column,
                business.aggregation,
                config.time_columns.get(sheet_name),
            )
            sheet_parts.append(aggregated.rename(output_col).reset_index())
            metadata["business_value_columns"][business.label] = output_col

        sheet_frame = _merge_one_per_entity(sheet_parts)
        metadata["sheet_rows_after_aggregation"][sheet_name] = int(len(sheet_frame))
        frames.append(sheet_frame)

    consolidated = _merge_one_per_entity(frames)
    allowed_entities = _allowed_entities_for_status_filters(sheets, config)
    if allowed_entities is not None:
        consolidated = consolidated[consolidated["canonical_entity_id"].isin(allowed_entities)].reset_index(drop=True)
        metadata["status_filtered_entities"] = int(len(consolidated))
    return consolidated, metadata
