from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

from core.generic_schema import analysis_config_from_dict, analysis_config_to_dict


def list_templates(template_dir: Path):
    template_dir.mkdir(parents=True, exist_ok=True)
    return [
        {"id": path.stem, "filename": path.name}
        for path in sorted(template_dir.glob("*.json"))
    ]


def load_template(template_dir: Path, template_id: str) -> dict:
    path = _template_path(template_dir, template_id)
    if not path.exists():
        raise FileNotFoundError("Template nao encontrado.")
    return json.loads(path.read_text(encoding="utf-8"))


def save_template(template_dir: Path, template_id: str, config_data: dict) -> dict:
    template_dir.mkdir(parents=True, exist_ok=True)
    path = _template_path(template_dir, template_id)
    config = analysis_config_from_dict(config_data)
    path.write_text(
        json.dumps(analysis_config_to_dict(config), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return {"id": path.stem, "filename": path.name}


def validate_template(config_data: dict, profile: Dict[str, dict]) -> dict:
    missing_sheets = []
    missing_columns = []
    new_columns = []
    config = analysis_config_from_dict(config_data)

    referenced = {}
    for sheet, column in config.entity_keys.items():
        referenced.setdefault(sheet, set()).add(column)
    for metric in config.metrics:
        referenced.setdefault(metric.source_sheet, set()).add(metric.source_column)
        if metric.time_column:
            referenced.setdefault(metric.source_sheet, set()).add(metric.time_column)
    for item in config.context_columns + config.business_values + config.status_filters:
        referenced.setdefault(item.source_sheet, set()).add(item.source_column)

    for sheet, columns in referenced.items():
        if sheet not in profile:
            missing_sheets.append(sheet)
            continue
        available = {column["name"] for column in profile[sheet]["columns"]}
        missing_columns.extend(
            {"sheet": sheet, "column": column} for column in sorted(columns - available)
        )
        new_columns.extend(
            {"sheet": sheet, "column": column} for column in sorted(available - columns)
        )

    if missing_sheets or missing_columns:
        status = "Incompativel"
    elif new_columns:
        status = "Compativel com avisos"
    else:
        status = "Compativel"
    return {
        "status": status,
        "missing_sheets": missing_sheets,
        "missing_columns": missing_columns,
        "new_columns": new_columns,
    }


def _template_path(template_dir: Path, template_id: str) -> Path:
    clean = "".join(ch for ch in template_id if ch.isalnum() or ch in "-_").strip()
    if not clean:
        clean = "template"
    return template_dir / f"{clean}.json"
