from __future__ import annotations

from dataclasses import asdict, dataclass, field
import re
from typing import Any, Dict, List, Optional


ROLE_ENTITY_ID = "ENTITY_ID"
ROLE_TIME = "TIME"
ROLE_METRIC = "METRIC"
ROLE_CONTEXT = "CONTEXT"
ROLE_BUSINESS_VALUE = "BUSINESS_VALUE"
ROLE_STATUS_FILTER = "STATUS_FILTER"
ROLE_IGNORE = "IGNORE"

GENERIC_TYPES = {
    "HIGH_IS_RISK",
    "LOW_IS_RISK",
    "BINARY_RISK",
    "CATEGORICAL_RISK",
    "TARGET_RANGE",
    "TREND_RISK",
    "INFORMATIONAL",
}

AGGREGATIONS = {"FIRST", "LATEST", "MEAN", "RECENT_MEAN", "SUM", "MIN", "MAX", "TREND"}
MISSING_STRATEGIES = {"IGNORE_AND_REWEIGHT", "NEUTRAL", "RISK", "HEALTHY", "CUSTOM"}
SCALE_MODES = {"AUTO_DYNAMIC", "FIXED", "MANUAL", "AUTO"}
TREND_DIRECTIONS = {"UP_IS_RISK", "DOWN_IS_RISK"}

AGGREGATION_MATRIX = {
    "HIGH_IS_RISK": {"FIRST", "LATEST", "MEAN", "RECENT_MEAN", "SUM", "MIN", "MAX"},
    "LOW_IS_RISK": {"FIRST", "LATEST", "MEAN", "RECENT_MEAN", "SUM", "MIN", "MAX"},
    "TARGET_RANGE": {"FIRST", "LATEST", "MEAN", "RECENT_MEAN", "MIN", "MAX"},
    "BINARY_RISK": {"FIRST", "LATEST", "MEAN", "RECENT_MEAN"},
    "CATEGORICAL_RISK": {"FIRST", "LATEST", "MEAN", "RECENT_MEAN"},
    "TREND_RISK": {"TREND"},
    "INFORMATIONAL": {"FIRST", "LATEST", "MEAN", "RECENT_MEAN", "SUM", "MIN", "MAX"},
}


@dataclass
class MetricConfig:
    source_sheet: str
    source_column: str
    label: str
    generic_type: str
    aggregation: str = "MEAN"
    weight: float = 1.0
    scale_mode: str = "AUTO_DYNAMIC"
    scale_min: Optional[float] = None
    scale_max: Optional[float] = None
    resolved_scale_min: Optional[float] = None
    resolved_scale_max: Optional[float] = None
    missing_strategy: str = "IGNORE_AND_REWEIGHT"
    missing_custom_value: Optional[float] = None
    binary_mapping: Dict[str, float] = field(default_factory=dict)
    category_mapping: Dict[str, float] = field(default_factory=dict)
    healthy_min: Optional[float] = None
    healthy_max: Optional[float] = None
    trend_direction: Optional[str] = None
    time_column: Optional[str] = None
    recent_periods: Optional[int] = None


@dataclass
class ContextColumnConfig:
    source_sheet: str
    source_column: str
    label: str
    aggregation: str = "LATEST"


@dataclass
class BusinessValueConfig:
    source_sheet: str
    source_column: str
    label: str
    aggregation: str = "LATEST"


@dataclass
class StatusFilterConfig:
    source_sheet: str
    source_column: str
    allowed_values: List[str] = field(default_factory=list)


@dataclass
class AnalysisConfig:
    entity_label: str = "Entidade"
    main_sheet: Optional[str] = None
    entity_keys: Dict[str, str] = field(default_factory=dict)
    time_columns: Dict[str, str] = field(default_factory=dict)
    context_columns: List[ContextColumnConfig] = field(default_factory=list)
    business_values: List[BusinessValueConfig] = field(default_factory=list)
    status_filters: List[StatusFilterConfig] = field(default_factory=list)
    metrics: List[MetricConfig] = field(default_factory=list)


def _coerce_dataclass_list(items: List[Dict[str, Any]], cls):
    return [item if isinstance(item, cls) else cls(**item) for item in items]


def analysis_config_from_dict(data: Dict[str, Any]) -> AnalysisConfig:
    data = dict(data or {})
    data["context_columns"] = _coerce_dataclass_list(data.get("context_columns", []), ContextColumnConfig)
    data["business_values"] = _coerce_dataclass_list(data.get("business_values", []), BusinessValueConfig)
    data["status_filters"] = _coerce_dataclass_list(data.get("status_filters", []), StatusFilterConfig)
    data["metrics"] = _coerce_dataclass_list(data.get("metrics", []), MetricConfig)
    for metric in data["metrics"]:
        if metric.scale_mode == "AUTO":
            metric.scale_mode = "AUTO_DYNAMIC"
    return AnalysisConfig(**data)


def analysis_config_to_dict(config: AnalysisConfig) -> Dict[str, Any]:
    return asdict(config)


def validate_analysis_config(config: AnalysisConfig) -> List[str]:
    errors: List[str] = []
    if not config.entity_keys:
        errors.append("Configure pelo menos uma coluna de entidade.")
    for sheet, column in config.entity_keys.items():
        if not sheet or not column:
            errors.append("Toda relacao precisa informar aba e coluna.")
    for metric in config.metrics:
        errors.extend(validate_metric_config(metric))
    return errors


def validate_metric_config(metric: MetricConfig) -> List[str]:
    errors: List[str] = []
    label = metric.label or metric.source_column
    if metric.generic_type not in GENERIC_TYPES:
        errors.append(f"Tipo generico invalido para {label}: {metric.generic_type}")
        return errors
    if metric.aggregation not in AGGREGATIONS:
        errors.append(f"Agregacao invalida para {label}: {metric.aggregation}")
    allowed = AGGREGATION_MATRIX.get(metric.generic_type, set())
    if metric.aggregation in AGGREGATIONS and metric.aggregation not in allowed:
        if metric.generic_type == "CATEGORICAL_RISK" and metric.aggregation == "SUM":
            errors.append(f"Categorias nao podem ser somadas para {label}; use Primeiro, Ultimo, Media ou Media recente.")
        elif metric.generic_type == "BINARY_RISK" and metric.aggregation == "SUM":
            errors.append(f"Indicadores Sim/Nao nao podem ser somados para {label}; use Primeiro, Ultimo, Media ou Media recente.")
        elif metric.generic_type == "TARGET_RANGE" and metric.aggregation == "SUM":
            errors.append(f"Faixa saudavel nao aceita soma para {label}; use uma agregacao compativel.")
        elif metric.generic_type == "TREND_RISK":
            errors.append(f"Tendencia deve usar agregacao Tendencia para {label}.")
        else:
            errors.append(f"Agregacao {metric.aggregation} nao e compativel com {label}.")
    if metric.weight <= 0:
        errors.append(f"Peso precisa ser maior que zero para {label}.")
    if metric.scale_mode not in SCALE_MODES:
        errors.append(f"Modo de escala invalido para {label}.")
    if metric.missing_strategy not in MISSING_STRATEGIES:
        errors.append(f"Tratamento de vazio invalido para {label}.")
    if metric.generic_type == "TREND_RISK" and not metric.time_column:
        errors.append(f"Tendencia precisa de coluna de tempo para {label}.")
    if metric.generic_type == "TARGET_RANGE" and (
        metric.healthy_min is None or metric.healthy_max is None
    ):
        errors.append(f"Faixa saudavel incompleta para {label}.")
    if metric.scale_mode == "MANUAL" and (metric.scale_min is None or metric.scale_max is None):
        errors.append(f"Escala manual incompleta para {label}.")
    if metric.scale_mode == "FIXED":
        fixed_min = metric.resolved_scale_min if metric.resolved_scale_min is not None else metric.scale_min
        fixed_max = metric.resolved_scale_max if metric.resolved_scale_max is not None else metric.scale_max
        if fixed_min is None or fixed_max is None:
            errors.append(f"Escala fixa precisa de limites resolvidos para {label}.")
    return errors


def safe_key(*parts: str) -> str:
    raw = "__".join(str(part) for part in parts if part is not None)
    key = re.sub(r"[^0-9A-Za-z_]+", "_", raw.strip())
    key = re.sub(r"_+", "_", key).strip("_").lower()
    return key or "campo"


def metric_output_column(metric: MetricConfig) -> str:
    return f"metric__{safe_key(metric.source_sheet, metric.source_column)}"


def context_output_column(config: ContextColumnConfig) -> str:
    return f"context__{safe_key(config.source_sheet, config.source_column)}"


def business_value_output_column(config: BusinessValueConfig) -> str:
    return f"business__{safe_key(config.source_sheet, config.source_column)}"
