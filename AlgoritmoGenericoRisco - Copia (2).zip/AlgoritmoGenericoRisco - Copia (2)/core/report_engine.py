from __future__ import annotations

from collections import Counter
from html import escape


def build_printable_report(result: dict, summary: dict) -> str:
    ranking = result.get("ranking", [])
    insufficient = result.get("insufficient_data", [])
    factor_counter = Counter()
    for row in ranking:
        for key in ["Fator 1", "Fator 2", "Fator 3"]:
            if row.get(key):
                factor_counter[row[key]] += 1

    top_rows = "\n".join(
        "<tr>"
        f"<td>{row.get('Posicao')}</td>"
        f"<td>{escape(str(row.get('Entidade', '')))}</td>"
        f"<td>{row.get('Score')}</td>"
        f"<td>{escape(str(row.get('Faixa', '')))}</td>"
        f"<td>{row.get('Cobertura')}%</td>"
        f"<td>{escape(str(row.get('Fator 1', '')))}</td>"
        "</tr>"
        for row in ranking[:10]
    )
    factors = "\n".join(
        f"<li>{escape(name)}: {count}</li>" for name, count in factor_counter.most_common(10)
    )
    insufficient_rows = "\n".join(
        "<tr>"
        f"<td>{escape(str(row.get('Entidade', '')))}</td>"
        f"<td>{row.get('Score')}</td>"
        f"<td>{row.get('Cobertura')}%</td>"
        f"<td>DADOS INSUFICIENTES</td>"
        "</tr>"
        for row in insufficient
    )
    insufficient_section = f"""
  <h2>Dados insuficientes</h2>
  <p>Estas entidades ficaram abaixo da cobertura minima operacional e nao foram classificadas nas faixas Baixo, Atencao, Alto ou Critico.</p>
  <table>
    <thead><tr><th>Cliente</th><th>Score calculado</th><th>Cobertura</th><th>Status</th></tr></thead>
    <tbody>{insufficient_rows}</tbody>
  </table>
""" if insufficient else ""

    return f"""<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Relatorio Risk Analysis</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 32px; color: #1f2937; }}
    h1, h2 {{ color: #111827; }}
    table {{ border-collapse: collapse; width: 100%; margin-top: 12px; }}
    th, td {{ border: 1px solid #d1d5db; padding: 8px; text-align: left; }}
    th {{ background: #f3f4f6; }}
    .cards {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }}
    .card {{ border: 1px solid #d1d5db; padding: 12px; border-radius: 8px; }}
    button {{ padding: 8px 12px; }}
    @media print {{ button {{ display: none; }} body {{ margin: 0; }} }}
  </style>
</head>
<body>
  <button onclick="window.print()">Imprimir / salvar PDF</button>
  <h1>Relatorio de Analise de Risco</h1>
  <section class="cards">
    <div class="card"><strong>Clientes analisados</strong><br>{summary.get('clientes_analisados', 0)}</div>
    <div class="card"><strong>Risco medio</strong><br>{summary.get('risco_medio', 0)}</div>
    <div class="card"><strong>Cobertura media</strong><br>{summary.get('cobertura_media', 0)}%</div>
    <div class="card"><strong>Dados insuficientes</strong><br>{summary.get('dados_insuficientes', 0)}</div>
  </section>
  <h2>Metodologia</h2>
  <p>{escape(result.get('methodology', ''))}</p>
  <h2>Top 10</h2>
  <table>
    <thead><tr><th>Posicao</th><th>Cliente</th><th>Score</th><th>Faixa</th><th>Cobertura</th><th>Principal fator</th></tr></thead>
    <tbody>{top_rows}</tbody>
  </table>
  <h2>Principais fatores</h2>
  <ul>{factors}</ul>
  {insufficient_section}
</body>
</html>"""
