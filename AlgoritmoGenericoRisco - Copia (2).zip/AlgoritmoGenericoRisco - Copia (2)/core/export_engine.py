from __future__ import annotations

from pathlib import Path

import pandas as pd

from .generic_risk_engine import analysis_to_frames


def export_xlsx(result: dict, consolidated: pd.DataFrame, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    frames = analysis_to_frames(result, consolidated)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for sheet_name, frame in frames.items():
            safe_name = sheet_name[:31]
            frame.to_excel(writer, sheet_name=safe_name, index=False)
    return path


def export_csv(result: dict, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for item in result["ranking"]:
        row = dict(item)
        row.pop("Contribuicoes", None)
        rows.append(row)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")
    return path
