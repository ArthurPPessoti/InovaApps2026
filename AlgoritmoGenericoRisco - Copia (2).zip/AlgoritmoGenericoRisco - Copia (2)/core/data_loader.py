from __future__ import annotations

from pathlib import Path
from typing import Dict

import pandas as pd


ALLOWED_EXTENSIONS = {".csv", ".xlsx"}


def load_workbook(path: Path) -> Dict[str, pd.DataFrame]:
    suffix = path.suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise ValueError("Formato nao suportado. Envie CSV ou XLSX.")
    if suffix == ".csv":
        return {"Dados": pd.read_csv(path, dtype=object, keep_default_na=False)}
    sheets = pd.read_excel(path, sheet_name=None, dtype=object, engine="openpyxl")
    return {str(name): df for name, df in sheets.items()}


def sanitize_filename(name: str) -> str:
    clean = "".join(ch for ch in name if ch.isalnum() or ch in "._- ").strip()
    clean = clean.replace(" ", "_")
    return clean or "arquivo"
