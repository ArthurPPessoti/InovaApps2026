from __future__ import annotations

from typing import Dict, List
import warnings

import pandas as pd


DOCUMENTATION_WORDS = {
    "readme",
    "leiame",
    "documentacao",
    "documentação",
    "dicionario",
    "dicionário",
    "metadata",
    "metadados",
    "instrucoes",
    "instruções",
}


def infer_kind(series: pd.Series) -> str:
    numeric = pd.to_numeric(series.replace("", pd.NA), errors="coerce")
    if numeric.notna().mean() >= 0.8 and numeric.notna().sum() > 0:
        return "number"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        dates = pd.to_datetime(series.replace("", pd.NA), errors="coerce")
    if dates.notna().mean() >= 0.8 and dates.notna().sum() > 0:
        return "date"
    return "text"


def _is_documentation_sheet(sheet_name: str, df: pd.DataFrame) -> bool:
    normalized = sheet_name.lower().replace(" ", "_")
    if any(word in normalized for word in DOCUMENTATION_WORDS):
        return True
    if len(df) <= 30 and len(df.columns) <= 4:
        joined_columns = " ".join(str(column).lower() for column in df.columns)
        if any(word in joined_columns for word in DOCUMENTATION_WORDS):
            return True
    return False


def _column_hints(name: str, kind: str, unique_count: int, row_count: int) -> List[str]:
    lowered = name.lower()
    hints: List[str] = []
    if any(token in lowered for token in ["id", "codigo", "código", "cod", "cliente", "account", "matricula", "matrícula", "assinante"]):
        hints.append("possivel_identificador")
    if any(token in lowered for token in ["data", "mes", "mês", "periodo", "período", "competencia", "competência", "ref"]):
        hints.append("possivel_periodo")
    if kind == "number":
        hints.append("numerica")
    if unique_count <= 2 and row_count > 0:
        hints.append("binaria")
    if kind == "text" and 2 < unique_count <= min(20, max(3, row_count // 2)):
        hints.append("categorica")
    return hints


def profile_sheets(sheets: Dict[str, pd.DataFrame]) -> Dict[str, dict]:
    result: Dict[str, dict] = {}
    for sheet_name, df in sheets.items():
        columns: List[dict] = []
        for column in df.columns:
            series = df[column]
            non_empty = series.replace("", pd.NA).dropna()
            kind = infer_kind(series)
            samples = [str(v) for v in non_empty.head(5).tolist()]
            values = [str(v) for v in non_empty.astype(str).drop_duplicates().head(50).tolist()]
            columns.append(
                {
                    "name": str(column),
                    "kind": kind,
                    "unique_count": int(non_empty.astype(str).nunique()),
                    "missing_count": int(len(series) - len(non_empty)),
                    "samples": samples,
                    "values": values,
                    "hints": _column_hints(str(column), kind, int(non_empty.astype(str).nunique()), int(len(df))),
                }
            )
        result[sheet_name] = {
            "rows": int(len(df)),
            "columns_count": int(len(df.columns)),
            "columns": columns,
            "is_documentation": _is_documentation_sheet(sheet_name, df),
        }
    return result
