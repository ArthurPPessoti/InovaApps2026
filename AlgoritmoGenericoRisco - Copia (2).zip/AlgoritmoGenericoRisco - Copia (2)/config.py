from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"
STORAGE_DIR = BASE_DIR / "storage"
UPLOAD_DIR = STORAGE_DIR / "uploads"
EXPORT_DIR = STORAGE_DIR / "exports"
TEMPLATE_DIR = STORAGE_DIR / "templates"

MAX_UPLOAD_SIZE = 50 * 1024 * 1024
DEFAULT_RECENT_PERIODS = 3
RECENT_WINDOW = DEFAULT_RECENT_PERIODS
AUTO_SCALE_SMALL_SAMPLE = 10
MIN_COVERAGE_FOR_RANKING = 40

RISK_BANDS = [
    {"key": "LOW", "label": "Baixo", "min": 0, "max": 29},
    {"key": "ATTENTION", "label": "Atencao", "min": 30, "max": 59},
    {"key": "HIGH", "label": "Alto", "min": 60, "max": 79},
    {"key": "CRITICAL", "label": "Critico", "min": 80, "max": 100},
]
