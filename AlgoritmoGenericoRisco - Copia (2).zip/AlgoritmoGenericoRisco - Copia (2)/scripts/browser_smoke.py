from __future__ import annotations

import base64
import json
import os
import socket
import struct
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CHROME = Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe")
URL = "http://127.0.0.1:8000/"
PORT = 9223


class CDP:
    def __init__(self, websocket_url: str):
        host, path = websocket_url.removeprefix("ws://").split("/", 1)
        if ":" in host:
            hostname, port = host.split(":", 1)
            self.sock = socket.create_connection((hostname, int(port)), timeout=10)
        else:
            self.sock = socket.create_connection((host, 80), timeout=10)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            f"GET /{path} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(request.encode("ascii"))
        response = self.sock.recv(4096)
        if b"101" not in response.split(b"\r\n", 1)[0]:
            raise RuntimeError("Falha ao conectar no DevTools.")
        self.next_id = 1
        self.events = []

    def command(self, method: str, params: dict | None = None, timeout: float = 10):
        command_id = self.next_id
        self.next_id += 1
        self._send({"id": command_id, "method": method, "params": params or {}})
        deadline = time.time() + timeout
        while time.time() < deadline:
            message = self._recv()
            if message.get("id") == command_id:
                if "error" in message:
                    raise RuntimeError(message["error"])
                return message.get("result", {})
            self.events.append(message)
        raise TimeoutError(method)

    def wait_eval(self, expression: str, timeout: float = 10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            result = self.command(
                "Runtime.evaluate",
                {
                    "expression": expression,
                    "awaitPromise": True,
                    "returnByValue": True,
                },
            )
            value = result.get("result", {}).get("value")
            if value:
                return value
            time.sleep(0.2)
        raise TimeoutError(expression)

    def eval(self, expression: str):
        result = self.command(
            "Runtime.evaluate",
            {
                "expression": expression,
                "awaitPromise": True,
                "returnByValue": True,
            },
        )
        if result.get("exceptionDetails"):
            raise RuntimeError(result["exceptionDetails"])
        return result.get("result", {}).get("value")

    def set_file(self, selector: str, file_path: Path):
        document = self.command("DOM.getDocument")
        node = self.command("DOM.querySelector", {"nodeId": document["root"]["nodeId"], "selector": selector})
        self.command("DOM.setFileInputFiles", {"nodeId": node["nodeId"], "files": [str(file_path)]})

    def close(self):
        self.sock.close()

    def _send(self, payload: dict):
        raw = json.dumps(payload).encode("utf-8")
        header = bytearray([0x81])
        if len(raw) < 126:
            header.append(0x80 | len(raw))
        elif len(raw) < 65536:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", len(raw)))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", len(raw)))
        mask = os.urandom(4)
        header.extend(mask)
        masked = bytes(byte ^ mask[index % 4] for index, byte in enumerate(raw))
        self.sock.sendall(bytes(header) + masked)

    def _recv(self):
        first = self.sock.recv(2)
        if not first:
            raise ConnectionError("DevTools fechado.")
        length = first[1] & 0x7F
        if length == 126:
            length = struct.unpack("!H", self.sock.recv(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", self.sock.recv(8))[0]
        if first[1] & 0x80:
            mask = self.sock.recv(4)
            data = bytearray(self.sock.recv(length))
            data = bytes(byte ^ mask[index % 4] for index, byte in enumerate(data))
        else:
            data = self.sock.recv(length)
        return json.loads(data.decode("utf-8"))


def main():
    args = sys.argv[1:]
    upload_only = "--upload-only" in args
    file_arg = next((arg for arg in args if not arg.startswith("--")), "sample_data/demo_servicos.xlsx")
    sample_file = (ROOT / file_arg).resolve()
    if not sample_file.exists():
        raise SystemExit(f"Arquivo nao encontrado: {sample_file}")
    if not CHROME.exists():
        raise SystemExit("Chrome nao encontrado.")
    user_data = tempfile.TemporaryDirectory()
    process = subprocess.Popen(
        [
            str(CHROME),
            "--headless=new",
            "--disable-gpu",
            "--disable-software-rasterizer",
            "--disable-extensions",
            "--no-sandbox",
            f"--remote-debugging-port={PORT}",
            f"--user-data-dir={user_data.name}",
            URL,
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        deadline = time.time() + 15
        targets = []
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json/list", timeout=2) as response:
                    targets = json.loads(response.read().decode("utf-8"))
                    if targets:
                        break
            except Exception:
                time.sleep(0.2)
        if not targets:
            raise RuntimeError("Chrome DevTools nao iniciou.")
        target = next(
            (
                item
                for item in targets
                if item.get("type") == "page" and item.get("url", "").startswith(URL)
            ),
            next(item for item in targets if item.get("type") == "page"),
        )
        cdp = CDP(target["webSocketDebuggerUrl"])
        try:
            cdp.command("Page.enable")
            cdp.command("Runtime.enable")
            cdp.command("DOM.enable")
            cdp.command("Network.enable")
            cdp.wait_eval("location.href.startsWith('http://127.0.0.1:8000') && document.readyState === 'complete'")
            cdp.eval("localStorage.clear()")
            cdp.command("Page.navigate", {"url": URL})
            cdp.wait_eval("location.href.startsWith('http://127.0.0.1:8000') && document.readyState === 'complete'")
            cdp.set_file("#file-input", sample_file)
            cdp.wait_eval(f"document.getElementById('selected-file').innerText.includes({json.dumps(sample_file.name)})")
            cdp.wait_eval("document.getElementById('continue-file').disabled === true")
            cdp.eval("document.getElementById('upload-button').click()")
            cdp.wait_eval(
                f"document.getElementById('file-profile').innerText.includes({json.dumps(sample_file.name)}) && document.getElementById('continue-file').disabled === false",
                timeout=20,
            )
            if upload_only:
                assert_upload_network(cdp)
                print("browser_upload_smoke=ok")
                return
            cdp.eval("document.getElementById('continue-file').click()")
            cdp.wait_eval("document.getElementById('step-2').classList.contains('active')")
            cdp.eval("document.getElementById('confirm-clients').click()")
            cdp.wait_eval("document.getElementById('step-3').classList.contains('active')")
            cdp.eval(
                """
                (() => {
                  const choices = { atendimento: "cliente_id", financeiro: "codigo_cliente", satisfacao: "id_cliente" };
                  Object.entries(choices).forEach(([sheet, column]) => {
                    const select = document.querySelector(`.entity-key[data-sheet="${sheet}"]`);
                    if (select) {
                      select.value = column;
                      select.dispatchEvent(new Event("change", { bubbles: true }));
                    }
                  });
                  document.getElementById("confirm-relationships").click();
                  return true;
                })()
                """
            )
            cdp.wait_eval("document.getElementById('step-4').classList.contains('active')")
            cdp.eval(
                """
                (() => {
                  const roles = [
                    ["clientes", "nome", "CONTEXT"],
                    ["clientes", "plano", "CONTEXT"],
                    ["clientes", "valor_mensal", "BUSINESS_VALUE"],
                    ["atendimento", "sla", "METRIC"],
                    ["financeiro", "dias_atraso", "METRIC"],
                    ["satisfacao", "nps", "METRIC"]
                  ];
                  roles.forEach(([sheet, column, role]) => {
                    const select = document.querySelector(`.role[data-sheet="${sheet}"][data-column="${column}"]`);
                    if (select) {
                      select.value = role;
                      select.dispatchEvent(new Event("change", { bubbles: true }));
                    }
                  });
                  return document.querySelectorAll(".metric-card").length;
                })()
                """
            )
            cdp.wait_eval("document.querySelectorAll('.metric-card').length === 3")
            cdp.eval(
                """
                (() => {
                  const setup = {
                    "atendimento|||sla": { type: "LOW_IS_RISK", weight: "2", aggregation: "RECENT_MEAN" },
                    "financeiro|||dias_atraso": { type: "HIGH_IS_RISK", weight: "3", aggregation: "RECENT_MEAN" },
                    "satisfacao|||nps": { type: "LOW_IS_RISK", weight: "4", aggregation: "LATEST" }
                  };
                  Object.entries(setup).forEach(([key, cfg]) => {
                    const card = document.querySelector(`[data-key="${key}"]`);
                    card.querySelector(".generic-type").value = cfg.type;
                    card.querySelector(".generic-type").dispatchEvent(new Event("change", { bubbles: true }));
                    const again = document.querySelector(`[data-key="${key}"]`);
                    again.querySelector(".weight").value = cfg.weight;
                    again.querySelector(".weight").dispatchEvent(new Event("change", { bubbles: true }));
                    again.querySelector(".aggregation").value = cfg.aggregation;
                    again.querySelector(".aggregation").dispatchEvent(new Event("change", { bubbles: true }));
                  });
                  document.getElementById("review-button").click();
                  return true;
                })()
                """
            )
            cdp.wait_eval("document.getElementById('step-5').classList.contains('active')", timeout=20)
            cdp.eval("document.getElementById('run-button').click()")
            cdp.wait_eval("document.getElementById('step-6').classList.contains('active') && document.getElementById('ranking').innerText.includes('C004')", timeout=20)
            errors = [
                event
                for event in cdp.events
                if event.get("method") in {"Runtime.exceptionThrown", "Log.entryAdded"}
            ]
            if errors:
                raise RuntimeError(errors)
            assert_upload_network(cdp)
            print("browser_smoke=ok")
        finally:
            cdp.close()
    finally:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        try:
            user_data.cleanup()
        except PermissionError:
            pass


def assert_upload_network(cdp: CDP):
    errors = [
        event
        for event in cdp.events
        if event.get("method") in {"Runtime.exceptionThrown", "Log.entryAdded"}
    ]
    if errors:
        raise RuntimeError(errors)
    responses = [
        event["params"]["response"]
        for event in cdp.events
        if event.get("method") == "Network.responseReceived"
    ]
    upload_statuses = [
        response["status"]
        for response in responses
        if response.get("url", "").endswith("/api/files/upload")
    ]
    profile_statuses = [
        response["status"]
        for response in responses
        if "/api/files/" in response.get("url", "") and response.get("url", "").endswith("/profile")
    ]
    if 200 not in upload_statuses:
        raise RuntimeError(f"POST /api/files/upload nao retornou 200: {upload_statuses}")
    if 200 not in profile_statuses:
        raise RuntimeError(f"GET /api/files/{{id}}/profile nao retornou 200: {profile_statuses}")


if __name__ == "__main__":
    main()
