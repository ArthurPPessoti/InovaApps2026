from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from browser_smoke import CDP  # noqa: E402


CHROME = Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe")
URL = "http://127.0.0.1:8000/"
PORT = 9224


def main():
    if not CHROME.exists():
        raise SystemExit("Chrome nao encontrado.")

    with tempfile.TemporaryDirectory() as data_dir:
        sample_file = Path(data_dir) / "binary_respondeu.csv"
        sample_file.write_text(
            "id,respondeu\nC1,1\nC1,0\nC1,1\nC2,0\nC2,1\n",
            encoding="utf-8",
        )
        user_data = tempfile.TemporaryDirectory()
        process = subprocess.Popen(
            [
                str(CHROME),
                "--headless=new",
                "--disable-gpu",
                "--disable-software-rasterizer",
                "--disable-extensions",
                "--no-sandbox",
                f"--remote-debugging-port={PORT}",
                f"--user-data-dir={user_data.name}",
                URL,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            cdp = connect()
            try:
                cdp.command("Page.enable")
                cdp.command("Runtime.enable")
                cdp.command("DOM.enable")
                cdp.command("Network.enable")
                cdp.wait_eval("location.href.startsWith('http://127.0.0.1:8000') && document.readyState === 'complete'")
                cdp.eval("localStorage.clear()")
                cdp.command("Page.navigate", {"url": URL})
                cdp.wait_eval("document.readyState === 'complete'")
                cdp.set_file("#file-input", sample_file)
                cdp.eval("document.getElementById('upload-button').click()")
                cdp.wait_eval("document.getElementById('continue-file').disabled === false", timeout=20)
                cdp.eval("document.getElementById('continue-file').click()")
                cdp.wait_eval("document.getElementById('step-2').classList.contains('active')")
                cdp.eval("document.getElementById('confirm-clients').click()")
                cdp.wait_eval("document.getElementById('step-3').classList.contains('active')")
                cdp.eval("document.getElementById('confirm-relationships').click()")
                cdp.wait_eval("document.getElementById('step-4').classList.contains('active')")
                cdp.eval(
                    """
                    (() => {
                      const role = document.querySelector('.role[data-sheet="Dados"][data-column="respondeu"]');
                      role.value = "METRIC";
                      role.dispatchEvent(new Event("change", { bubbles: true }));
                      const card = document.querySelector('[data-key="Dados|||respondeu"]');
                      card.querySelector(".generic-type").value = "BINARY_RISK";
                      card.querySelector(".generic-type").dispatchEvent(new Event("change", { bubbles: true }));
                      return true;
                    })()
                    """
                )
                cdp.wait_eval('document.querySelectorAll("[data-key=\\"Dados|||respondeu\\"] .mapping-risk").length === 2')
                cdp.eval(
                    """
                    (() => {
                      const card = document.querySelector('[data-key="Dados|||respondeu"]');
                      const one = card.querySelector('.mapping-risk[data-value="1"]');
                      const zero = card.querySelector('.mapping-risk[data-value="0"]');
                      one.value = "0";
                      zero.value = "1";
                      one.dispatchEvent(new Event("change", { bubbles: true }));
                      zero.dispatchEvent(new Event("change", { bubbles: true }));
                      document.querySelector('[data-key="Dados|||respondeu"] .done-indicator').click();
                      return true;
                    })()
                    """
                )
                cdp.wait_eval('document.getElementById("toast").textContent === "Indicador configurado."')
                cdp.eval('document.getElementById("review-button").click()')
                cdp.wait_eval("document.getElementById('step-5').classList.contains('active')", timeout=20)
                cdp.eval('document.querySelector(".back-button[data-back=\\"4\\"]").click()')
                cdp.wait_eval("document.getElementById('step-4').classList.contains('active')")
                persisted = cdp.eval(
                    """
                    (() => {
                      const card = document.querySelector('[data-key="Dados|||respondeu"]');
                      const metric = currentAnalysisConfig().metrics.find(item => item.source_column === "respondeu");
                      return {
                        one: card.querySelector('.mapping-risk[data-value="1"]').value,
                        zero: card.querySelector('.mapping-risk[data-value="0"]').value,
                        mapping: metric.binary_mapping,
                        scaleHidden: card.querySelector(".scale-row").classList.contains("hidden")
                      };
                    })()
                    """
                )
                if persisted != {"one": "0", "zero": "1", "mapping": {"1": 0, "0": 1}, "scaleHidden": True}:
                    raise RuntimeError(f"Mapeamento binario nao persistiu: {persisted}")
                page_errors = [
                    event
                    for event in cdp.events
                    if event.get("method") in {"Runtime.exceptionThrown", "Log.entryAdded"}
                ]
                if page_errors:
                    raise RuntimeError(page_errors)
                print("browser_binary_mapping_smoke=ok pageErrors=0")
            finally:
                cdp.close()
        finally:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            try:
                user_data.cleanup()
            except PermissionError:
                pass


def connect() -> CDP:
    deadline = time.time() + 15
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json/list", timeout=2) as response:
                targets = json.loads(response.read().decode("utf-8"))
                target = next(item for item in targets if item.get("type") == "page")
                return CDP(target["webSocketDebuggerUrl"])
        except Exception:
            time.sleep(0.2)
    raise RuntimeError("Chrome DevTools nao iniciou.")


if __name__ == "__main__":
    main()
