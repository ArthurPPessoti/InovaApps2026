from __future__ import annotations

import json
import subprocess
import tempfile
import time
import urllib.request

from browser_smoke import CDP, CHROME, PORT, ROOT, URL


def _launch():
    user_data = tempfile.TemporaryDirectory()
    process = subprocess.Popen(
        [
            str(CHROME),
            "--headless=new",
            "--disable-gpu",
            "--disable-software-rasterizer",
            "--disable-extensions",
            "--no-sandbox",
            f"--remote-debugging-port={PORT}",
            f"--user-data-dir={user_data.name}",
            URL,
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    deadline = time.time() + 15
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json/list", timeout=2) as response:
                targets = json.loads(response.read().decode("utf-8"))
                target = next(
                    (
                        item
                        for item in targets
                        if item.get("type") == "page" and item.get("url", "").startswith(URL)
                    ),
                    None,
                )
                if target:
                    return process, user_data, CDP(target["webSocketDebuggerUrl"])
        except Exception:
            time.sleep(0.2)
    raise RuntimeError("Chrome DevTools nao iniciou.")


def main():
    process, user_data, cdp = _launch()
    try:
        cdp.command("Page.enable")
        cdp.command("Runtime.enable")
        cdp.command("DOM.enable")
        cdp.command("Network.enable")
        cdp.wait_eval("location.href.startsWith('http://127.0.0.1:8000') && document.readyState === 'complete'")
        cdp.eval("localStorage.clear()")
        cdp.command("Page.navigate", {"url": URL})
        cdp.wait_eval("location.href.startsWith('http://127.0.0.1:8000') && document.readyState === 'complete'")
        cdp.set_file("#file-input", ROOT / "sample_data" / "demo_servicos.xlsx")
        cdp.eval("document.getElementById('upload-button').click()")
        cdp.wait_eval("document.getElementById('continue-file').disabled === false", timeout=20)
        cdp.eval("document.getElementById('continue-file').click()")
        cdp.wait_eval("document.getElementById('step-2').classList.contains('active')")
        cdp.eval("document.getElementById('confirm-clients').click()")
        cdp.wait_eval("document.getElementById('step-3').classList.contains('active')")
        cdp.eval(
            """
            (() => {
              const choices = { atendimento: "cliente_id", financeiro: "codigo_cliente", satisfacao: "id_cliente" };
              Object.entries(choices).forEach(([sheet, column]) => {
                const select = document.querySelector(`.entity-key[data-sheet="${sheet}"]`);
                if (select) {
                  select.value = column;
                  select.dispatchEvent(new Event("change", { bubbles: true }));
                }
              });
              document.getElementById("confirm-relationships").click();
              return true;
            })()
            """
        )
        cdp.wait_eval("document.getElementById('step-4').classList.contains('active')")
        cdp.eval(
            """
            (() => {
              const roles = [
                ["clientes", "status", "STATUS_FILTER"],
                ["atendimento", "sla", "METRIC"],
                ["atendimento", "chamados", "METRIC"],
                ["financeiro", "dias_atraso", "METRIC"],
                ["satisfacao", "nps", "METRIC"]
              ];
              roles.forEach(([sheet, column, role]) => {
                const select = document.querySelector(`.role[data-sheet="${sheet}"][data-column="${column}"]`);
                select.value = role;
                select.dispatchEvent(new Event("change", { bubbles: true }));
              });
              return true;
            })()
            """
        )
        cdp.wait_eval("document.querySelectorAll('.metric-card').length === 5 && document.querySelectorAll('.status-card').length === 1")
        cdp.eval(
            """
            (() => {
              const statusCard = document.querySelector('.status-card');
              if (statusCard) {
                statusCard.querySelectorAll('.status-value').forEach(input => {
                  input.checked = input.value.toLowerCase().includes('ativo');
                  input.dispatchEvent(new Event('change', { bubbles: true }));
                });
              }
              const setup = {
                "atendimento|||sla": { type: "LOW_IS_RISK", weight: "15" },
                "atendimento|||chamados": { type: "HIGH_IS_RISK", weight: "10" },
                "financeiro|||dias_atraso": { type: "HIGH_IS_RISK", weight: "25" },
                "satisfacao|||nps": { type: "LOW_IS_RISK", weight: "5" }
              };
              Object.entries(setup).forEach(([key, cfg]) => {
                let card = document.querySelector(`[data-key="${key}"]`);
                card.querySelector(".generic-type").value = cfg.type;
                card.querySelector(".generic-type").dispatchEvent(new Event("change", { bubbles: true }));
                card = document.querySelector(`[data-key="${key}"]`);
                card.querySelector(".weight").value = cfg.weight;
                card.querySelector(".weight").dispatchEvent(new Event("input", { bubbles: true }));
              });
              window.__validationBeforeReview = validateBeforeRun();
              document.getElementById("review-button").click();
              return true;
            })()
            """
        )
        try:
            cdp.wait_eval("document.getElementById('step-5').classList.contains('active')", timeout=20)
        except TimeoutError:
            validation = cdp.eval("JSON.stringify(window.__validationBeforeReview || [])")
            status_debug = cdp.eval(
                "JSON.stringify({cards: document.querySelectorAll('.status-card').length, text: document.getElementById('metric-cards').innerText, settings: state.columnSettings})"
            )
            raise AssertionError(f"Revisao bloqueada: {validation}; status_debug={status_debug}")
        review = cdp.eval("document.getElementById('review').innerText")
        config_before = json.loads(cdp.eval("JSON.stringify(buildConfig())"))
        cdp.eval("document.getElementById('run-button').click()")
        cdp.wait_eval("document.getElementById('step-6').classList.contains('active')", timeout=20)
        run_requests = [
            event["params"]["request"].get("postData")
            for event in cdp.events
            if event.get("method") == "Network.requestWillBeSent"
            and event["params"]["request"].get("url", "").endswith("/api/analysis/run")
        ]
        js_errors = [
            event
            for event in cdp.events
            if event.get("method") in {"Runtime.exceptionThrown", "Log.entryAdded"}
        ]
        if js_errors:
            raise AssertionError({"javascript_errors": js_errors})
        run_request = json.loads(run_requests[-1])
        expected = {
            ("atendimento", "sla"): ("LOW_IS_RISK", 15),
            ("atendimento", "chamados"): ("HIGH_IS_RISK", 10),
            ("financeiro", "dias_atraso"): ("HIGH_IS_RISK", 25),
            ("satisfacao", "nps"): ("LOW_IS_RISK", 5),
        }
        review_config = {
            (metric["source_sheet"], metric["source_column"]): (metric["generic_type"], metric["weight"])
            for metric in config_before["metrics"]
        }
        request_config = {
            (metric["source_sheet"], metric["source_column"]): (metric["generic_type"], metric["weight"])
            for metric in run_request["config"]["metrics"]
        }
        if review_config != expected:
            raise AssertionError({"review_config": review_config, "expected": expected, "review": review})
        if request_config != expected:
            raise AssertionError({"request_config": request_config, "expected": expected})
        expected_filter = [{"source_sheet": "clientes", "source_column": "status", "allowed_values": ["Ativo"]}]
        if run_request["config"].get("status_filters") != expected_filter:
            raise AssertionError({"status_filters": run_request["config"].get("status_filters")})
        used_config_text = cdp.eval("document.getElementById('used-config').innerText")
        for label in ["Sla", "Chamados", "Dias Atraso", "Nps"]:
            if label not in used_config_text:
                raise AssertionError(f"Configuracao usada nao mostra {label}")
        print("config_request_smoke=ok")
    finally:
        cdp.close()
        process.terminate()
        try:
            process.wait(timeout=5)
        except Exception:
            process.kill()
        try:
            user_data.cleanup()
        except Exception:
            pass


if __name__ == "__main__":
    main()
