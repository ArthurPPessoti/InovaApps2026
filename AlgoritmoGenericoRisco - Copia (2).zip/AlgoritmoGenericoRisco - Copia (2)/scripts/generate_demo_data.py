from __future__ import annotations

from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SAMPLE_DIR = ROOT / "sample_data"


def demo_servicos():
    clientes = pd.DataFrame(
        [
            ["C001", "Alfa Ltda", "Enterprise", "Ativo", 12000],
            ["C002", "Beta SA", "PME", "Ativo", 2800],
            ["C003", "Gamma ME", "PME", "Ativo", 1800],
            ["C004", "Delta Corp", "Enterprise", "Ativo", 21000],
            ["C005", "Epsilon", "PME", "Cancelado", 900],
        ],
        columns=["cliente_id", "nome", "plano", "status", "valor_mensal"],
    )
    atendimento = pd.DataFrame(
        [
            ["C001", "2024-01", 98, 1],
            ["C001", "2024-02", 97, 1],
            ["C001", "2024-03", 96, 2],
            ["C002", "2024-01", 85, 4],
            ["C002", "2024-02", 80, 5],
            ["C002", "2024-03", 75, 7],
            ["C003", "2024-01", 93, 2],
            ["C003", "2024-02", 91, 2],
            ["C003", "2024-03", 90, 3],
            ["C004", "2024-01", 70, 7],
            ["C004", "2024-02", 65, 10],
            ["C004", "2024-03", 58, 13],
        ],
        columns=["cliente_id", "mes", "sla", "chamados"],
    )
    financeiro = pd.DataFrame(
        [
            ["C001", "2024-01", 0],
            ["C001", "2024-02", 0],
            ["C001", "2024-03", 1],
            ["C002", "2024-01", 2],
            ["C002", "2024-02", 7],
            ["C002", "2024-03", 9],
            ["C003", "2024-01", 0],
            ["C003", "2024-02", 0],
            ["C003", "2024-03", 0],
            ["C004", "2024-01", 10],
            ["C004", "2024-02", 18],
            ["C004", "2024-03", 24],
        ],
        columns=["codigo_cliente", "mes", "dias_atraso"],
    )
    satisfacao = pd.DataFrame(
        [
            ["C001", "2024-03", 8],
            ["C002", "2024-03", 5],
            ["C003", "2024-03", 7],
            ["C004", "2024-03", 2],
        ],
        columns=["id_cliente", "competencia", "nps"],
    )
    path = SAMPLE_DIR / "demo_servicos.xlsx"
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        clientes.to_excel(writer, sheet_name="clientes", index=False)
        atendimento.to_excel(writer, sheet_name="atendimento", index=False)
        financeiro.to_excel(writer, sheet_name="financeiro", index=False)
        satisfacao.to_excel(writer, sheet_name="satisfacao", index=False)
    return path


def demo_academia():
    membros = pd.DataFrame(
        [
            ["A-10", "Rafaela", "Gold", "ativo", 199],
            ["A-11", "Bruno", "Basic", "ativo", 89],
            ["A-12", "Carla", "Basic", "ativo", 89],
            ["A-13", "Diego", "Gold", "ativo", 199],
        ],
        columns=["matricula", "aluno", "pacote", "situacao", "mensalidade"],
    )
    presencas = pd.DataFrame(
        [
            ["A-10", "2024-01", 18],
            ["A-10", "2024-02", 17],
            ["A-10", "2024-03", 16],
            ["A-11", "2024-01", 12],
            ["A-11", "2024-02", 8],
            ["A-11", "2024-03", 3],
            ["A-12", "2024-01", 6],
            ["A-12", "2024-02", 5],
            ["A-12", "2024-03", 4],
            ["A-13", "2024-01", 20],
            ["A-13", "2024-02", 20],
            ["A-13", "2024-03", 19],
        ],
        columns=["cod_assinante", "periodo", "visitas"],
    )
    pagamentos = pd.DataFrame(
        [
            ["A-10", "em dia"],
            ["A-11", "atrasado"],
            ["A-12", "em dia"],
            ["A-13", "em dia"],
        ],
        columns=["assinante_ref", "pagamento"],
    )
    path = SAMPLE_DIR / "demo_academia.xlsx"
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        membros.to_excel(writer, sheet_name="membros", index=False)
        presencas.to_excel(writer, sheet_name="frequencia", index=False)
        pagamentos.to_excel(writer, sheet_name="pagamentos", index=False)
    return path


def demo_csv():
    path = SAMPLE_DIR / "demo_unico.csv"
    pd.DataFrame(
        [
            ["X1", "Empresa X", 2, 9, 95],
            ["X2", "Empresa Y", 8, 4, 62],
            ["X3", "Empresa Z", 0, 8, 88],
        ],
        columns=["account", "nome", "reclamacoes", "satisfacao", "uso"],
    ).to_csv(path, index=False, encoding="utf-8-sig")
    return path


def main():
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    paths = [demo_servicos(), demo_academia(), demo_csv()]
    for path in paths:
        print(path)


if __name__ == "__main__":
    main()
