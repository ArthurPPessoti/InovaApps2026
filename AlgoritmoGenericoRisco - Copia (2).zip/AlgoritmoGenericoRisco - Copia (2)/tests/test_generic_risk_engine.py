import math

import pandas as pd

from core.generic_risk_engine import (
    calculate_contributions,
    calculate_coverage,
    calculate_score,
    calculate_trend_risk,
    normalize_binary_risk,
    normalize_categorical_risk,
    normalize_high_is_risk,
    normalize_low_is_risk,
    normalize_target_range,
    normalize_weights,
    run_generic_analysis,
)
from core.generic_schema import AnalysisConfig, MetricConfig
from core.entity_metric_builder import build_entity_metrics
from core.generic_schema import validate_analysis_config


def test_numeric_normalizers():
    assert normalize_high_is_risk(75, 0, 100) == 0.75
    assert normalize_high_is_risk(150, 0, 100) == 1
    assert normalize_low_is_risk(25, 0, 100) == 0.75


def test_sla_low_is_risk_regression():
    assert normalize_low_is_risk(0, 0, 100) == 1
    assert normalize_low_is_risk(50, 0, 100) == 0.5
    assert normalize_low_is_risk(100, 0, 100) == 0


def test_binary_and_categorical_normalizers():
    assert normalize_binary_risk("Sim", {"Sim": 1, "Nao": 0}) == 1
    assert normalize_categorical_risk("B", {"A": 0, "B": 0.5, "C": 1}) == 0.5


def test_target_range_normalizer():
    assert normalize_target_range(50, 40, 60, 0, 100) == 0
    assert normalize_target_range(20, 40, 60, 0, 100) == 0.5
    assert normalize_target_range(80, 40, 60, 0, 100) == 0.5


def test_trend_risk_up_and_down():
    up = calculate_trend_risk(pd.Series([-5, 0, 10]), "UP_IS_RISK")
    down = calculate_trend_risk(pd.Series([-5, 0, 10]), "DOWN_IS_RISK")
    assert list(up.round(2)) == [0, 0, 1]
    assert list(down.round(2)) == [1, 0, 0]


def test_weights_coverage_score_and_contributions():
    metrics = [
        MetricConfig("s", "a", "A", "HIGH_IS_RISK", weight=3),
        MetricConfig("s", "b", "B", "LOW_IS_RISK", weight=1),
    ]
    weights = normalize_weights(metrics)
    assert weights == {"A": 0.75, "B": 0.25}
    assert calculate_coverage(3, 4) == 75
    assert calculate_score(2, 4) == 50
    contributions = calculate_contributions({"A": 0.8, "B": 0.4}, weights)
    assert math.isclose(contributions["A"]["contribution_points"], 60)
    assert math.isclose(contributions["B"]["contribution_points"], 10)


def test_configured_weights_are_preserved():
    labels_and_weights = [
        ("SLA", 15),
        ("Tempo", 10),
        ("Reclamacoes", 15),
        ("Uso", 25),
        ("Atraso", 15),
        ("Respondeu", 5),
        ("NPS", 15),
    ]
    metrics = [
        MetricConfig("s", label.lower(), label, "HIGH_IS_RISK", weight=weight)
        for label, weight in labels_and_weights
    ]
    assert sum(metric.weight for metric in metrics) == 100
    assert [metric.weight for metric in metrics] == [15, 10, 15, 25, 15, 5, 15]


def test_missing_ignore_and_reweight_reconstructs_score():
    df = pd.DataFrame(
        {
            "canonical_entity_id": ["C1", "C2"],
            "metric__s_a": [100, 50],
            "metric__s_b": [pd.NA, 0],
        }
    )
    config = AnalysisConfig(
        entity_keys={"s": "id"},
        metrics=[
            MetricConfig("s", "a", "A", "HIGH_IS_RISK", weight=1, scale_mode="MANUAL", scale_min=0, scale_max=100),
            MetricConfig("s", "b", "B", "HIGH_IS_RISK", weight=1, scale_mode="MANUAL", scale_min=0, scale_max=100),
        ],
    )
    result = run_generic_analysis(df, config)
    c1 = next(row for row in result["ranking"] if row["Entidade"] == "C1")
    assert c1["Score"] == 100
    assert c1["Cobertura"] == 50
    for row in result["ranking"]:
        total = sum(item["contribution_points"] for item in row["Contribuicoes"].values())
        assert math.isclose(total, row["Score"], abs_tol=0.01)


def test_binary_is_mapped_before_recent_mean_aggregation():
    sheets = {
        "eventos": pd.DataFrame(
            {
                "id": ["C1", "C1", "C1", "C1"],
                "mes": ["2024-01", "2024-02", "2024-02", "2024-03"],
                "flag": ["Nao", "Sim", "Nao", "Sim"],
            }
        )
    }
    metric = MetricConfig(
        "eventos",
        "flag",
        "flag",
        "BINARY_RISK",
        aggregation="RECENT_MEAN",
        binary_mapping={"Sim": 1, "Nao": 0},
        time_column="mes",
        recent_periods=2,
    )
    consolidated, _ = build_entity_metrics(sheets, AnalysisConfig(entity_keys={"eventos": "id"}, metrics=[metric]))
    assert consolidated.loc[0, "metric__eventos_flag"] == 0.75


def test_recent_mean_uses_distinct_periods_not_last_rows():
    sheets = {
        "uso": pd.DataFrame(
            {
                "id": ["C1", "C1", "C1", "C1", "C1"],
                "mes": ["2024-01", "2024-02", "2024-02", "2024-03", "2024-03"],
                "valor": [100, 0, 0, 10, 30],
            }
        )
    }
    metric = MetricConfig("uso", "valor", "valor", "HIGH_IS_RISK", aggregation="RECENT_MEAN", time_column="mes", recent_periods=2)
    consolidated, _ = build_entity_metrics(sheets, AnalysisConfig(entity_keys={"uso": "id"}, metrics=[metric]))
    assert consolidated.loc[0, "metric__uso_valor"] == 10


def test_non_discriminant_metric_is_removed_from_score_and_coverage():
    df = pd.DataFrame({"canonical_entity_id": ["C1", "C2"], "metric__s_a": [5, 5]})
    config = AnalysisConfig(entity_keys={"s": "id"}, metrics=[MetricConfig("s", "a", "A", "HIGH_IS_RISK")])
    result = run_generic_analysis(df, config)
    assert len(result["insufficient_data"]) == 2
    assert result["ranking"] == []
    assert result["warnings"] == ["A metrica A nao apresentou variabilidade suficiente e foi desconsiderada nesta analise."]
    assert all(row["non_discriminant"] for row in result["details"])


def test_imputed_missing_value_does_not_raise_coverage_and_low_coverage_is_split():
    df = pd.DataFrame(
        {
            "canonical_entity_id": ["C1"],
            "metric__s_a": [100],
            "metric__s_b": [pd.NA],
            "metric__s_c": [pd.NA],
        }
    )
    metrics = [
        MetricConfig("s", "a", "A", "HIGH_IS_RISK", scale_mode="MANUAL", scale_min=0, scale_max=100),
        MetricConfig("s", "b", "B", "HIGH_IS_RISK", scale_mode="MANUAL", scale_min=0, scale_max=100, missing_strategy="NEUTRAL"),
        MetricConfig("s", "c", "C", "HIGH_IS_RISK", scale_mode="MANUAL", scale_min=0, scale_max=100, missing_strategy="NEUTRAL"),
    ]
    result = run_generic_analysis(df, AnalysisConfig(entity_keys={"s": "id"}, metrics=metrics))
    row = result["insufficient_data"][0]
    assert row["Score"] == 66.67
    assert row["Cobertura"] == 33.33
    assert row["operational_status"] == "Dados insuficientes"


def test_trend_requires_two_distinct_windows_and_scores_when_available():
    sheets = {
        "serie": pd.DataFrame(
            {
                "id": ["C1"] * 6 + ["C2"] * 6,
                "mes": list(range(1, 7)) + list(range(1, 7)),
                "valor": [1, 2, 3, 5, 6, 7, 4, 4, 4, 4, 4, 4],
            }
        )
    }
    metric = MetricConfig(
        "serie",
        "valor",
        "tendencia",
        "TREND_RISK",
        aggregation="TREND",
        trend_direction="UP_IS_RISK",
        time_column="mes",
        recent_periods=3,
    )
    consolidated, metadata = build_entity_metrics(sheets, AnalysisConfig(entity_keys={"serie": "id"}, metrics=[metric]))
    assert metadata["trend_columns"]["metric__serie_valor"]["previous_mean"]["C1"] == 2
    result = run_generic_analysis(consolidated, AnalysisConfig(entity_keys={"serie": "id"}, metrics=[metric]))
    assert result["ranking"][0]["Entidade"] == "C1"
    assert result["ranking"][0]["Score"] == 100


def test_validation_matrix_rejects_incompatible_aggregations():
    errors = validate_analysis_config(
        AnalysisConfig(
            entity_keys={"s": "id"},
            metrics=[
                MetricConfig("s", "categoria", "Categoria", "CATEGORICAL_RISK", aggregation="SUM"),
                MetricConfig("s", "faixa", "Faixa", "TARGET_RANGE", aggregation="SUM", healthy_min=1, healthy_max=2),
                MetricConfig("s", "delta", "Delta", "TREND_RISK", aggregation="MEAN", time_column="mes"),
            ],
        )
    )
    assert any("Categorias nao podem ser somadas" in error for error in errors)
    assert any("Faixa saudavel nao aceita soma" in error for error in errors)
    assert any("Tendencia deve usar agregacao Tendencia" in error for error in errors)
