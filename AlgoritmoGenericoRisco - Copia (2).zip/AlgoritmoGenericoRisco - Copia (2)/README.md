# Risk Analysis

Protótipo local para gerar uma análise explicável de risco de cancelamento a partir de dados próprios da empresa.

O sistema recebe dados específicos, transforma indicadores configurados pelo usuário em métricas genéricas de risco e aplica uma fórmula universal ponderada para produzir um ranking de entidades com maior risco.

## Como rodar

No Windows, dê duplo clique em `iniciar.bat`.

Ou rode manualmente:

```bash
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python server.py
```

Acesse:

```text
http://127.0.0.1:8000
```

## Tecnologias

- Backend: Python com `http.server`, `BaseHTTPRequestHandler` e `ThreadingHTTPServer`
- Frontend: HTML, CSS e JavaScript puro
- Análise: `pandas`, `numpy`, `openpyxl`
- Testes: `pytest`

Não há Gemini, AutoML, scikit-learn, regressão logística ou treinamento.

## Fluxo guiado

A interface usa um assistente em 6 passos:

1. Arquivo: envie CSV ou XLSX e veja abas, colunas e possiveis clientes.
2. Clientes: confirme a aba principal e a coluna que identifica cada cliente.
3. Abas: confirme como as abas pertencem ao mesmo cliente ou ignore abas que nao entram na analise.
4. Indicadores: escolha poucas colunas relevantes, defina regra, peso e agregacao.
5. Revisao: confira clientes, abas, indicadores, pesos e formula antes de executar.
6. Resultado: veja o ranking, detalhes por cliente, relatorio imprimivel, Excel e CSV.

O usuario nao precisa conhecer nomes internos como `ENTITY_ID`, `METRIC` ou `HIGH_IS_RISK`; a tela mostra textos em portugues simples.

## Entidade canônica

Cada aba pode usar um nome diferente para a entidade, como `cliente_id`, `codigo_cliente`, `account` ou `matricula`.

Internamente todas as chaves são convertidas para:

```text
canonical_entity_id
```

O valor é convertido para texto e aparado nas pontas, preservando zeros à esquerda quando o arquivo foi lido como texto.

## Relações entre abas

O módulo `core/relationship_detector.py` sugere possíveis relações usando:

- semelhança do nome da coluna;
- compatibilidade de tipo;
- valores compartilhados;
- unicidade.

As sugestões nunca são aplicadas automaticamente. A interface exige confirmação do usuário.

## Como evita multiplicação de linhas

O módulo `core/entity_metric_builder.py` nunca junta tabelas brutas com várias linhas por entidade.

O pipeline é:

```text
aba -> identificar entidade -> agregar métricas por entidade -> 1 linha por entidade
```

Somente depois disso as abas agregadas são unidas por `canonical_entity_id`, com validação `one_to_one`.

## Tipos genéricos de risco

Foram implementados os sete tipos:

- `HIGH_IS_RISK`: quanto maior o valor, maior o risco.
- `LOW_IS_RISK`: quanto menor o valor, maior o risco.
- `BINARY_RISK`: valores mapeados pelo usuário para 0 a 1.
- `CATEGORICAL_RISK`: categorias mapeadas pelo usuário para 0 a 1.
- `TARGET_RANGE`: risco zero dentro de uma faixa saudável; aumenta pela distância fora da faixa.
- `TREND_RISK`: compara média anterior e média recente; subida ou queda pode gerar risco.
- `INFORMATIONAL`: não entra no score.

Na interface esses nomes tecnicos aparecem como rotulos em portugues, por exemplo "Quanto maior, maior o risco" e "Mudanca ao longo do tempo".

## Agregações

Implementadas:

- `LATEST`
- `MEAN`
- `RECENT_MEAN`
- `SUM`
- `MIN`
- `MAX`
- `FIRST`

`RECENT_MEAN` usa a janela padrão de 3 períodos em `config.py`.

## Escalas

Cada métrica numérica pode usar escala manual ou automática.

Na escala automática, o sistema usa percentil 5 e percentil 95 quando há dados suficientes. Para amostras pequenas, usa mínimo e máximo.

## Fórmula

Para cada entidade:

```text
weighted_sum = soma(metric_risk * peso_disponivel)
available_weight_sum = soma(pesos das metricas disponiveis)
risk_score = 100 * weighted_sum / available_weight_sum
```

O resultado é um índice de 0 a 100. Não é uma probabilidade.

## Ausentes e cobertura

Estratégias:

- `IGNORE_AND_REWEIGHT`: remove a métrica daquela entidade e redistribui os pesos disponíveis.
- `NEUTRAL`: usa risco 0,5.
- `RISK`: usa risco 1.
- `HEALTHY`: usa risco 0.
- `CUSTOM`: usa valor customizado de 0 a 1.

Cobertura:

```text
cobertura = peso_disponivel / peso_total_configurado
```

## Explicação do score

Para cada métrica o sistema guarda:

- valor agregado;
- regra;
- risco normalizado;
- peso;
- peso normalizado;
- contribuição em pontos.

A soma das contribuições reconstrói o score.

## Exportações

O Excel `analise_risco.xlsx` contém:

- Ranking
- Detalhes
- Configuração
- Metodologia
- Dados Consolidados

Também é gerado `ranking.csv`.

## Templates

Templates são JSON salvos em:

```text
storage/templates/
```

Eles guardam relações, chaves, métricas, pesos, regras, agregações, escalas e tratamento de ausentes.

Ao reusar um template, o sistema valida:

- compatível;
- compatível com avisos;
- incompatível.

Na tela inicial, ao carregar um template junto de uma nova planilha, a aplicacao informa quanto das colunas esperadas foi encontrado e reaplica a configuracao para revisao.

## Teste de navegador

Com o servidor rodando, execute:

```bash
python scripts/browser_smoke.py
```

Esse teste abre o Chrome em modo headless, acessa a interface real, envia `sample_data/demo_servicos.xlsx`, percorre o wizard e gera o ranking.

## Dados de demonstração

Gere bases de exemplo com:

```bash
python scripts/generate_demo_data.py
```

Arquivos gerados:

- `sample_data/demo_servicos.xlsx`
- `sample_data/demo_academia.xlsx`
- `sample_data/demo_unico.csv`

## Testes

```bash
python -m pytest -q
```
