from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


HORIZONTE_MESES = 2
TOP_N_OPERACIONAL = 10
RANDOM_STATE = 42

FEATURES_MODELO = [
    "abertos_media_3m",
    "sla_media_3m",
    "sla_tendencia_6m",
    "resolucao_tendencia_6m",
    "reclamacoes_3m",
    "uso_media_3m",
    "uso_tendencia_6m",
    "atraso_max_3m",
    "reunioes_perdidas_pct_3m",
    "nps_ultimo",
    "nps_tendencia",
    "nps_nao_respostas_seguidas",
]


@dataclass
class ResultadoModelo:
    ranking: pd.DataFrame
    metricas: Dict[str, float | int | str]
    modelo: Pipeline
    coeficientes: pd.DataFrame
    atendimento: pd.DataFrame
    nps: pd.DataFrame
    clientes: pd.DataFrame
    situacao: pd.DataFrame
    mes_atual: str


def mes_para_indice(mes: str) -> int:
    ano, numero_mes = [int(x) for x in mes.split("-")]
    return ano * 12 + numero_mes - 1


def indice_para_mes(indice: int) -> str:
    return f"{indice // 12:04d}-{indice % 12 + 1:02d}"


def diferenca_meses(mes_inicial: str, mes_final: str) -> int:
    return mes_para_indice(mes_final) - mes_para_indice(mes_inicial)


def media_segura(valores, padrao: float = 0.0) -> float:
    serie = pd.to_numeric(pd.Series(list(valores)), errors="coerce").dropna()
    if serie.empty:
        return float(padrao)
    return float(serie.mean())


def carregar_dados(caminho_excel: str | Path) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    caminho_excel = Path(caminho_excel)
    clientes = pd.read_excel(caminho_excel, sheet_name="clientes")
    atendimento = pd.read_excel(caminho_excel, sheet_name="atendimento_mensal")
    nps = pd.read_excel(caminho_excel, sheet_name="pesquisas_nps")
    situacao = pd.read_excel(caminho_excel, sheet_name="situacao_clientes")

    for df in (clientes, atendimento, nps, situacao):
        df.dropna(how="all", inplace=True)

    atendimento["mes_ref"] = atendimento["mes_ref"].astype(str).str[:7]
    nps["mes_ref"] = nps["mes_ref"].astype(str).str[:7]
    situacao["mes_cancelamento"] = situacao["mes_cancelamento"].where(
        situacao["mes_cancelamento"].notna(), None
    )
    situacao["mes_cancelamento"] = situacao["mes_cancelamento"].apply(
        lambda x: str(x)[:7] if x is not None else None
    )
    clientes["inicio_contrato"] = pd.to_datetime(clientes["inicio_contrato"])

    return clientes, atendimento, nps, situacao


def calcular_features_cliente(
    cliente_id: str,
    mes_snapshot: str,
    clientes: pd.DataFrame,
    atendimento: pd.DataFrame,
    nps: pd.DataFrame,
) -> Dict[str, float]:
    dados_cliente = atendimento[
        (atendimento["cliente_id"] == cliente_id)
        & (atendimento["mes_ref"] <= mes_snapshot)
    ].sort_values("mes_ref")

    if dados_cliente.empty:
        raise ValueError(f"Sem histórico de atendimento para {cliente_id} em {mes_snapshot}.")

    cadastro = clientes.loc[clientes["cliente_id"] == cliente_id].iloc[0]
    recentes = dados_cliente.tail(3)
    anteriores = dados_cliente.iloc[-6:-3]

    sla_recente = media_segura(recentes["pct_sla_cumprido"], 100.0)
    sla_anterior = media_segura(anteriores["pct_sla_cumprido"], sla_recente) if not anteriores.empty else sla_recente

    resolucao_recente = media_segura(
        recentes["tempo_medio_resolucao_h"], float(cadastro["sla_contratado_h"])
    )
    resolucao_anterior = media_segura(
        anteriores["tempo_medio_resolucao_h"], resolucao_recente
    ) if not anteriores.empty else resolucao_recente

    uso_recente = media_segura(recentes["uso_plataforma_pct"], 0.0)
    uso_anterior = media_segura(anteriores["uso_plataforma_pct"], uso_recente) if not anteriores.empty else uso_recente

    reunioes_previstas = float(recentes["reunioes_previstas"].fillna(0).sum())
    reunioes_realizadas = float(recentes["reunioes_realizadas"].fillna(0).sum())
    pct_reunioes_perdidas = 100.0 * (reunioes_previstas - reunioes_realizadas) / max(reunioes_previstas, 1.0)

    historico_nps = nps[
        (nps["cliente_id"] == cliente_id) & (nps["mes_ref"] <= mes_snapshot)
    ].sort_values("mes_ref")

    respondidos = historico_nps[
        (historico_nps["respondeu"] == 1) & historico_nps["nota_nps"].notna()
    ]

    if not respondidos.empty:
        nps_ultimo = float(respondidos.iloc[-1]["nota_nps"])
    else:
        # Imputação neutra. O fato de não haver resposta é capturado separadamente.
        nps_ultimo = 7.0

    if len(respondidos) >= 2:
        nps_tendencia = float(respondidos.iloc[-1]["nota_nps"] - respondidos.iloc[-2]["nota_nps"])
    else:
        nps_tendencia = 0.0

    nao_respostas_seguidas = 0
    for _, linha in historico_nps.iloc[::-1].iterrows():
        if int(linha["respondeu"]) == 0:
            nao_respostas_seguidas += 1
        else:
            break

    inicio = cadastro["inicio_contrato"].strftime("%Y-%m")
    tempo_contrato = max(0, diferenca_meses(inicio, mes_snapshot))

    return {
        "abertos_media_3m": media_segura(recentes["chamados_abertos"]),
        "sla_media_3m": sla_recente,
        "sla_tendencia_6m": sla_recente - sla_anterior,
        "resolucao_tendencia_6m": resolucao_recente - resolucao_anterior,
        "reclamacoes_3m": float(recentes["reclamacoes_formais"].fillna(0).sum()),
        "uso_media_3m": uso_recente,
        "uso_tendencia_6m": uso_recente - uso_anterior,
        "atraso_max_3m": float(recentes["dias_atraso_pagamento"].fillna(0).max()),
        "reunioes_perdidas_pct_3m": pct_reunioes_perdidas,
        "nps_ultimo": nps_ultimo,
        "nps_tendencia": nps_tendencia,
        "nps_nao_respostas_seguidas": float(nao_respostas_seguidas),
        "tempo_contrato_meses": float(tempo_contrato),
    }


def montar_base_treinamento(
    clientes: pd.DataFrame,
    atendimento: pd.DataFrame,
    nps: pd.DataFrame,
    situacao: pd.DataFrame,
    horizonte_meses: int = HORIZONTE_MESES,
) -> pd.DataFrame:
    mes_final_base = atendimento["mes_ref"].max()
    ultimo_snapshot_rotulado = indice_para_mes(mes_para_indice(mes_final_base) - horizonte_meses)
    primeiro_snapshot = indice_para_mes(mes_para_indice(atendimento["mes_ref"].min()) + 2)

    cancelamentos = situacao.set_index("cliente_id")["mes_cancelamento"].to_dict()
    linhas: List[Dict[str, float | str | int]] = []

    for cliente_id, grupo in atendimento.groupby("cliente_id"):
        grupo = grupo.sort_values("mes_ref")
        mes_cancelamento = cancelamentos.get(cliente_id)

        for mes_snapshot in grupo["mes_ref"].tolist():
            if mes_snapshot < primeiro_snapshot or mes_snapshot > ultimo_snapshot_rotulado:
                continue
            if mes_cancelamento and mes_snapshot >= mes_cancelamento:
                # O cliente já cancelou; não é mais um exemplo de previsão.
                continue

            features = calcular_features_cliente(
                cliente_id, mes_snapshot, clientes, atendimento, nps
            )
            alvo = 0
            if mes_cancelamento:
                distancia = diferenca_meses(mes_snapshot, mes_cancelamento)
                alvo = int(1 <= distancia <= horizonte_meses)

            linha = {
                "cliente_id": cliente_id,
                "mes_snapshot": mes_snapshot,
                "alvo_cancelamento": alvo,
                **{nome: features[nome] for nome in FEATURES_MODELO},
            }
            linhas.append(linha)

    return pd.DataFrame(linhas)


def criar_modelo() -> Pipeline:
    return Pipeline(
        [
            ("padronizacao", StandardScaler()),
            (
                "regressao_logistica",
                LogisticRegression(
                    C=0.05,
                    class_weight="balanced",
                    max_iter=2000,
                    random_state=RANDOM_STATE,
                ),
            ),
        ]
    )


def fator_valor_contrato(valor: float, valores_carteira: pd.Series) -> float:
    logs = np.log(valores_carteira.astype(float).values)
    minimo = float(logs.min())
    maximo = float(logs.max())
    if maximo == minimo:
        return 0.0
    return float((math.log(float(valor)) - minimo) / (maximo - minimo))


def validar_modelo(base_treino: pd.DataFrame, clientes: pd.DataFrame) -> Dict[str, float | int | str]:
    X = base_treino[FEATURES_MODELO].astype(float).values
    y = base_treino["alvo_cancelamento"].astype(int).values
    grupos = base_treino["cliente_id"].values

    cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    modelo = criar_modelo()
    previsoes = cross_val_predict(
        modelo,
        X,
        y,
        groups=grupos,
        cv=cv,
        method="predict_proba",
    )[:, 1]

    base_validacao = base_treino[["cliente_id", "mes_snapshot", "alvo_cancelamento"]].copy()
    base_validacao["score_oof"] = previsoes
    valores = clientes.set_index("cliente_id")["valor_mensal"]
    base_validacao["valor_mensal"] = base_validacao["cliente_id"].map(valores).astype(float)
    base_validacao["fator_valor"] = base_validacao["valor_mensal"].apply(
        lambda v: fator_valor_contrato(v, clientes["valor_mensal"])
    )
    base_validacao["prioridade_oof"] = base_validacao["score_oof"] * (
        1.0 + 0.25 * base_validacao["fator_valor"]
    )

    selecionados = 0
    positivos_selecionados = 0
    top5_hits = 0
    top10_hits = 0
    total_positivos = int(y.sum())

    indices_top10 = set()
    indices_top5 = set()

    for mes, grupo_mes in base_validacao.groupby("mes_snapshot"):
        grupo_mes = grupo_mes.sort_values("prioridade_oof", ascending=False)
        top5 = grupo_mes.head(5)
        top10 = grupo_mes.head(TOP_N_OPERACIONAL)
        selecionados += len(top10)
        positivos_selecionados += int(top10["alvo_cancelamento"].sum())
        top5_hits += int(top5["alvo_cancelamento"].sum())
        top10_hits += int(top10["alvo_cancelamento"].sum())
        indices_top5.update(top5.index.tolist())
        indices_top10.update(top10.index.tolist())

    # Mede cancelamentos únicos: apareceu pelo menos uma vez no Top 10 nos dois meses anteriores?
    capturados_top10 = 0
    capturados_top5 = 0
    cancelados = base_treino.loc[base_treino["alvo_cancelamento"] == 1, "cliente_id"].unique()
    for cliente_id in cancelados:
        indices_cliente = base_treino.index[
            (base_treino["cliente_id"] == cliente_id)
            & (base_treino["alvo_cancelamento"] == 1)
        ].tolist()
        if any(i in indices_top10 for i in indices_cliente):
            capturados_top10 += 1
        if any(i in indices_top5 for i in indices_cliente):
            capturados_top5 += 1

    taxa_base = float(y.mean())
    precisao_top10 = positivos_selecionados / max(selecionados, 1)

    return {
        "roc_auc": float(roc_auc_score(y, previsoes)),
        "pr_auc": float(average_precision_score(y, previsoes)),
        "taxa_base": taxa_base,
        "top5_recall_client_month": top5_hits / max(total_positivos, 1),
        "top10_recall_client_month": top10_hits / max(total_positivos, 1),
        "precisao_top10": precisao_top10,
        "lift_top10": precisao_top10 / max(taxa_base, 1e-12),
        "cancelamentos_unicos": int(len(cancelados)),
        "capturados_top10": int(capturados_top10),
        "capturados_top5": int(capturados_top5),
        "amostras_treino": int(len(base_treino)),
        "positivos_treino": int(y.sum()),
    }


def texto_motivo(nome: str, valor: float) -> str:
    if nome == "abertos_media_3m":
        return f"Volume alto: {valor:.1f} chamados/mês (média 3 meses)"
    if nome == "sla_media_3m":
        return f"SLA pressionado: {valor:.1f}% cumprido (média 3 meses)"
    if nome == "sla_tendencia_6m":
        return f"SLA em queda: {abs(valor):.1f} p.p. vs. período anterior"
    if nome == "resolucao_tendencia_6m":
        return f"Resolução mais lenta: +{valor:.1f} h vs. período anterior"
    if nome == "reclamacoes_3m":
        return f"{int(round(valor))} reclamações formais nos últimos 3 meses"
    if nome == "uso_media_3m":
        return f"Uso baixo: {valor:.1f}% (média 3 meses)"
    if nome == "uso_tendencia_6m":
        return f"Uso em queda: {abs(valor):.1f} p.p. vs. período anterior"
    if nome == "atraso_max_3m":
        return f"Atraso de pagamento chegou a {int(round(valor))} dias"
    if nome == "reunioes_perdidas_pct_3m":
        return f"{valor:.0f}% das reuniões previstas não ocorreram"
    if nome == "nps_ultimo":
        return f"Último NPS baixo: nota {valor:.0f}/10"
    if nome == "nps_tendencia":
        return f"NPS caiu {abs(valor):.0f} ponto(s)"
    if nome == "nps_nao_respostas_seguidas":
        return f"{int(round(valor))} pesquisa(s) NPS seguida(s) sem resposta"
    return f"{nome}: {valor:.2f}"


def acao_inicial(motivos_nomes: List[str]) -> str:
    if any(x in motivos_nomes for x in [
        "sla_media_3m", "sla_tendencia_6m", "resolucao_tendencia_6m", "abertos_media_3m"
    ]):
        return "Revisão técnica da conta e plano de recuperação de SLA"
    if any(x in motivos_nomes for x in [
        "nps_ultimo", "nps_tendencia", "reclamacoes_3m", "nps_nao_respostas_seguidas"
    ]):
        return "Contato de relacionamento para entender insatisfação e alinhar plano"
    if any(x in motivos_nomes for x in [
        "uso_media_3m", "uso_tendencia_6m", "reunioes_perdidas_pct_3m"
    ]):
        return "Reunião de adoção/engajamento e revisão de valor percebido"
    if "atraso_max_3m" in motivos_nomes:
        return "Checagem financeira e contato preventivo sobre pagamento"
    return "Contato preventivo de relacionamento"


def gerar_ranking_atual(
    modelo: Pipeline,
    clientes: pd.DataFrame,
    atendimento: pd.DataFrame,
    nps: pd.DataFrame,
    situacao: pd.DataFrame,
    mes_atual: str,
) -> pd.DataFrame:
    ativos = situacao.loc[situacao["situacao"] == "Ativo", "cliente_id"].tolist()
    cadastro = clientes.set_index("cliente_id")

    scaler = modelo.named_steps["padronizacao"]
    reg = modelo.named_steps["regressao_logistica"]

    linhas = []
    for cliente_id in ativos:
        features = calcular_features_cliente(
            cliente_id, mes_atual, clientes, atendimento, nps
        )
        X = np.array([[features[nome] for nome in FEATURES_MODELO]], dtype=float)
        score = float(modelo.predict_proba(X)[0, 1])

        valores_padronizados = scaler.transform(X)[0]
        contribuicoes = valores_padronizados * reg.coef_[0]
        pares = sorted(
            zip(FEATURES_MODELO, contribuicoes),
            key=lambda item: item[1],
            reverse=True,
        )
        positivos = [p for p in pares if p[1] > 0][:3]

        motivos_nomes = [nome for nome, _ in positivos]
        motivos = [texto_motivo(nome, features[nome]) for nome in motivos_nomes]
        while len(motivos) < 3:
            motivos.append("Sem outro sinal relevante acima da média")

        valor = float(cadastro.loc[cliente_id, "valor_mensal"])
        fator_valor = fator_valor_contrato(valor, clientes["valor_mensal"])
        prioridade_bruta = score * (1.0 + 0.25 * fator_valor)

        linhas.append(
            {
                "cliente_id": cliente_id,
                "segmento": cadastro.loc[cliente_id, "segmento"],
                "porte": cadastro.loc[cliente_id, "porte"],
                "plano": cadastro.loc[cliente_id, "plano"],
                "valor_mensal": valor,
                "score_risco": score * 100.0,
                "prioridade_bruta": prioridade_bruta,
                "motivo_1": motivos[0],
                "motivo_2": motivos[1],
                "motivo_3": motivos[2],
                "acao_inicial": acao_inicial(motivos_nomes),
                **{nome: features[nome] for nome in FEATURES_MODELO},
            }
        )

    ranking = pd.DataFrame(linhas).sort_values("prioridade_bruta", ascending=False).reset_index(drop=True)
    if not ranking.empty:
        ranking["indice_prioridade"] = 100.0 * ranking["prioridade_bruta"] / ranking["prioridade_bruta"].max()
    else:
        ranking["indice_prioridade"] = []
    ranking.insert(0, "ordem_contato", np.arange(1, len(ranking) + 1))
    return ranking


def executar_pipeline(caminho_excel: str | Path) -> ResultadoModelo:
    clientes, atendimento, nps, situacao = carregar_dados(caminho_excel)
    mes_atual = atendimento["mes_ref"].max()

    base_treino = montar_base_treinamento(
        clientes, atendimento, nps, situacao, HORIZONTE_MESES
    )
    metricas = validar_modelo(base_treino, clientes)

    modelo = criar_modelo()
    modelo.fit(
        base_treino[FEATURES_MODELO].astype(float).values,
        base_treino["alvo_cancelamento"].astype(int).values,
    )

    ranking = gerar_ranking_atual(
        modelo, clientes, atendimento, nps, situacao, mes_atual
    )

    coef = pd.DataFrame(
        {
            "variavel": FEATURES_MODELO,
            "coeficiente_padronizado": modelo.named_steps["regressao_logistica"].coef_[0],
        }
    )
    coef["peso_absoluto"] = coef["coeficiente_padronizado"].abs()
    coef = coef.sort_values("peso_absoluto", ascending=False).reset_index(drop=True)

    return ResultadoModelo(
        ranking=ranking,
        metricas=metricas,
        modelo=modelo,
        coeficientes=coef,
        atendimento=atendimento,
        nps=nps,
        clientes=clientes,
        situacao=situacao,
        mes_atual=mes_atual,
    )


if __name__ == "__main__":
    caminho = Path(__file__).parent / "data" / "INOVAAPPS_base_de_dados.xlsx"
    resultado = executar_pipeline(caminho)

    saida = Path(__file__).with_name("ranking_gerado.csv")
    colunas = [
        "ordem_contato",
        "cliente_id",
        "segmento",
        "porte",
        "plano",
        "valor_mensal",
        "score_risco",
        "indice_prioridade",
        "motivo_1",
        "motivo_2",
        "motivo_3",
        "acao_inicial",
    ]
    resultado.ranking[colunas].to_csv(saida, index=False, encoding="utf-8-sig")

    print("Modelo executado com sucesso.")
    print(f"Mês de referência: {resultado.mes_atual}")
    print(f"ROC-AUC: {resultado.metricas['roc_auc']:.3f}")
    print(f"PR-AUC: {resultado.metricas['pr_auc']:.3f}")
    print(
        "Cancelamentos históricos capturados no Top 10: "
        f"{resultado.metricas['capturados_top10']}/{resultado.metricas['cancelamentos_unicos']}"
    )
    print(f"Ranking salvo em: {saida}")
