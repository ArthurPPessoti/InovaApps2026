# INOVAAPPS — Dashboard de Risco de Cancelamento

Aplicação web local simples, sem Streamlit e sem framework web. A interface é HTML/CSS/JavaScript e é servida pelo `http.server` do próprio Python.

## Abrir o dashboard

### Windows

Dê dois cliques em:

```text
run_windows.bat
```

Ou, pelo terminal:

```bash
python server.py
```

O navegador abrirá automaticamente em:

```text
http://localhost:8000
```

Para encerrar, volte ao terminal e pressione `Ctrl + C`.

**Importante:** não abra `web/index.html` diretamente por duplo clique. O dashboard lê um arquivo JSON e precisa ser servido localmente pelo Python.

## O que existe na aplicação

- **Visão geral:** resumo da carteira, MRR, fila crítica, Top 10, validação histórica, risco × valor e principais sinais.
- **Ranking de risco:** os 58 clientes ativos, filtros, score, prioridade, principal evidência e ação inicial sugerida.
- **Cliente 360°:** detalhes do cliente, motivos do alerta e evolução mensal de uso, SLA, chamados e NPS.
- **Como funciona:** explicação não técnica do processo, sinais utilizados, score, prioridade, validação, métricas e limitações.

## Abrir não exige instalar bibliotecas

Os dados do dashboard já estão calculados em `web/data/dashboard_data.json`. Para apenas visualizar e testar a aplicação, basta ter Python instalado.

## Recalcular o modelo com outra base

A parte de modelagem foi mantida separada para não complicar o dashboard. Para recalcular os dados:

```bash
python -m pip install -r requirements-model.txt
python atualizar_dados.py
python server.py
```

A nova planilha deve substituir:

```text
data/INOVAAPPS_base_de_dados.xlsx
```

mantendo as mesmas abas e colunas da base original.

## Estrutura

```text
INOVAAPPS_dashboard_http/
├── server.py
├── run_windows.bat
├── run_linux_mac.sh
├── atualizar_dados.py
├── requirements-model.txt
├── ranking_atual.csv
├── README.md
├── RELATORIO_METODOLOGIA.md
├── data/
│   └── INOVAAPPS_base_de_dados.xlsx
├── modelo/
│   ├── __init__.py
│   └── modelo_cancelamento.py
└── web/
    ├── index.html
    ├── styles.css
    ├── app.js
    └── data/
        └── dashboard_data.json
```

## Interpretação importante

O **Score de Risco** é um índice de ordenação de 0 a 100. Ele não é apresentado como probabilidade literal. Um cliente com score 90 não deve ser descrito como alguém com “90% de chance de cancelar”.

A **Prioridade** considera o risco e depois permite que o valor do contrato aumente a urgência em no máximo 25%. Assim, valor financeiro não substitui o comportamento do cliente.

## Resultado do backtest da base fornecida

- ROC-AUC: 0,950
- PR-AUC: 0,561
- taxa-base: 4,0%
- lift Top 10: 6,2x
- concentração de eventos no Top 10: 25,0%
- cancelamentos históricos capturados no Top 10 antes da saída: 20 de 22
- cancelamentos históricos capturados no Top 5 antes da saída: 17 de 22

Esses números são resultados do backtest sobre a base fictícia entregue no desafio, não garantia de desempenho futuro.
