from __future__ import annotations

import argparse
import functools
import http.server
import socketserver
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WEB_DIR = ROOT / "web"

class ReusableTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True


def main():
    parser = argparse.ArgumentParser(description="Dashboard local INOVAAPPS")
    parser.add_argument("--port", type=int, default=8000, help="Porta local (padrão: 8000)")
    parser.add_argument("--no-browser", action="store_true", help="Não abrir o navegador automaticamente")
    args = parser.parse_args()

    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(WEB_DIR))
    url = f"http://localhost:{args.port}"

    with ReusableTCPServer(("", args.port), handler) as httpd:
        print("=" * 62)
        print("INOVAAPPS — Dashboard de Risco de Cancelamento")
        print(f"Acesse: {url}")
        print("Para encerrar, pressione Ctrl+C.")
        print("=" * 62)

        if not args.no_browser:
            threading.Timer(0.8, lambda: webbrowser.open(url)).start()

        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServidor encerrado.")


if __name__ == "__main__":
    main()
