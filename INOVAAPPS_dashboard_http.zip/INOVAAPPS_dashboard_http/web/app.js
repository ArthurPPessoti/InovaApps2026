let DATA = null;
let currentClient = null;

const $ = (id) => document.getElementById(id);
const money = (v) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(v || 0);
const num = (v, digits = 1) => new Intl.NumberFormat('pt-BR', { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(v ?? 0);
const pct = (v, digits = 1) => `${num(v, digits)}%`;
const esc = (s) => String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

function bandClass(band) { return `band band-${band}`; }
function metricCard(label, value, note = '') {
  return `<div class="metric-card"><span class="label">${esc(label)}</span><strong>${value}</strong>${note ? `<small>${esc(note)}</small>` : ''}</div>`;
}

function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  $(`view-${name}`).classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (name === 'overview') requestAnimationFrame(renderScatter);
  if (name === 'client') requestAnimationFrame(() => renderClient(currentClient || DATA.ranking[0].client_id));
}

function initNavigation() {
  document.querySelectorAll('.nav-item').forEach(btn => btn.addEventListener('click', () => showView(btn.dataset.view)));
  document.querySelectorAll('[data-go]').forEach(btn => btn.addEventListener('click', () => showView(btn.dataset.go)));
}

function renderOverview() {
  const s = DATA.summary, m = DATA.metrics;
  $('overviewMetrics').innerHTML = [
    metricCard('Clientes ativos', s.active_clients, `${s.total_clients} clientes na base`),
    metricCard('MRR ativo', money(s.mrr_active), 'Receita mensal recorrente dos ativos'),
    metricCard('Fila crítica', `${s.critical_queue_size}`, 'Primeiros clientes para investigação'),
    metricCard('MRR no Top 10', money(s.mrr_top10), `${num(s.mrr_top10_pct,1)}% do MRR ativo`),
    metricCard('Captura histórica', `${m.capturados_top10}/${m.cancelamentos_unicos}`, 'Cancelados que passaram no Top 10 antes da saída'),
    metricCard('ROC-AUC', num(m.roc_auc,3), 'Qualidade geral da ordenação no backtest'),
  ].join('');

  $('top10List').innerHTML = DATA.ranking.slice(0,10).map(r => `
    <div class="risk-row" data-client="${esc(r.client_id)}">
      <div class="rank-badge">${r.rank}</div>
      <div class="client-id">${esc(r.client_id)}</div>
      <div class="risk-bar-track"><div class="risk-bar-fill" style="width:${Math.max(2,r.risk_score)}%"></div></div>
      <div class="risk-score">${num(r.risk_score,1)}</div>
    </div>`).join('');
  document.querySelectorAll('.risk-row[data-client]').forEach(row => row.addEventListener('click', () => openClient(row.dataset.client)));

  $('validationBlock').innerHTML = `
    <div class="validation-kpi"><strong>${m.capturados_top10}/${m.cancelamentos_unicos}</strong><span>cancelamentos históricos encontrados no Top 10 antes da saída</span></div>
    <div class="validation-kpi"><strong>${pct(m.top10_recall_client_month*100,1)}</strong><span>dos meses imediatamente anteriores a cancelamento capturados pelo Top 10</span></div>
    <div class="validation-kpi"><strong>${num(m.lift_top10,1)}×</strong><span>mais concentração de eventos que a taxa média da base</span></div>
    <div class="validation-kpi"><strong>${pct(m.precisao_top10*100,1)}</strong><span>concentração de eventos nas posições Top 10 do histórico</span></div>
    <div class="validation-note">A taxa-base de evento é de apenas ${pct(m.taxa_base*100,1)}. Por isso, concentrar ${pct(m.precisao_top10*100,1)} no Top 10 é mais informativo do que olhar apenas a acurácia tradicional.</div>`;

  $('featureBars').innerHTML = DATA.feature_importance.slice(0,7).map(f => `
    <div class="feature-row" title="${esc(f.explanation)}">
      <div class="name">${esc(f.label)}</div>
      <div class="feature-track"><div class="feature-fill" style="width:${Math.min(100,f.relative_weight*3.6)}%"></div></div>
      <div class="pct">${num(f.relative_weight,1)}%</div>
    </div>`).join('');

  renderScatter();
}

function renderScatter() {
  const svg = $('riskValueChart');
  if (!svg || !DATA) return;
  const rows = DATA.ranking;
  const W=760,H=360,L=58,R=20,T=18,B=44;
  const plotW=W-L-R, plotH=H-T-B;
  const maxMrr=Math.max(...rows.map(r=>r.mrr));
  const minMrr=Math.min(...rows.map(r=>r.mrr));
  const logMin=Math.log(Math.max(1,minMrr)), logMax=Math.log(maxMrr);
  const x = v => L + (v/100)*plotW;
  const y = v => T + (1-(Math.log(Math.max(1,v))-logMin)/(logMax-logMin || 1))*plotH;
  let html='';
  [0,25,50,75,100].forEach(t=>{ const xx=x(t); html+=`<line x1="${xx}" y1="${T}" x2="${xx}" y2="${H-B}" class="chart-grid"/><text x="${xx}" y="${H-16}" text-anchor="middle" class="chart-label">${t}</text>`; });
  [minMrr, Math.sqrt(minMrr*maxMrr), maxMrr].forEach(v=>{ const yy=y(v); html+=`<line x1="${L}" y1="${yy}" x2="${W-R}" y2="${yy}" class="chart-grid"/><text x="${L-8}" y="${yy+4}" text-anchor="end" class="chart-label">${money(v).replace(',00','')}</text>`; });
  html += `<line x1="${L}" y1="${H-B}" x2="${W-R}" y2="${H-B}" class="chart-axis"/><line x1="${L}" y1="${T}" x2="${L}" y2="${H-B}" class="chart-axis"/><text x="${L+plotW/2}" y="${H-2}" text-anchor="middle" class="chart-label">Score de Risco →</text>`;
  rows.forEach(r=>{
    const radius = r.rank <=10 ? 7 : 5;
    html += `<circle class="scatter-dot ${r.rank<=10?'top':''}" data-client="${esc(r.client_id)}" data-label="${esc(`${r.client_id} • Score ${num(r.risk_score,1)} • ${money(r.mrr)} • #${r.rank}`)}" cx="${x(r.risk_score)}" cy="${y(r.mrr)}" r="${radius}"/>`;
  });
  svg.innerHTML=html;
  svg.querySelectorAll('.scatter-dot').forEach(dot=>{
    dot.addEventListener('mouseenter', e=>showTooltip(e, dot.dataset.label));
    dot.addEventListener('mousemove', e=>moveTooltip(e));
    dot.addEventListener('mouseleave', hideTooltip);
    dot.addEventListener('click', ()=>openClient(dot.dataset.client));
  });
}

function fillSelect(id, values) {
  const el=$(id); values.forEach(v=>{ const o=document.createElement('option'); o.value=v; o.textContent=v; el.appendChild(o); });
}

function initRankingFilters() {
  fillSelect('filterBand', ['Crítico','Alto','Atenção','Monitoramento']);
  fillSelect('filterSegment', [...new Set(DATA.ranking.map(r=>r.segment))].sort());
  fillSelect('filterPlan', [...new Set(DATA.ranking.map(r=>r.plan))].sort());
  ['searchClient','filterBand','filterSegment','filterPlan','sortRanking'].forEach(id=>$(id).addEventListener(id==='searchClient'?'input':'change',renderRanking));
}

function renderRanking() {
  const q=$('searchClient').value.trim().toLowerCase(), band=$('filterBand').value, segment=$('filterSegment').value, plan=$('filterPlan').value, sort=$('sortRanking').value;
  let rows=DATA.ranking.filter(r=>(!q || r.client_id.toLowerCase().includes(q)) && (!band||r.band===band) && (!segment||r.segment===segment) && (!plan||r.plan===plan));
  if(sort==='risk') rows.sort((a,b)=>b.risk_score-a.risk_score); else if(sort==='mrr') rows.sort((a,b)=>b.mrr-a.mrr); else rows.sort((a,b)=>a.rank-b.rank);
  $('rankingCount').textContent=rows.length;
  $('rankingBody').innerHTML=rows.length ? rows.map(r=>`<tr data-client="${esc(r.client_id)}">
    <td><strong>#${r.rank}</strong></td><td><strong>${esc(r.client_id)}</strong><br><small>${esc(r.segment)} • ${esc(r.plan)}</small></td>
    <td><span class="${bandClass(r.band)}">${esc(r.band)}</span></td>
    <td class="score-cell"><div class="score-mini"><div class="mini-track"><div class="mini-fill" style="width:${r.risk_score}%"></div></div><strong>${num(r.risk_score,1)}</strong></div></td>
    <td>${num(r.priority_index,1)}</td><td>${money(r.mrr)}</td><td>${esc(r.reasons[0])}</td><td>${esc(r.suggested_action)}</td>
  </tr>`).join('') : `<tr><td colspan="8"><div class="empty">Nenhum cliente encontrado com estes filtros.</div></td></tr>`;
  $('rankingBody').querySelectorAll('tr[data-client]').forEach(tr=>tr.addEventListener('click',()=>openClient(tr.dataset.client)));
}

function initClientSelect() {
  $('clientSelect').innerHTML=DATA.ranking.map(r=>`<option value="${esc(r.client_id)}">#${r.rank} • ${esc(r.client_id)} • Score ${num(r.risk_score,1)}</option>`).join('');
  $('clientSelect').addEventListener('change',()=>renderClient($('clientSelect').value));
}

function openClient(cid) {
  currentClient=cid;
  $('clientSelect').value=cid;
  showView('client');
  renderClient(cid);
}

function renderClient(cid) {
  const c=DATA.clients[cid]; if(!c) return;
  currentClient=cid; $('clientSelect').value=cid;
  const r=c.ranking;
  $('clientHero').innerHTML=`<div><span class="${bandClass(r.band)}">${esc(r.band)}</span><h3>${esc(cid)}</h3><p>${esc(c.segment)} • ${esc(c.size)} • Plano ${esc(c.plan)} • contrato desde ${esc(c.contract_start.slice(0,7))}</p></div><div class="hero-score"><strong>${num(r.risk_score,1)}</strong><span>Score de Risco • posição #${r.rank}</span></div>`;
  $('clientMetrics').innerHTML=[
    metricCard('MRR',money(c.mrr),'Valor mensal do contrato'),
    metricCard('Prioridade',num(r.priority_index,1),'Índice usado para ordenar a fila'),
    metricCard('SLA médio 3m',pct(r.features.sla_media_3m,1),'Cumprimento recente'),
    metricCard('Uso médio 3m',pct(r.features.uso_media_3m,1),'Engajamento recente'),
    metricCard('Último NPS',num(r.features.nps_ultimo,0)+'/10', r.features.nps_nao_respostas_seguidas ? `${num(r.features.nps_nao_respostas_seguidas,0)} pesquisa(s) seguida(s) sem resposta` : 'Última resposta disponível'),
  ].join('');
  $('clientReasons').innerHTML=r.reasons.map((reason,i)=>`<div class="reason-item"><span>${i+1}</span><div>${esc(reason)}</div></div>`).join('');
  $('clientAction').textContent=r.suggested_action;

  const hist=c.history;
  drawLine('usageChart',hist,'usage_pct','Uso','%',0,100);
  drawLine('slaChart',hist,'sla_pct','SLA','%',0,100);
  drawLine('ticketsChart',hist,'tickets','Chamados','',0,null);
  drawLine('npsChart',hist,'nps','NPS','/10',0,10);
  const recent=hist.slice(-12).reverse();
  $('historyBody').innerHTML=recent.map(h=>`<tr><td><strong>${esc(h.month)}</strong></td><td>${h.usage_pct==null?'—':pct(h.usage_pct,1)}</td><td>${h.sla_pct==null?'—':pct(h.sla_pct,1)}</td><td>${h.tickets??'—'}</td><td>${h.critical_tickets??'—'}</td><td>${h.reopened_tickets??'—'}</td><td>${h.complaints??'—'}</td><td>${h.payment_delay_days==null?'—':`${h.payment_delay_days} dias`}</td><td>${h.meetings_done??0}/${h.meetings_planned??0}</td><td>${h.nps==null?'—':`${num(h.nps,0)}/10`}</td></tr>`).join('');
}

function drawLine(id, history, key, label, unit, minFixed=null, maxFixed=null) {
  const svg=$(id), vals=history.map((h,i)=>({i,month:h.month,v:h[key]})).filter(d=>d.v!==null && d.v!==undefined && !Number.isNaN(Number(d.v)));
  const W=720,H=280,L=44,R=15,T=16,B=38, plotW=W-L-R, plotH=H-T-B;
  if(!vals.length){svg.innerHTML='<text x="360" y="140" text-anchor="middle" class="chart-label">Sem dados para este indicador</text>';return;}
  let min=minFixed!==null?minFixed:Math.min(...vals.map(d=>Number(d.v))); let max=maxFixed!==null?maxFixed:Math.max(...vals.map(d=>Number(d.v)));
  if(max===min){max+=1;min=Math.max(0,min-1);} if(maxFixed===null){ const pad=(max-min)*.12; max+=pad; min=Math.max(0,min-pad); }
  const x=i=>L+(i/Math.max(history.length-1,1))*plotW; const y=v=>T+(1-(v-min)/(max-min))*plotH;
  let html='';
  for(let g=0;g<=4;g++){const yy=T+(g/4)*plotH; const v=max-(g/4)*(max-min); html+=`<line x1="${L}" y1="${yy}" x2="${W-R}" y2="${yy}" class="chart-grid"/><text x="${L-7}" y="${yy+4}" text-anchor="end" class="chart-label">${num(v,0)}${unit==='%'?'%':''}</text>`;}
  history.forEach((h,i)=>{ if(i===0 || i===history.length-1 || i%3===0) html+=`<text x="${x(i)}" y="${H-12}" text-anchor="middle" class="chart-label">${esc(h.month.slice(5))}/${esc(h.month.slice(2,4))}</text>`; });
  const pts=vals.map(d=>`${x(d.i)},${y(Number(d.v))}`).join(' ');
  const area=`${x(vals[0].i)},${H-B} ${pts} ${x(vals[vals.length-1].i)},${H-B}`;
  html+=`<polygon points="${area}" class="area-path"/><polyline points="${pts}" class="line-path"/>`;
  vals.forEach(d=>{html+=`<circle cx="${x(d.i)}" cy="${y(Number(d.v))}" r="4" class="line-dot" data-label="${esc(`${d.month} • ${label}: ${num(Number(d.v),1)}${unit}`)}"/>`;});
  svg.innerHTML=html;
  svg.querySelectorAll('.line-dot').forEach(dot=>{dot.addEventListener('mouseenter',e=>showTooltip(e,dot.dataset.label));dot.addEventListener('mousemove',moveTooltip);dot.addEventListener('mouseleave',hideTooltip);});
}

function renderReport() {
  $('signalGlossary').innerHTML=DATA.feature_importance.map(f=>`<div class="signal-card"><h4>${esc(f.label)}</h4><p>${esc(f.explanation)}</p><div class="signal-direction">${esc(f.risk_direction)}</div></div>`).join('');
  const m=DATA.metrics;
  const metrics=[
    ['ROC-AUC',num(m.roc_auc,3),'Mede o quanto o modelo consegue colocar situações próximas de cancelamento acima de situações normais. 0,5 seria praticamente aleatório; quanto mais perto de 1, melhor a separação.'],
    ['PR-AUC',num(m.pr_auc,3),`Dá mais atenção ao grupo raro que queremos encontrar: os cancelamentos. É especialmente útil porque a taxa-base é de apenas ${pct(m.taxa_base*100,1)}.`],
    ['Taxa-base',pct(m.taxa_base*100,1),'É a frequência normal de eventos de cancelamento nos exemplos mensais usados no treino. Serve como referência para saber se o Top 10 realmente concentra risco.'],
    ['Concentração Top 10',pct(m.precisao_top10*100,1),'No backtest, esta foi a proporção de posições Top 10 que correspondiam a meses localizados até dois meses antes de um cancelamento.'],
    ['Lift Top 10',num(m.lift_top10,1)+'×','Mostra quantas vezes a fila Top 10 concentra mais eventos que uma escolha média da carteira. Quanto maior, mais útil é a priorização operacional.'],
    ['Captura Top 10',`${m.capturados_top10}/${m.cancelamentos_unicos}`,'Dos clientes que cancelaram historicamente, quantos apareceram ao menos uma vez entre os 10 primeiros nos dois meses que antecederam a saída.'],
    ['Captura Top 5',`${m.capturados_top5}/${m.cancelamentos_unicos}`,'Mesma ideia da captura Top 10, porém considerando apenas os cinco primeiros clientes da fila.'],
    ['Recall Top 10',pct(m.top10_recall_client_month*100,1),'Considera todos os meses históricos que estavam dentro da janela de dois meses antes do cancelamento e mede quantos ficaram no Top 10.'],
  ];
  $('metricsGlossary').innerHTML=metrics.map(([title,value,desc])=>`<div class="metric-explain"><div class="top"><h4>${esc(title)}</h4><strong>${esc(value)}</strong></div><p>${esc(desc)}</p></div>`).join('');
  $('featureReport').innerHTML=DATA.feature_importance.map(f=>`<div class="feature-report-row"><div class="title">${esc(f.label)}</div><div class="feature-track"><div class="feature-fill" style="width:${Math.min(100,f.relative_weight*3.6)}%"></div></div><strong>${num(f.relative_weight,1)}%</strong><div class="direction">${esc(f.risk_direction)}. ${esc(f.explanation)}</div></div>`).join('');
}

function showTooltip(e,text){const t=$('tooltip');t.textContent=text;t.classList.add('show');moveTooltip(e);} function moveTooltip(e){const t=$('tooltip');t.style.left=`${Math.min(window.innerWidth-280,e.clientX+14)}px`;t.style.top=`${Math.max(8,e.clientY-12)}px`;} function hideTooltip(){$('tooltip').classList.remove('show');}

async function boot(){
  try{
    const res=await fetch('data/dashboard_data.json',{cache:'no-store'}); if(!res.ok) throw new Error('Falha ao carregar dados'); DATA=await res.json();
    $('sideMonth').textContent=DATA.reference_month; $('headerMonth').textContent=DATA.reference_month;
    initNavigation(); initRankingFilters(); initClientSelect(); renderOverview(); renderRanking(); renderReport(); renderClient(DATA.ranking[0].client_id);
  }catch(err){
    document.querySelector('.main').innerHTML=`<div class="card"><h2>Não foi possível carregar o dashboard.</h2><p>${esc(err.message)}</p><p>Abra pelo comando <strong>python server.py</strong>. O navegador não consegue ler o arquivo JSON diretamente quando o HTML é aberto com duplo clique.</p></div>`;
  }
}
boot();
