# Relatório resumido — Previsibilidade de cancelamento

## Objetivo

O modelo transforma sinais que já existem na operação em uma ordem de clientes para investigação preventiva. A pergunta principal não é apenas “quem tem risco?”, mas também “por que entrou no alerta?” e “quem deve ser analisado primeiro?”.

## Janela de análise

A maior parte dos sinais é resumida nos **últimos 3 meses**. Em indicadores de tendência, esses três meses são comparados com os **3 meses anteriores**. No treinamento histórico, o objetivo é identificar cancelamentos que ocorreriam em um dos **2 meses seguintes**.

## Sinais analisados

O modelo combina:

- média de chamados abertos;
- média de SLA cumprido;
- queda ou melhora do SLA;
- mudança no tempo de resolução;
- reclamações formais;
- nível de uso da plataforma;
- queda ou aumento de uso;
- maior atraso de pagamento;
- reuniões previstas que não ocorreram;
- última nota NPS;
- mudança entre as últimas notas NPS;
- pesquisas NPS seguidas sem resposta.

Nenhum desses sinais é tratado como causa isolada do cancelamento.

## Modelo

Foi usada **Regressão Logística regularizada com balanceamento de classes**. A escolha privilegia explicabilidade e estabilidade para uma carteira pequena.

O balanceamento é importante porque cancelamentos são muito menos frequentes que meses normais. Por causa disso, o valor bruto produzido pelo modelo é usado para **ranking**, e não apresentado como uma probabilidade literal de cancelamento.

## Score de Risco

O Score de Risco varia de 0 a 100 e indica o quanto o comportamento atual se parece com padrões que apareceram antes de cancelamentos históricos.

Ele serve para comparar clientes. Score 90 não significa, por si só, 90% de chance de cancelamento.

## Índice de Prioridade

Depois do risco comportamental, é considerado quanto está em jogo financeiramente:

```text
Prioridade = Score de Risco × (1 + 0,25 × Fator de Valor)
```

O fator financeiro varia entre 0 e 1. Assim, o valor do contrato consegue aumentar a urgência em no máximo 25%.

## Faixas operacionais

- **Crítico:** posições 1 a 10;
- **Alto:** posições 11 a 20;
- **Atenção:** posições 21 a 35;
- **Monitoramento:** demais clientes.

Essas faixas representam capacidade de atendimento e ordem operacional, não uma probabilidade estatística fixa.

## Validação

Na validação, clientes são separados entre treino e teste. O mesmo cliente não é usado simultaneamente para ensinar e avaliar o modelo naquela rodada.

Resultados na base do desafio:

- **ROC-AUC 0,950:** boa capacidade de separar situações de maior e menor risco no histórico;
- **PR-AUC 0,561:** resultado focado na classe rara de cancelamentos;
- **Taxa-base 4,0%:** apenas cerca de 4% dos exemplos mensais estavam dentro da janela de dois meses antes de uma saída;
- **Concentração Top 10 25,0%:** o Top 10 concentrou muito mais eventos que a média da base;
- **Lift Top 10 6,2x:** a fila Top 10 concentrou aproximadamente 6,2 vezes mais eventos que uma seleção média;
- **Captura Top 10 20/22:** 20 dos 22 clientes cancelados apareceram pelo menos uma vez no Top 10 antes da saída;
- **Captura Top 5 17/22:** 17 dos 22 apareceram no Top 5 antes da saída.

## Limitações

A base possui apenas 80 clientes e é fictícia. O backtest mostra que a lógica funciona bem no conjunto fornecido, mas não é garantia de desempenho futuro. O modelo identifica padrões associados a risco; ele não prova causa e não substitui investigação humana.
