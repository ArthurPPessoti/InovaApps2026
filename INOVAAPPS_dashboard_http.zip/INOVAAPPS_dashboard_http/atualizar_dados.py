from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from modelo.modelo_cancelamento import executar_pipeline, TOP_N_OPERACIONAL

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "data" / "INOVAAPPS_base_de_dados.xlsx"
OUT = ROOT / "web" / "data" / "dashboard_data.json"

FEATURE_LABELS = {
    "abertos_media_3m": "Chamados abertos",
    "sla_media_3m": "SLA cumprido",
    "sla_tendencia_6m": "Tendência do SLA",
    "resolucao_tendencia_6m": "Tempo de resolução",
    "reclamacoes_3m": "Reclamações formais",
    "uso_media_3m": "Uso da plataforma",
    "uso_tendencia_6m": "Tendência de uso",
    "atraso_max_3m": "Atraso de pagamento",
    "reunioes_perdidas_pct_3m": "Reuniões não realizadas",
    "nps_ultimo": "Último NPS",
    "nps_tendencia": "Tendência do NPS",
    "nps_nao_respostas_seguidas": "NPS sem resposta",
}

FEATURE_EXPLANATIONS = {
    "abertos_media_3m": "Média de chamados abertos nos últimos 3 meses.",
    "sla_media_3m": "Percentual médio de SLA cumprido nos últimos 3 meses.",
    "sla_tendencia_6m": "Compara o SLA dos últimos 3 meses com os 3 meses anteriores.",
    "resolucao_tendencia_6m": "Mostra se o tempo de resolução aumentou ou diminuiu em relação ao período anterior.",
    "reclamacoes_3m": "Quantidade total de reclamações formais nos últimos 3 meses.",
    "uso_media_3m": "Percentual médio de uso da plataforma nos últimos 3 meses.",
    "uso_tendencia_6m": "Compara o uso dos últimos 3 meses com os 3 meses anteriores.",
    "atraso_max_3m": "Maior atraso de pagamento observado nos últimos 3 meses.",
    "reunioes_perdidas_pct_3m": "Percentual de reuniões previstas que não aconteceram nos últimos 3 meses.",
    "nps_ultimo": "Última nota NPS respondida pelo cliente.",
    "nps_tendencia": "Mudança entre as duas últimas notas NPS respondidas.",
    "nps_nao_respostas_seguidas": "Quantidade de pesquisas NPS consecutivas sem resposta.",
}


def py(v):
    if v is None:
        return None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return None if np.isnan(v) else float(v)
    if isinstance(v, pd.Timestamp):
        return v.strftime("%Y-%m-%d")
    if pd.isna(v):
        return None
    return v


def faixa(ordem: int) -> str:
    if ordem <= 10:
        return "Crítico"
    if ordem <= 20:
        return "Alto"
    if ordem <= 35:
        return "Atenção"
    return "Monitoramento"


def main():
    resultado = executar_pipeline(BASE)
    ranking = resultado.ranking.copy()
    metricas = resultado.metricas

    total_clientes = int(resultado.clientes["cliente_id"].nunique())
    ativos = int(len(ranking))
    cancelados = int((resultado.situacao["situacao"] != "Ativo").sum())
    mrr_ativo = float(ranking["valor_mensal"].sum())
    mrr_top10 = float(ranking.head(TOP_N_OPERACIONAL)["valor_mensal"].sum())

    coef = resultado.coeficientes.copy()
    total_peso = float(coef["peso_absoluto"].sum()) or 1.0
    features = []
    for _, row in coef.iterrows():
        nome = row["variavel"]
        c = float(row["coeficiente_padronizado"])
        features.append({
            "key": nome,
            "label": FEATURE_LABELS.get(nome, nome),
            "explanation": FEATURE_EXPLANATIONS.get(nome, ""),
            "coefficient": c,
            "relative_weight": float(row["peso_absoluto"] / total_peso * 100),
            "risk_direction": "Valores maiores aumentam o risco" if c > 0 else "Valores menores aumentam o risco",
        })

    rank_rows = []
    for _, row in ranking.iterrows():
        rank_rows.append({
            "rank": int(row["ordem_contato"]),
            "client_id": str(row["cliente_id"]),
            "segment": str(row["segmento"]),
            "size": str(row["porte"]),
            "plan": str(row["plano"]),
            "mrr": float(row["valor_mensal"]),
            "risk_score": float(row["score_risco"]),
            "priority_index": float(row["indice_prioridade"]),
            "band": faixa(int(row["ordem_contato"])),
            "reasons": [str(row["motivo_1"]), str(row["motivo_2"]), str(row["motivo_3"])],
            "suggested_action": str(row["acao_inicial"]),
            "features": {k: py(row[k]) for k in FEATURE_LABELS.keys()},
        })

    clients_meta = resultado.clientes.set_index("cliente_id")
    nps_by_key = {
        (str(r["cliente_id"]), str(r["mes_ref"])): {
            "answered": int(r["respondeu"]),
            "nps": py(r["nota_nps"]),
            "nps_class": py(r["classificacao_nps"]),
        }
        for _, r in resultado.nps.iterrows()
    }

    client_details = {}
    active_ids = set(ranking["cliente_id"].astype(str))
    ranking_by_id = {r["client_id"]: r for r in rank_rows}
    for cid in sorted(active_ids):
        h = resultado.atendimento[resultado.atendimento["cliente_id"].astype(str) == cid].sort_values("mes_ref")
        history = []
        for _, r in h.iterrows():
            month = str(r["mes_ref"])
            n = nps_by_key.get((cid, month), {"answered": None, "nps": None, "nps_class": None})
            history.append({
                "month": month,
                "tickets": py(r["chamados_abertos"]),
                "critical_tickets": py(r["chamados_criticos"]),
                "reopened_tickets": py(r["chamados_reabertos"]),
                "within_sla": py(r["chamados_dentro_sla"]),
                "sla_pct": py(r["pct_sla_cumprido"]),
                "resolution_hours": py(r["tempo_medio_resolucao_h"]),
                "complaints": py(r["reclamacoes_formais"]),
                "usage_pct": py(r["uso_plataforma_pct"]),
                "payment_delay_days": py(r["dias_atraso_pagamento"]),
                "meetings_planned": py(r["reunioes_previstas"]),
                "meetings_done": py(r["reunioes_realizadas"]),
                "nps": n["nps"],
                "nps_answered": n["answered"],
                "nps_class": n["nps_class"],
            })

        meta = clients_meta.loc[cid]
        client_details[cid] = {
            "client_id": cid,
            "segment": str(meta["segmento"]),
            "size": str(meta["porte"]),
            "plan": str(meta["plano"]),
            "mrr": float(meta["valor_mensal"]),
            "contracted_sla_hours": float(meta["sla_contratado_h"]),
            "contract_start": meta["inicio_contrato"].strftime("%Y-%m-%d"),
            "ranking": ranking_by_id[cid],
            "history": history,
        }

    bands = {"Crítico": 0, "Alto": 0, "Atenção": 0, "Monitoramento": 0}
    for r in rank_rows:
        bands[r["band"]] += 1

    payload = {
        "generated_from": BASE.name,
        "reference_month": resultado.mes_atual,
        "summary": {
            "total_clients": total_clientes,
            "active_clients": ativos,
            "cancelled_clients": cancelados,
            "mrr_active": mrr_ativo,
            "critical_queue_size": min(TOP_N_OPERACIONAL, ativos),
            "mrr_top10": mrr_top10,
            "mrr_top10_pct": mrr_top10 / max(mrr_ativo, 1) * 100,
            "bands": bands,
        },
        "metrics": {k: py(v) for k, v in metricas.items()},
        "feature_importance": features,
        "ranking": rank_rows,
        "clients": client_details,
        "methodology": {
            "observation_window_months": 3,
            "comparison_window_months": 3,
            "prediction_horizon_months": 2,
            "model_name": "Regressão Logística regularizada",
            "top_n": TOP_N_OPERACIONAL,
            "priority_formula": "Prioridade = Score de Risco × (1 + 0,25 × Fator de Valor)",
            "priority_note": "O valor do contrato aumenta a prioridade em no máximo 25%, para não transformar receita em risco.",
        },
    }

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Dados atualizados em: {OUT}")
    print(f"Mês de referência: {resultado.mes_atual}")
    print(f"Clientes ativos: {ativos}")
    print(f"Top 10 histórico: {metricas['capturados_top10']}/{metricas['cancelamentos_unicos']}")


if __name__ == "__main__":
    main()
